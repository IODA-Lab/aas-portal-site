"""Simulation-session KPIs; no OEE claim without planned production/loss data."""
def compute(s):
    produced,good,reject=(s[k] for k in ('Produced','Good','Reject'))
    if produced!=good+reject: raise ValueError('inconsistent production counters')
    total=s['SimTime']; cycles=s['CompletedCycles']
    return {'QualityRate':good/produced if produced else 0.0,'RejectRate':reject/produced if produced else 0.0,
            'Utilization':s['RunSeconds']/total if total else 0.0,'ThroughputPerHour':produced*3600/total if total else 0.0,
            'MeanCycleTime':s['CycleSumSeconds']/cycles if cycles else 0.0}
