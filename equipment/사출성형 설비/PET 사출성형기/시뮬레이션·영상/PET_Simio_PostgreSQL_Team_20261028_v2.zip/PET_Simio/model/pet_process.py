"""Deterministic PET process; no networking or external packages. All values simulated."""
from pathlib import Path
from collections import deque
import copy
import json
import math
import random

SCENARIO = Path(__file__).with_name('process_scenario.json')


def smooth(x):
    x = min(1.0, max(0.0, x))
    return x*x*(3-2*x)


class PetProcess:
    def __init__(self, scenario_path=None, seed=0, scenario=None, init=None):
        self.cfg = copy.deepcopy(scenario) if isinstance(scenario, dict) else json.loads(Path(scenario_path or SCENARIO).read_text(encoding='utf-8'))
        c = self.cfg
        if isinstance(scenario, str) and scenario != 'normal':
            c['faults'] = copy.deepcopy(c['fault_profiles'][scenario])
        self._validate()
        self.rng = random.Random(seed)
        self.hz = c['tick_hz']; self.tick = 1/self.hz
        self.steps = c['steps']; self.recipe = c['recipe']; self.limits = c['limits']
        self.n = 0; self.pending_dt = 0.0; self.t = 0.0
        self.stage = 0; self.elapsed = 0.0; self.mode = 'Running'; self.alarm = 'None'
        self.stop_requested = False; self.cycle_start = None
        self.completed_cycles = 0; self.produced = 0; self.good = 0; self.reject = 0
        self.run_s = 0.0; self.last_cycle_s = 0.0; self.cycle_sum_s = 0.0
        self.barrel = c['dynamics']['barrel_initial_c']; self.mold_temp = c['dynamics']['mold_initial_c']
        self.pressure = 0.0; self.mold_open = self.recipe['mold_open_mm']
        self.screw = self.recipe['cushion_mm']; self.angle = 0.0; self.rpm = 0.0
        self.peak_pressure = 0.0; self.batch_bad = False; self.takeout = 0.0
        self.conveyor_batches = []; self.ejected = False; self.events = []
        self.cycle_log = deque(maxlen=1000)
        self._noise_temp = 0.0; self._noise_pressure = 0.0
        if init:
            # Resume counters only at a safe new cycle. Never restore a partly molded shot.
            for key, attr in [('CompletedCycles','completed_cycles'),('Produced','produced'),('Good','good'),('Reject','reject'),('RunSeconds','run_s'),('CycleSumSeconds','cycle_sum_s')]:
                setattr(self, attr, type(getattr(self,attr))(init[key]))
            self.t = float(init['SimTime']); self.n = round(self.t*self.hz)
            if self.produced != self.good+self.reject:
                raise ValueError('counter continuity mismatch')

    def _validate(self):
        c=self.cfg
        expected=['Feed','Warmup','Clamp','Inject','Hold','CoolMeter','Open','Eject','Transfer']
        if [s['name'] for s in c['steps']] != expected:
            raise ValueError('invalid phase order')
        def positive(v): return isinstance(v,(int,float)) and math.isfinite(v) and v>0
        if not all(positive(s['duration_s']) for s in c['steps']): raise ValueError('durations must be positive')
        if not positive(c['tick_hz']) or int(c['tick_hz'])!=c['tick_hz']: raise ValueError('invalid tick rate')
        if not all(positive(v) for v in c['recipe'].values()): raise ValueError('invalid recipe')
        if not isinstance(c['recipe']['cavities'],int): raise ValueError('cavities must be integer')
        if not all(positive(c['dynamics'][k]) for k in ['barrel_tau_s','mold_tau_s','pressure_tau_s','pressure_release_tau_s']): raise ValueError('invalid dynamics')
        if not 0<=c['quality']['base_reject_probability']<=1: raise ValueError('invalid reject probability')
        if c['recipe']['cushion_mm']>=c['recipe']['screw_stroke_mm']: raise ValueError('cushion >= stroke')
        if not c['limits']['barrel_ready_c']<c['recipe']['barrel_target_c']<c['limits']['barrel_max_c']: raise ValueError('temperature limits')
        if c['recipe']['holding_setpoint_bar']>c['recipe']['injection_setpoint_bar'] or c['recipe']['injection_setpoint_bar']>=c['limits']['pressure_max_bar']: raise ValueError('pressure limits')

    @property
    def phase(self): return self.steps[self.stage]['name']

    def duration(self, index=None):
        i=self.stage if index is None else index
        d=self.steps[i]['duration_s']
        return max(d,self.recipe['metering_s']) if self.steps[i]['name']=='CoolMeter' else d

    def nominal_timeline(self):
        t=0.; result=[]
        for i,s in enumerate(self.steps):
            d=self.duration(i); result.append({'phase':s['name'],'start_s':t,'end_s':t+d,'startup_only':i<2}); t+=d
        return result

    def request_stop(self): self.stop_requested=True

    def pause(self):
        if self.mode=='Running': self.mode='Standby'

    def start(self):
        if self.alarm!='None': raise RuntimeError('clear active alarm first')
        if self.mode=='Stopped': self._enter(2)
        self.mode='Running'; self.stop_requested=False

    def clear_alarm(self):
        if self._faults(): raise RuntimeError('fault still active')
        if self.barrel>=self.limits['barrel_max_c'] or self.mold_temp>=self.limits['mold_max_c']: raise RuntimeError('temperature still unsafe')
        self.alarm='None'; self.mode='Stopped'; self.pressure=0
        self.mold_open=self.recipe['mold_open_mm']; self.screw=self.recipe['screw_stroke_mm']
        self.takeout=0; self.ejected=False

    def _faults(self):
        return {f['kind'] for f in self.cfg['faults'] if f['at_s']<=self.t<f['at_s']+f['duration_s']}

    def _enter(self,index):
        old=self.phase; self.stage=index; self.elapsed=0
        if index==2:
            self.cycle_start=self.t; self.peak_pressure=0; self.batch_bad=False; self.ejected=False
        self.events.append({'type':'phase_changed','time':round(self.t,6),'from':old,'phase':self.phase})

    def _trip(self,code):
        if self.alarm=='None': self.events.append({'type':'alarm','time':round(self.t,6),'code':code})
        self.alarm=code; self.mode='Alarm'; self.rpm=0; self.pressure=0; self.batch_bad=True

    def _tick(self):
        dt=self.tick; self.n+=1; self.t=self.n/self.hz
        faults=self._faults(); r=self.recipe; d=self.cfg['dynamics']
        p=self.phase; active=self.mode=='Running'
        target=r['barrel_target_c']+(d['barrel_meter_heat_c'] if active and p in ('Warmup','CoolMeter') else 0)
        if 'overheat' in faults: target=self.limits['barrel_max_c']+40
        self.barrel+=(target-self.barrel)*(-math.expm1(-dt/d['barrel_tau_s']))
        self.mold_temp+=(r['mold_target_c']-self.mold_temp)*(-math.expm1(-dt/d['mold_tau_s']))
        if active and p in ('Inject','Hold'): self.mold_temp+=d['mold_heat_c_per_s']*dt
        if self.barrel>self.limits['barrel_max_c']: self._trip('BARREL_OVERHEAT')
        if 'interlock' in faults: self._trip('SAFETY_INTERLOCK')
        if 'cooling_failure' in faults and p=='CoolMeter': self._trip('COOLING_FAILURE')
        if self.mold_temp>self.limits['mold_max_c']: self._trip('MOLD_OVERHEAT')
        active=self.mode=='Running'; self.rpm=0
        if active:
            self.run_s+=dt; self.elapsed+=dt
            u=min(1,self.elapsed/self.duration()); v=smooth(u)
            if p=='Warmup':
                self.rpm=r['screw_rpm']; self.screw=r['cushion_mm']+(r['screw_stroke_mm']-r['cushion_mm'])*v
            elif p=='Clamp': self.mold_open=r['mold_open_mm']*(1-v)
            elif p=='Inject': self.screw=r['screw_stroke_mm']-(r['screw_stroke_mm']-r['cushion_mm'])*v
            elif p=='CoolMeter':
                m=min(1,self.elapsed/r['metering_s']); self.screw=r['cushion_mm']+(r['screw_stroke_mm']-r['cushion_mm'])*smooth(m)
                self.rpm=r['screw_rpm'] if m<1 else 0
            elif p=='Open': self.mold_open=r['mold_open_mm']*v
            elif p=='Eject': self.takeout=v
            elif p=='Transfer': self.takeout=1-v
            pt=r['injection_setpoint_bar'] if p=='Inject' else r['holding_setpoint_bar'] if p=='Hold' else 0
            if pt and self.mold_open>1e-6: self._trip('MOLD_NOT_CLAMPED'); pt=0
            if 'overpressure' in faults and p=='Inject': pt=self.limits['pressure_max_bar']*1.25
            tau=d['pressure_tau_s'] if pt else d['pressure_release_tau_s']
            self.pressure+=(pt-self.pressure)*(-math.expm1(-dt/tau))
            if self.pressure>self.limits['pressure_max_bar']: self._trip('OVERPRESSURE')
            if p=='Inject': self.peak_pressure=max(self.peak_pressure,self.pressure)
            self.angle+=self.rpm*6*dt
            self.batch_bad |= self.mold_temp>self.cfg['quality']['max_mold_c']
            ready=self.elapsed+1e-9>=self.duration()
            if p=='Warmup':
                ready &= self.barrel>=self.limits['barrel_ready_c']
                if self.elapsed>self.limits['warmup_timeout_s']: self._trip('WARMUP_TIMEOUT')
            if p=='CoolMeter': ready &= self.pressure<self.limits['open_pressure_bar']
            if ready and self.mode=='Running':
                if p=='Eject' and not self.ejected:
                    bad=self.batch_bad or self.peak_pressure<self.cfg['quality']['min_injection_peak_bar']
                    ng=r['cavities'] if bad else sum(self.rng.random()<self.cfg['quality']['base_reject_probability'] for _ in range(r['cavities']))
                    self.produced+=r['cavities']; self.reject+=ng; self.good+=r['cavities']-ng; self.ejected=True
                    self.events.append({'type':'batch_ejected','time':self.t,'good':r['cavities']-ng,'reject':ng})
                if p=='Transfer':
                    self.completed_cycles+=1; self.last_cycle_s=self.t-self.cycle_start; self.cycle_sum_s+=self.last_cycle_s
                    event={'type':'cycle_done','time':self.t,'cycle':self.completed_cycles,'duration_s':self.last_cycle_s}
                    self.cycle_log.append(event); self.events.append(event)
                    self.conveyor_batches.append({'start':self.t,'count':r['cavities']})
                    if self.stop_requested: self.mode='Stopped'; self.rpm=0
                    else: self._enter(2)
                else: self._enter(self.stage+1)
        else: self.pressure*=math.exp(-dt/d['pressure_release_tau_s'])
        self.conveyor_batches=[b for b in self.conveyor_batches if self.t-b['start']<r['conveyor_s']]
        self._noise_temp=self.rng.uniform(-1,1)*self.cfg['noise']['temperature_c']
        self._noise_pressure=self.rng.uniform(-1,1)*self.cfg['noise']['pressure_bar']

    def step(self,dt=None):
        dt=self.tick if dt is None else dt
        if not math.isfinite(dt) or dt<0: raise ValueError('dt must be finite and nonnegative')
        self.events=[]; self.pending_dt+=dt
        while self.pending_dt+1e-10>=self.tick:
            self.pending_dt-=self.tick; self._tick()
        return self.state()

    def state(self):
        r=self.recipe; active=self.mode=='Running'; p=self.phase
        cycle_nominal=sum(self.duration(i) for i in range(2,len(self.steps)))
        progress=0 if self.stage<2 else min(1,(sum(self.duration(i) for i in range(2,self.stage))+self.elapsed)/cycle_nominal)
        s={'SchemaVersion':'1.0.0','DataSource':'Simulated','Assumption':'SimulationAssumption','SimTime':round(self.t,6),
           'RunState':self.mode,'Phase':p,'PhaseProgress':round(min(1,self.elapsed/self.duration()),6),'CycleProgress':round(progress,6),
           'BarrelTemperature':round(self.barrel+self._noise_temp,4),'MoldTemperature':round(self.mold_temp+self._noise_temp,4),
           'InjectionPressure':round(max(0,self.pressure+self._noise_pressure),4) if active and p in ('Inject','Hold') else 0.0,
           'InjectionSetpoint':r['injection_setpoint_bar'],'HoldingSetpoint':r['holding_setpoint_bar'],
           'HoldingPressure':round(self.pressure,4) if active and p=='Hold' else 0.0,
           'ClampingForce':r['clamp_force_kn'] if self.mold_open<1e-6 else 0.0,
           'MoldOpen':round(self.mold_open,4),'ScrewPosition':round(self.screw,4),'ScrewRPM':self.rpm if active else 0,
           'ScrewAngle':round(self.angle,4),'Cooling':active and p=='CoolMeter','Metering':active and p=='CoolMeter' and self.elapsed<r['metering_s'],
           'Injection':active and p=='Inject','Holding':active and p=='Hold','Takeout':round(self.takeout,6),
           'ConveyorProgress':round((self.t-self.conveyor_batches[-1]['start'])/r['conveyor_s'],6) if self.conveyor_batches else -1.0,
           'Cavities':r['cavities'],'CompletedCycles':self.completed_cycles,'Produced':self.produced,'Good':self.good,'Reject':self.reject,
           'CycleTime':round(self.last_cycle_s,6),'CycleSumSeconds':round(self.cycle_sum_s,6),'RunSeconds':round(self.run_s,6),'Alarm':self.alarm}
        # Keep the public contract's analog types stable even when a recipe uses integer literals.
        integer_fields={'Cavities','CompletedCycles','Produced','Good','Reject'}
        for key,value in s.items():
            if isinstance(value,(int,float)) and not isinstance(value,bool) and key not in integer_fields:
                s[key]=float(value)
        return s

    def telemetry(self,ts=None):
        s=self.state(); s['Timestamp']=self.t if ts is None else ts; s['Events']=copy.deepcopy(self.events); return s

    def process_msg(self,ts=None): return self.telemetry(ts)


if __name__=='__main__':
    e=PetProcess()
    while e.completed_cycles<2:
        e.step()
        for event in e.events: print(json.dumps(event,ensure_ascii=False))
    print(json.dumps(e.state(),ensure_ascii=False,indent=2))
