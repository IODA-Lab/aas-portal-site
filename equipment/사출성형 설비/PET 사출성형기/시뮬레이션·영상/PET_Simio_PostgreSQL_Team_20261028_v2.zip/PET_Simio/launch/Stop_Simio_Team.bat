@echo off
cd /d "%~dp0.."
powershell -NoProfile -ExecutionPolicy Bypass -File launch\Simio_Team.ps1 -Action Stop
pause
