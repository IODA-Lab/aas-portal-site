param([ValidateSet('Start','Stop','Status')][string]$Action='Start')
$ErrorActionPreference='Stop'
$PetSimioRoot=Split-Path -Parent $PSScriptRoot
Push-Location $PetSimioRoot
try {
    docker info --format '{{.ServerVersion}}'
    if($LASTEXITCODE -ne 0){throw 'Start Docker Desktop (Linux containers), then retry.'}
    $envFile=Join-Path $PetSimioRoot 'simio-team.local.env'
    if(-not(Test-Path -LiteralPath $envFile)){
        if($Action -ne 'Start'){throw 'No Simio team configuration. Run Start first.'}
        $existing=docker volume ls --filter 'label=com.docker.compose.project=pet-simio-team' --format '{{.Name}}'
        if($LASTEXITCODE -ne 0){throw 'Cannot inspect volumes.'}
        if($existing){throw 'Existing Simio team volumes found. Restore simio-team.local.env; no reset was performed.'}
        $source=Join-Path $env:LOCALAPPDATA 'PETSimio/Live'
        New-Item -ItemType Directory -Force -Path $source | Out-Null
        $source=$source.Replace('\','/')
        $password=[Guid]::NewGuid().ToString('N')
        [IO.File]::WriteAllText($envFile,"PET_SIMIO_GRAFANA_PASSWORD=$password`nPET_SIMIO_LIVE_DIR=`"$source`"`n",[Text.UTF8Encoding]::new($false))
    }
    $configText=[IO.File]::ReadAllText($envFile)
    if($configText -notmatch '(?m)^PET_POSTGRES_PASSWORD=.+'){
        if($Action -ne 'Start'){throw 'PostgreSQL configuration missing. Run Start to upgrade this package first.'}
        $pgVolumes=docker volume ls --filter 'label=com.docker.compose.project=pet-simio-team' --format '{{.Name}}'
        if($LASTEXITCODE -ne 0){throw 'Cannot inspect PostgreSQL volumes.'}
        if($pgVolumes -contains 'pet-simio-team_simio-postgres'){throw 'PostgreSQL volume exists but password is missing. Restore the original env file; no reset was performed.'}
        $pgPassword=[Guid]::NewGuid().ToString('N')
        [IO.File]::AppendAllText($envFile,"`nPET_POSTGRES_PASSWORD=$pgPassword`n",[Text.UTF8Encoding]::new($false))
    }
    $dc=@('compose','--project-name','pet-simio-team','--env-file',$envFile,'-f','docker-compose.simio-team.yml')
    if($Action -eq 'Stop'){
        & docker @dc stop -t 30 bridge
        if($LASTEXITCODE -ne 0){throw 'Bridge stop failed; remaining services left running.'}
        for($drain=0;$drain -lt 10;$drain++){
            $archiveText=& docker @dc exec -T archive python tools/archive_status.py
            try {$archiveState=$archiveText | ConvertFrom-Json} catch {break}
            if($archiveState.pending -eq 0){break}
            Start-Sleep -Seconds 1
        }
        & docker @dc stop -t 15 archive
        if($LASTEXITCODE -ne 0){throw 'Archive stop failed. Pending records remain on the outbox volume.'}
        & docker @dc stop -t 30 grafana aas-env mongo postgres
        if($LASTEXITCODE -ne 0){throw 'Check container status; some services did not stop.'}
        Write-Output 'Stopped. Volumes and model retained. You may stop/close Simio now.'
        exit 0
    }
    if($Action -eq 'Start'){
        & docker @dc up -d --build
        if($LASTEXITCODE -ne 0){throw 'Startup failed. No existing service or volume was reset.'}
    }
    $manifest=Get-Content aas/twin_manifest.json -Raw -Encoding utf8 | ConvertFrom-Json
    $runtime=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($manifest.submodels.TwinRuntime)).TrimEnd('=').Replace('+','-').Replace('/','_')
    $url="http://127.0.0.1:8084/submodels/$runtime/submodel-elements/Current/%24value"
    $attempts=1
    if($Action -eq 'Start'){$attempts=90}
    $ready=$false
    for($i=0;$i -lt $attempts;$i++){
        try {
            $v=Invoke-RestMethod $url -TimeoutSec 3
            $age=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000-[double]$v.Timestamp
            if($v.Connection -eq 'ConnectedSimulated' -and $v.Session -like 'simio-*' -and $age -ge -1 -and $age -lt 5){
                $health=Invoke-RestMethod 'http://127.0.0.1:3004/api/health' -TimeoutSec 3
                if($health.database -eq 'ok'){
                    $archiveText=& docker @dc exec -T archive python tools/archive_status.py
                    if($LASTEXITCODE -eq 0){$ready=$true;break}
                }
            }
        } catch { }
        if($Action -eq 'Start'){Start-Sleep -Seconds 2}
    }
    & docker @dc ps
    if($LASTEXITCODE -ne 0){throw 'Cannot inspect containers.'}
    if(-not $ready){throw 'Not ready: verify Simio (Shift+F6), AAS, Grafana and PostgreSQL archive. Then retry Start. Inspect logs: docker compose --env-file simio-team.local.env -f docker-compose.simio-team.yml logs --tail 60 bridge aas-env grafana archive postgres'}
    Write-Output "SIMIO LIVE Sequence=$($v.Sequence) Phase=$($v.Phase) Produced=$($v.Produced)"
    Write-Output 'Grafana: http://localhost:3004/d/pet-injection-twin'
    Write-Output 'Login admin; password: PET_SIMIO_GRAFANA_PASSWORD in simio-team.local.env.'
    Write-Output 'PostgreSQL: localhost:15432 / database pet_history / user pet; password: PET_POSTGRES_PASSWORD in simio-team.local.env.'
    Write-Output "ARCHIVE $archiveText"
} finally {Pop-Location}
