@echo off
cd /d "%~dp0.."
powershell -NoProfile -ExecutionPolicy Bypass -File launch\Backup_PostgreSQL.ps1
pause
