@echo off
cd /d "%~dp0.."
powershell -NoProfile -ExecutionPolicy Bypass -File launch\Install_Simio_Extension.ps1
pause
