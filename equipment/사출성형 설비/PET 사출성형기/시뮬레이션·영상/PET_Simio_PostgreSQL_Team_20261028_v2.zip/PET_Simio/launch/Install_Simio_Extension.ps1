param([switch]$Build)
$ErrorActionPreference='Stop'
$PetProjectRoot=Split-Path -Parent $PSScriptRoot
if(Get-Process -Name Simio -ErrorAction SilentlyContinue){throw 'Close Simio before installing its extension. Save the model first.'}
$project=Join-Path $PetProjectRoot 'simio/NativeTelemetry/PetSimioTelemetry.csproj'
if($Build){
    & dotnet build $project -c Release
    if($LASTEXITCODE -ne 0){throw 'PETTelemetry build failed'}
}
$dll=Join-Path $PetProjectRoot 'simio/NativeTelemetry/bin/Release/net10.0-windows/PetSimioTelemetry.dll'
if(-not(Test-Path -LiteralPath $dll)){throw 'Extension DLL missing. Run this script with -Build using .NET 10 SDK and Simio 20.'}
$target=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'SimioUserExtensions'
New-Item -ItemType Directory -Path $target -Force | Out-Null
$dest=Join-Path $target 'PetSimioTelemetry.dll'
if(Test-Path -LiteralPath $dest){Copy-Item -LiteralPath $dest -Destination ($dest+'.previous') -Force}
Copy-Item -LiteralPath $dll -Destination $dest -Force
Write-Output "Installed: $dest"
Write-Output 'Open simio/PET_24Cavity_27_5s.spfx in Simio, then Fast Forward (Shift+F6).'
