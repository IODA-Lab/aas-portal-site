$ErrorActionPreference='Stop'
$PetRoot=Split-Path -Parent $PSScriptRoot
Push-Location $PetRoot
try {
    $dc=@('compose','--project-name','pet-simio-team','--env-file','simio-team.local.env','-f','docker-compose.simio-team.yml')
    $backupDir=Join-Path $PetRoot 'backups'
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    $name='pet_history_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.dump'
    & docker @dc exec -T postgres pg_dump -U pet -d pet_history -Fc -f /tmp/pet-history-backup.dump
    if($LASTEXITCODE -ne 0){throw 'PostgreSQL backup failed'}
    & docker @dc cp postgres:/tmp/pet-history-backup.dump (Join-Path $backupDir $name)
    if($LASTEXITCODE -ne 0){throw 'Backup copy failed'}
    Write-Output "Backup saved: $(Join-Path $backupDir $name)"
} finally {Pop-Location}
