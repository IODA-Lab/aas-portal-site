"""Transport native Simio observations to the existing AAS contract.

This module has no process engine, phase timing, random yield or pose synthesis.
Stale, accelerated or restarted sources stop publication instead of fabricating data.
"""
import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

import pet_config as cfg
from cycle_archive import CycleTracker,Outbox,telemetry_event
from aas_equipment import AasTwinWriter, iso, parse_snapshot

COUNTERS = ('CompletedCycles','Produced','Good','Reject','CycleSumSeconds','RunSeconds')
REQUIRED = set(('SchemaVersion DataSource Assumption SimTime RunState Phase PhaseProgress CycleProgress '
 'BarrelTemperature MoldTemperature InjectionPressure InjectionSetpoint HoldingSetpoint HoldingPressure '
 'ClampingForce MoldOpen ScrewPosition ScrewRPM ScrewAngle Cooling Metering Injection Holding Takeout '
 'ConveyorProgress Cavities CompletedCycles Produced Good Reject CycleTime CycleSumSeconds RunSeconds Alarm SampleIndex').split())


def read_packet(path, now=None):
    now = time.time() if now is None else now
    packet = json.loads(Path(path).read_text(encoding='utf-8'))
    if packet.get('engine') != 'Simio' or packet.get('model') != 'PET_24Cavity_27_5s':
        raise ValueError('unexpected source model')
    if not isinstance(packet.get('session'), str) or not packet['session'].startswith('simio-'):
        raise ValueError('missing Simio run identity')
    age = now - packet['written_at']
    if not math.isfinite(age) or not -1 <= age <= 3:
        raise ValueError('Simio source stale; start/resume the Simio model')
    samples = packet.get('samples')
    if not isinstance(samples,list) or not 1 <= len(samples) <= 40:
        raise ValueError('invalid pose window')
    previous = -1
    for sample in samples:
        if set(sample) != REQUIRED:
            raise ValueError('Simio output contract mismatch')
        for value in sample.values():
            if isinstance(value,(int,float)) and not math.isfinite(value):
                raise ValueError('non-finite Simio value')
        if sample['SampleIndex'] <= previous:
            raise ValueError('out-of-order Simio samples')
        previous=sample['SampleIndex']
        if sample['Produced'] != sample['Good']+sample['Reject'] or sample['Cavities']!=24:
            raise ValueError('Simio cavity/counter mismatch')
    return packet


def discover_packet():
    # Each native Simio run has its own file. Never reuse a stale session.
    configured=os.environ.get('PET_SIMIO_LIVE_DIR')
    folder=Path(configured) if configured else Path(os.environ['LOCALAPPDATA'])/'PETSimio/Live'
    matches=[]
    for path in folder.glob('pet_live_simio-*.json'):
        try: read_packet(path)
        except (ValueError,OSError,KeyError,TypeError): continue
        matches.append(path)
    if len(matches)!=1:
        raise ValueError('Run exactly one PET_24Cavity_27_5s model with the PETTelemetry extension in Simio; fresh sources='+str(len(matches)))
    return matches[0]


class Translator:
    def __init__(self, initial, packet, cycle_consumer=None):
        self.initial=initial
        self.session=packet['session']
        self.baseline=packet['samples'][-1]
        self.last_index=self.baseline['SampleIndex']
        self.sequence=initial['Sequence']
        self.last_phase=self.baseline['Phase']
        self.wall0=time.time()
        self.sim0=self.baseline['SimTime']
        self.offsets={k:initial[k]-self.baseline[k] for k in COUNTERS}
        self.time_offset=initial['SimTime']-self.sim0
        self.last_raw=self.baseline
        self.cycle_tracker=CycleTracker(cfg.EQUIPMENT_ID,packet)
        self.cycle_consumer=cycle_consumer
        self.cycle_boundary=False

    def translate(self, packet):
        if packet['session']!=self.session:
            raise ValueError('Simio restarted; restart the bridge to establish a new session')
        samples=[];events=[]
        for raw in packet['samples']:
            if raw['SampleIndex']<=self.last_index:continue
            if raw['SampleIndex']!=self.last_index+1:
                raise ValueError('Simio sample gap; reconnect instead of replaying old motion')
            self.last_index=raw['SampleIndex']
            s={k:v for k,v in raw.items() if k!='SampleIndex'}
            for k,v in self.offsets.items():s[k]+=v
            s['SimTime']+=self.time_offset
            self.last_raw=raw
            completed=self.cycle_tracker.observe(raw,s)
            if completed is not None:
                self.cycle_boundary=True
                if self.cycle_consumer:self.cycle_consumer(completed)
            if s['Phase']!=self.last_phase:
                events.append({'type':'phase_changed','time':s['SimTime'],'from':self.last_phase,'phase':s['Phase']})
                self.last_phase=s['Phase']
            samples.append(s)
        return samples,events

    def window(self, samples, events):
        now=time.time(); self.sequence+=1
        s=samples[-1]
        return {**s,'Timestamp':now,'TimestampISO':iso(now),
                'StartedISO':iso(self.wall0-self.initial['SimTime']),
                'Sequence':self.sequence,'Session':self.session,'Connection':'ConnectedSimulated',
                'Samples':json.dumps(samples,separators=(',',':')),
                'Events':json.dumps(events,separators=(',',':')),
                'DroppedRecords':self.initial['DroppedRecords']}


def confirm_realtime(path):
    first=read_packet(path); start=time.monotonic()
    time.sleep(3)
    last=read_packet(path); wall=time.monotonic()-start
    elapsed=last['samples'][-1]['SimTime']-first['samples'][-1]['SimTime']
    if last['session']!=first['session'] or not 0.7<=elapsed/wall<=1.3:
        raise ValueError('Simio must run at realtime 1x; accelerated/offline output is not published')
    return last


def run(args):
    path=Path(args.packet) if args.packet else discover_packet()
    packet=confirm_realtime(path)
    if args.check_source:
        print(json.dumps({'source':'Simio','realtime':True,'phase':packet['samples'][-1]['Phase']}))
        return 0
    # Docker uses the explicitly allowed internal AAS hostname; desktop callers
    # retain loopback-only behavior unless internal HTTP is explicitly enabled.
    url=cfg.validate_url(args.aas_url,write=True,local=os.environ.get('PET_ALLOW_INTERNAL_HTTP')!='1')
    writer=AasTwinWriter(url,token=cfg.token())
    initial=writer.prepare()
    # Recipe HTTP requests can take seconds. Establish the native clock baseline
    # only after all blocking startup I/O, otherwise startup latency looks like
    # accelerated simulation and can also exhaust the rolling pose window.
    writer.configure_cycle_target(27.5)
    archive=Outbox(os.environ['PET_ARCHIVE_OUTBOX']) if os.environ.get('PET_ARCHIVE_OUTBOX') else None
    fresh=read_packet(path)
    if fresh['session']!=packet['session']:raise ValueError('Simio restarted during connection')
    packet=fresh
    translator=Translator(initial,packet,lambda event:archive.put('cycle',event) if archive else None)
    writer.start()
    print(json.dumps({'engine':'Simio','packet':str(path),'session':translator.session,'aas':url}),flush=True)
    start=time.monotonic();last_emit=start; samples=[];events=[];result=0
    read_at=start; clock_at=start; clock_sim=packet['samples'][-1]['SimTime']
    try:
        while not args.seconds or time.monotonic()-start<args.seconds:
            if args.stop_file and Path(args.stop_file).exists():break
            try:
                packet=read_packet(path)
            except (PermissionError,json.JSONDecodeError):
                if time.monotonic()-read_at>3:raise ValueError('Simio output unreadable for over 3 seconds')
                time.sleep(0.05);continue
            read_at=time.monotonic()
            new,changes=translator.translate(packet);samples.extend(new);events.extend(changes)
            # Re-check speed throughout the run, including a user's Fast Forward change.
            wall=time.monotonic()-clock_at
            if wall>3:
                native=packet['samples'][-1]['SimTime']-clock_sim
                if not 0.65<=native/wall<=1.35:
                    raise ValueError(f'Simio clock no longer realtime 1x: native={native:.3f}s wall={wall:.3f}s ratio={native/wall:.3f}')
                clock_at=time.monotonic();clock_sim=packet['samples'][-1]['SimTime']
            if (time.monotonic()-last_emit>=1 or translator.cycle_boundary) and samples:
                snapshot=translator.window(samples,events)
                parse_snapshot(snapshot)
                if archive:archive.put('telemetry',telemetry_event(cfg.EQUIPMENT_ID,translator.last_raw,snapshot))
                writer.add_sample(snapshot)
                print(json.dumps({'sim_s':snapshot['SimTime'],'phase':snapshot['Phase'],'produced':snapshot['Produced'],'sequence':snapshot['Sequence']}),flush=True)
                samples=[];events=[];last_emit=time.monotonic()
                translator.cycle_boundary=False
            time.sleep(0.05)
    except KeyboardInterrupt:
        pass
    except (ValueError,OSError) as exc:
        print('Simio disconnected: '+str(exc),file=sys.stderr,flush=True);result=2
    finally:
        # Retain the last real timestamp; never issue a fresh heartbeat for a frozen source.
        if not writer.close(timeout=10):result=3
        if archive:archive.close()
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--aas-url',default='http://localhost:8081')
    p.add_argument('--packet',help='optional native PETTelemetry JSON path; default discovers fresh files in LOCALAPPDATA/PETSimio/Live')
    p.add_argument('--seconds',type=float,default=0)
    p.add_argument('--stop-file')
    p.add_argument('--check-source',action='store_true',help='verify realtime Simio without writing AAS')
    args=p.parse_args()
    try:return run(args)
    except (ValueError,RuntimeError,OSError) as exc:
        print(str(exc),file=sys.stderr);return 1

if __name__=='__main__':sys.exit(main())
