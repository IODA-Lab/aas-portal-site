import copy
import json
import time
import unittest
from pathlib import Path
import pet_config as cfg
from aas_core import AasHttp,AasError,b64,encode_path,value_body,fmt
from aas_equipment import AasTwinWriter,PetProfile,parse_snapshot,iso
from tools.make_twin_aasx import initial_snapshot
from tools.aas_model import at,read_aasx,inventory
from tests.fake_aas import FakeAAS,set_value
from aas_seed.seed import seed
from model.pet_process import PetProcess

def environment():return json.loads((cfg.ROOT/'aas/PET_Twin.environment.json').read_text(encoding='utf-8'))
def snapshot(n):
    s=initial_snapshot();s.update(Sequence=n,SimTime=float(n),Timestamp=time.time(),TimestampISO=iso(time.time()),Session='test',Connection='ConnectedSimulated',StartedISO=iso(time.time()-n));return s
def waitfor(fn,timeout=8):
    until=time.monotonic()+timeout
    while time.monotonic()<until:
        if fn():return
        time.sleep(.03)
    raise AssertionError('condition timed out')

class AasTests(unittest.TestCase):
    def test_cycle_target_sync_preserves_metadata_and_counters(self):
        with FakeAAS(environment()) as server:
            w=AasTwinWriter(server.url,token='pet-test-token');sid=w.profile.ids['ProcessParameters']
            path='Processes.Process__00__.ProcessParameters.CycleTimeTarget'
            before=w.http.get(sid,path)
            with self.assertRaises(RuntimeError):w.configure_cycle_target(27.5)
            w.prepare();current=w.http.get_value(w.profile.ids['TwinRuntime'],'Current')
            w.configure_cycle_target(27.5);after=w.http.get(sid,path)
            self.assertEqual(after,{**before,'value':'PT27.5S'})
            w.configure_cycle_target(27.5);self.assertEqual(w.http.get(sid,path),after)
            self.assertEqual(w.http.get_value(w.profile.ids['TwinRuntime'],'Current'),current);w.http.close()
    def test_encoding(self):
        self.assertNotIn('=',b64('https://test/사출'))
        self.assertIn('%5B0%5D',encode_path('/A.B[0]/$value'))
    def test_types(self):
        self.assertEqual(value_body({'x':1,'flag':True,'items':[1,2]}),{'x':'1','flag':'true','items':['1','2']})
        self.assertEqual(fmt(2,'xs:integer'),'2')
        with self.assertRaises(ValueError):fmt(float('nan'))
    def test_auth_and_shapes(self):
        with FakeAAS(environment()) as server:
            m=cfg.manifest();id=m['submodels']['TwinRuntime'];h=AasHttp(server.url,token='bad')
            with self.assertRaises(AasError) as ex:h.patch_value(id,'Current',snapshot(1))
            self.assertEqual(ex.exception.status,401);h.close()
            h=AasHttp(server.url,token='pet-test-token')
            with self.assertRaises(AasError):h.patch_value(id,'Current',{'Sequence':2})
            h.patch_value(id,'Current',snapshot(1));self.assertEqual(parse_snapshot(h.get_value(id,'Current'))['Sequence'],1);h.close()
    def test_sml(self):
        el={'modelType':'SubmodelElementList','value':[{'modelType':'Property','valueType':'xs:integer','value':'1'}]}
        set_value(el,['2']);self.assertEqual(el['value'][0]['value'],'2')
        with self.assertRaises(ValueError):set_value(el,['2','3'])
    def test_mapping_type_unit_and_semantics(self):
        p=PetProfile();od=p.models['OperationalData'];seen=0
        for m in p.mapping:
            e=at(od,m['path']);self.assertEqual(e['valueType'],m['valueType']);self.assertEqual(e['semanticId'],m['semanticId'])
            if m['status']=='MAPPED_SIMULATION':seen+=1
        self.assertEqual(seen,14)
        self.assertEqual(next(x['unit'] for x in p.mapping if x['engine_key']=='InjectionPressure'),'bar')
        self.assertFalse(any(x['engine_key']=='BarrelTemperature' for x in p.mapping))
    def test_seed_idempotency_and_partial_refusal(self):
        env=environment()
        with FakeAAS() as server:
            h=AasHttp(server.url,token='pet-test-token');self.assertEqual(seed(h,env),'CREATED');self.assertEqual(seed(h,env),'SKIP_ALREADY_PRESENT')
            del server.data['submodels'][env['submodels'][0]['id']]
            with self.assertRaisesRegex(RuntimeError,'PARTIAL_SEED'):seed(h,env)
            h.close()
    def test_writer_history_dedupe_shutdown_restart(self):
        with FakeAAS(environment()) as server:
            w=AasTwinWriter(server.url,token='pet-test-token',flush_s=.1);w.prepare();w.start()
            w.add_sample(snapshot(1));self.assertFalse(w.add_sample(snapshot(1)))
            waitfor(lambda:w.stats()['flushed_sequence']==1)
            self.assertTrue(w.close());self.assertEqual(w.stats()['errors'],0)
            h=AasHttp(server.url);sid=w.profile.ids['TwinRuntime'];cur=parse_snapshot(h.get_value(sid,'Current'))
            self.assertEqual(cur['Connection'],'Disconnected');self.assertEqual(cur['Sequence'],1)
            hist=h.get_value(sid,'History');self.assertEqual(sum(int(v['Sequence'])>0 for v in hist.values()),1)
            records=h.get(w.profile.ids['TimeSeries'],'Segments.InternalSegment.Records');r=records['value'][0]
            self.assertEqual(next(c['value'] for c in r['value'] if c['idShort']=='Time'),'1')
            self.assertNotIn('value',next(c for c in r['value'] if c['idShort']=='MeltTemperatureActual'))
            w2=AasTwinWriter(server.url,token='pet-test-token');self.assertEqual(w2.prepare()['Sequence'],1);w2.http.close();h.close()
    def test_outage_nonblocking_recovery(self):
        with FakeAAS(environment()) as server:
            w=AasTwinWriter(server.url,token='pet-test-token',flush_s=.1,timeout=.15);w.prepare();w.start();server.fail_status=503
            t=time.perf_counter()
            for n in range(1,75):w.add_sample(snapshot(n))
            self.assertLess(time.perf_counter()-t,.5);waitfor(lambda:w.stats()['errors']>0)
            self.assertGreater(w.stats()['records_dropped'],0)
            server.fail_status=0;waitfor(lambda:w.stats()['flushed_sequence']==74)
            self.assertTrue(w.close());self.assertEqual(len(w.history),60)
    def test_restart_recovers_current_ahead_and_does_not_count_persisted_loss(self):
        env=environment();rt=next(s for s in env['submodels'] if s['idShort']=='TwinRuntime')
        s=snapshot(60);s['Connection']='Disconnected';s['DroppedRecords']=3
        set_value(at(rt,'Current'),value_body(s))
        with FakeAAS(env) as server:
            w=AasTwinWriter(server.url,token='pet-test-token');w.prepare()
            self.assertEqual(w.history[59]['Sequence'],60)
            self.assertFalse(w.add_sample(snapshot(60)))
            w.add_sample(snapshot(120))
            self.assertEqual(w.stats()['records_dropped'],3)
            w.http.close()
    def test_auth_failure_count_and_recovery(self):
        with FakeAAS(environment()) as server:
            w=AasTwinWriter(server.url,token='pet-test-token',flush_s=.1);w.prepare();w.start();server.token='rotated';w.add_sample(snapshot(1))
            waitfor(lambda:w.stats()['auth_failures']>0);server.token='pet-test-token';waitfor(lambda:w.stats()['flushed_sequence']==1);self.assertTrue(w.close())
    def test_network_timeout_reconnect(self):
        with FakeAAS(environment()) as server:
            w=AasTwinWriter(server.url,token='pet-test-token',flush_s=.1,timeout=.05);w.prepare();w.start();server.delay=.2;w.add_sample(snapshot(1))
            waitfor(lambda:w.http.n_conn_err>0);server.delay=0;waitfor(lambda:w.stats()['flushed_sequence']==1);self.assertTrue(w.close())
    def test_active_writer_refused(self):
        env=environment();rt=next(s for s in env['submodels'] if s['idShort']=='TwinRuntime');set_value(at(rt,'Current'),value_body(snapshot(1)))
        with FakeAAS(env) as server:
            w=AasTwinWriter(server.url,token='pet-test-token')
            with self.assertRaisesRegex(RuntimeError,'active writer'):w.prepare()
            w.http.close()
    def test_remote_no_http_or_missing_address(self):
        for url in ['', 'http://example.org:8081','https://u:p@example.org']:
            with self.assertRaises(ValueError):cfg.validate_url(url,write=True)

if __name__=='__main__':unittest.main()
