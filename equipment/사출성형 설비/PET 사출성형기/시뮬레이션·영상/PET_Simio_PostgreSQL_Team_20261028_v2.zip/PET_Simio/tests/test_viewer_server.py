import io
import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from urllib.error import HTTPError, URLError
from tools.serve_viewer import PublicHandler


class ViewerServerTests(unittest.TestCase):
    def handler(self,path='/api/current'):
        h=PublicHandler.__new__(PublicHandler)
        h.path=path;h.server=SimpleNamespace(current_url='http://127.0.0.1:8081/fixed-current')
        h.wfile=io.BytesIO();h.headers_out={}
        h.send_response=lambda code:setattr(h,'code',code)
        h.send_error=lambda code:setattr(h,'code',code)
        h.send_header=lambda k,v:h.headers_out.update({k:v})
        h.end_headers=lambda:None
        return h

    def test_only_fixed_current_endpoint_is_proxied(self):
        h=self.handler('/api/current?url=http://example.com/private')
        with patch('tools.serve_viewer.urlopen',return_value=io.BytesIO(b'{"Sequence":1}')) as request:
            h.do_GET()
        self.assertEqual(request.call_args.args[0].full_url,h.server.current_url)
        self.assertEqual(h.code,200)
        self.assertEqual(h.headers_out['Cache-Control'],'no-store')

    def test_upstream_failures_do_not_become_empty_success(self):
        for error,code in [(HTTPError('url',404,'missing',{},None),502),(URLError('offline'),503)]:
            h=self.handler()
            with patch('tools.serve_viewer.urlopen',side_effect=error):h.do_GET()
            self.assertEqual(h.code,code)
            self.assertIn('error',json.loads(h.wfile.getvalue()))

    def test_invalid_json_is_failure(self):
        h=self.handler()
        with patch('tools.serve_viewer.urlopen',return_value=io.BytesIO(b'not json')):h.do_GET()
        self.assertEqual(h.code,503)

    def test_private_files_and_traversal_are_blocked(self):
        for path in ('/equipment.env','/viewer/../equipment.env','/viewer/%2e%2e/aas/twin_manifest.json','/api/shells'):
            h=self.handler(path);h.do_GET();self.assertEqual(h.code,404,path)


if __name__=='__main__':unittest.main()
