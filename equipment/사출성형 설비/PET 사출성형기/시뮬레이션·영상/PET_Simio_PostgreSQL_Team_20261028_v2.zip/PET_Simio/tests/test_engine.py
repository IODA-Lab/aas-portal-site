import copy
import math
import unittest
from model.pet_process import PetProcess
from kpi import compute
from rul_model import predict

def advance(e,seconds):
    for _ in range(round(seconds*e.hz)): e.step()
    return e.state()

class EngineTests(unittest.TestCase):
    def test_complete_phase_order(self):
        e=PetProcess(); phases=[e.phase]
        while e.completed_cycles<2:
            e.step()
            for ev in e.events:
                if ev['type']=='phase_changed': phases.append(ev['phase'])
        self.assertEqual(phases[:9],[x['name'] for x in e.steps]);self.assertEqual(phases[9],'Clamp')
        self.assertEqual(e.completed_cycles,2);self.assertEqual(e.produced,48)
    def test_interlocks_and_ranges(self):
        e=PetProcess()
        for _ in range(3600):
            s=e.step()
            self.assertLessEqual(s['MoldOpen'],500);self.assertGreaterEqual(s['MoldOpen'],0)
            self.assertTrue(6-1e-4<=s['ScrewPosition']<=120+1e-4)
            if s['Injection'] or s['Holding']: self.assertEqual(s['MoldOpen'],0)
            if s['MoldOpen']>0: self.assertEqual(s['InjectionPressure'],0)
            self.assertEqual(s['Produced'],s['Good']+s['Reject'])
            self.assertTrue(all(math.isfinite(v) for v in s.values() if isinstance(v,(int,float))))
    def test_cooling_and_metering_overlap(self):
        e=PetProcess(); states=[]
        for _ in range(1400):
            s=e.step()
            if s['Cooling'] and s['Metering']: states.append(s)
        self.assertGreater(len(states),250);self.assertGreater(states[-1]['ScrewPosition'],states[0]['ScrewPosition']);self.assertEqual(states[0]['MoldOpen'],0)
    def test_slow_meter_extends_cooling(self):
        c=PetProcess().cfg;c['recipe']['metering_s']=8;e=PetProcess(scenario=c)
        self.assertEqual(e.duration(5),8);advance(e,sum(e.duration(i) for i in range(9))+.5);self.assertEqual(e.completed_cycles,1)
    def test_deterministic_and_read_only_telemetry(self):
        a,b=PetProcess(seed=42),PetProcess(seed=42)
        for i in range(2500):
            a.step();a.telemetry();a.state();b.step()
        self.assertEqual(a.telemetry(123),b.telemetry(123))
    def test_dt_partition(self):
        a,b=PetProcess(),PetProcess();a.step(1)
        for _ in range(60):b.step()
        self.assertEqual(a.state(),b.state())
    def test_normal_stop_and_restart(self):
        e=PetProcess();advance(e,9);e.request_stop();advance(e,30)
        self.assertEqual(e.mode,'Stopped');self.assertEqual(e.completed_cycles,1)
        before=e.produced;advance(e,5);self.assertEqual(e.produced,before)
        e.start();advance(e,28);self.assertEqual(e.completed_cycles,2)
    def test_standby_freezes_motion(self):
        e=PetProcess();advance(e,8);e.pause();old=e.screw;phase=e.phase;advance(e,2)
        self.assertEqual(e.mode,'Standby');self.assertEqual(e.screw,old);self.assertEqual(e.phase,phase)
        e.start();advance(e,2);self.assertNotEqual(e.phase,phase)
    def test_alarms(self):
        for profile,code in [('overpressure','OVERPRESSURE'),('overheat','BARREL_OVERHEAT'),('cooling_failure','COOLING_FAILURE'),('interlock','SAFETY_INTERLOCK')]:
            with self.subTest(profile=profile):
                e=PetProcess(scenario=profile);advance(e,30);self.assertEqual(e.mode,'Alarm');self.assertEqual(e.alarm,code);self.assertEqual(e.state()['InjectionPressure'],0)
    def test_alarm_reset_and_production(self):
        e=PetProcess(scenario='interlock');advance(e,11)
        with self.assertRaises(RuntimeError):e.clear_alarm()
        advance(e,6);e.clear_alarm();e.start();advance(e,28);self.assertEqual(e.completed_cycles,1)
    def test_restart_counters(self):
        e=PetProcess();advance(e,35);s=e.state();r=PetProcess(init=s);advance(r,35)
        self.assertEqual(r.produced,48);self.assertEqual(r.completed_cycles,2);self.assertGreater(r.t,e.t)
    def test_bad_parameters(self):
        for key,value in [('cavities',0),('metering_s',-1),('screw_stroke_mm',2)]:
            c=PetProcess().cfg;c['recipe'][key]=value
            with self.assertRaises(ValueError):PetProcess(scenario=c)
        with self.assertRaises(ValueError):PetProcess().step(float('nan'))
    def test_kpi(self):
        e=PetProcess();advance(e,35);s=e.state();k=compute(s)
        self.assertAlmostEqual(k['QualityRate']+k['RejectRate'],1);self.assertAlmostEqual(k['MeanCycleTime'],27.5);self.assertLessEqual(k['Utilization'],1.00001)
    def test_no_fabricated_rul(self):self.assertIsNone(predict()['remaining_useful_life_h'])
    def test_conveyor_overlaps_next_cycle(self):
        e=PetProcess();s=advance(e,35)
        self.assertEqual(s['Phase'],'Clamp');self.assertGreater(s['ConveyorProgress'],0)
    def test_robot_operations_have_time_to_complete(self):
        e=PetProcess();changes={}
        while e.completed_cycles<1:
            e.step()
            for ev in e.events:
                if ev['type']=='phase_changed':changes[ev['phase']]=ev['time']
        self.assertAlmostEqual(changes['Transfer']-changes['Eject'],6)
        self.assertAlmostEqual(changes['Clamp']-changes['Transfer'],8)
        self.assertEqual(e.produced,24);self.assertAlmostEqual(e.last_cycle_s,27.5)

if __name__=='__main__':unittest.main()
