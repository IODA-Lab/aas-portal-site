import copy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from cycle_archive import CycleTracker,Outbox,flush_once
from simio_bridge import Translator
from tests.test_simio_bridge import packet
from tools.make_twin_aasx import initial_snapshot


def cycle_packet(index=10,cycle=2,produced=48,good=47,phase='Clamp'):
    p=packet(index,produced=produced)
    p['samples'][0].update(CompletedCycles=cycle,Good=good,Reject=produced-good,Phase=phase,CycleTime=27.5)
    return p


class CycleArchiveTests(unittest.TestCase):
    def test_cycle_completion_and_duplicate_samples(self):
        first=cycle_packet();events=[]
        t=Translator(initial_snapshot(),first,events.append)
        p=cycle_packet(11,3,72,70)
        t.translate(p);t.translate(p)
        self.assertEqual(len(events),1)
        self.assertEqual(events[0]['batch_produced'],24)
        self.assertEqual(events[0]['batch_good'],23)
        self.assertEqual(events[0]['batch_reject'],1)
        self.assertTrue(t.cycle_boundary)
        self.assertFalse(events[0]['observed_full_cycle'])

    def test_attach_after_ejection_does_not_invent_batch_quality(self):
        p=cycle_packet(10,2,72,70,'Transfer')
        tracker=CycleTracker('PET',p)
        raw=cycle_packet(11,3,72,70)['samples'][0]
        first=tracker.observe(raw,raw)
        self.assertIsNone(first['batch_good'])
        raw=cycle_packet(12,4,96,94)['samples'][0]
        second=tracker.observe(raw,raw)
        self.assertEqual(second['batch_good'],24)
        self.assertTrue(second['observed_full_cycle'])

    def test_skipped_cycle_is_not_fabricated(self):
        tracker=CycleTracker('PET',cycle_packet())
        raw=cycle_packet(11,4,96,94)['samples'][0]
        with self.assertRaisesRegex(ValueError,'gap'):tracker.observe(raw,raw)

    def test_sqlite_survives_reopen_and_ignores_repeated_event(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'pending.sqlite3'
            q=Outbox(path)
            e={'equipment_id':'PET','session':'simio-run','sample_index':10}
            q.put('telemetry',e);q.put('telemetry',e);q.close()
            q=Outbox(path)
            self.assertEqual(q.count(),1)
            q.close()

    def test_commit_before_ack_and_retry_after_crash(self):
        class Sink:
            def __init__(self):self.ids=set();self.down=True
            def write(self,rows):
                if self.down:raise ConnectionError('test outage')
                self.ids.update(row[0] for row in rows)
        with tempfile.TemporaryDirectory() as tmp:
            q=Outbox(Path(tmp)/'queue.db');sink=Sink()
            e={'equipment_id':'PET','session':'simio-run','sample_index':10}
            q.put('telemetry',e)
            with self.assertRaises(ConnectionError):flush_once(q,sink)
            self.assertEqual(q.count(),1)
            sink.down=False
            with patch.object(q,'acknowledge',side_effect=OSError('simulated crash after commit')):
                with self.assertRaises(OSError):flush_once(q,sink)
            self.assertEqual(q.count(),1)
            self.assertEqual(len(sink.ids),1)
            self.assertEqual(flush_once(q,sink),1)
            self.assertEqual(len(sink.ids),1)
            self.assertEqual(q.count(),0)
            q.close()

    def test_new_session_allows_same_cycle_number(self):
        with tempfile.TemporaryDirectory() as tmp:
            q=Outbox(Path(tmp)/'queue.db')
            e={'equipment_id':'PET','session':'simio-one','cycle_number':1}
            q.put('cycle',e);e['session']='simio-two';q.put('cycle',e)
            self.assertEqual(q.count(),2);q.close()


if __name__=='__main__':unittest.main()
