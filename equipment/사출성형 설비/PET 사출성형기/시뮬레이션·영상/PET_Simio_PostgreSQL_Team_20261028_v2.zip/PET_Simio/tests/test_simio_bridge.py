import copy
import json
import tempfile
import time
import unittest
from pathlib import Path
from tools.make_twin_aasx import initial_snapshot
from simio_bridge import Translator, read_packet, REQUIRED
from aas_equipment import parse_snapshot


def packet(index=10, session='simio-test', produced=24):
    defaults=initial_snapshot()
    sample={k:v for k,v in defaults.items() if k in REQUIRED}
    sample.update(SampleIndex=index,SimTime=index*0.05,Cavities=24,Produced=produced,Good=produced,Reject=0)
    return {'engine':'Simio','model':'PET_24Cavity_27_5s','session':session,'written_at':time.time(),'samples':[sample]}


class SimioBridgeTests(unittest.TestCase):
    def test_resume_counts_and_schema(self):
        initial=initial_snapshot();initial.update(Produced=240,Good=239,Reject=1,Sequence=99,SimTime=300.0)
        translator=Translator(initial,packet())
        samples,events=translator.translate(packet(11,produced=48))
        result=translator.window(samples,events)
        self.assertEqual(result['Produced'],264)
        self.assertEqual(result['Good'],263)
        self.assertEqual(result['Reject'],1)
        self.assertEqual(result['Sequence'],100)
        self.assertAlmostEqual(result['SimTime'],300.05)
        parse_snapshot(result)

    def test_no_duplicate_or_invented_pose(self):
        t=Translator(initial_snapshot(),packet())
        self.assertEqual(t.translate(packet()),([],[]))
        with self.assertRaisesRegex(ValueError,'gap'):t.translate(packet(12))

    def test_restarted_simio_requires_new_session(self):
        t=Translator(initial_snapshot(),packet())
        with self.assertRaisesRegex(ValueError,'restarted'):t.translate(packet(11,'simio-new'))

    def test_stale_and_invalid_packets_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'packet.json'
            data=packet();path.write_text(json.dumps(data),encoding='utf8')
            self.assertEqual(read_packet(path)['engine'],'Simio')
            with self.assertRaisesRegex(ValueError,'stale'):read_packet(path,now=data['written_at']+4)
            data['samples'][0]['Produced']+=1
            path.write_text(json.dumps(data),encoding='utf8')
            with self.assertRaisesRegex(ValueError,'counter'):read_packet(path)

if __name__=='__main__':unittest.main()
