import copy
import json
import unittest
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from grafana.make_dashboard import build
from tools.local_stack_check import publication_state
from tools.make_twin_aasx import initial_snapshot
from aas_seed.seed import seed
from aas_core import b64
import pet_config as cfg


class GrafanaTests(unittest.TestCase):
    def test_viewer_cache_version_and_transport_configuration(self):
        d=build('http://test-aas:8081','urn:test','custom-uid')
        panel=next(p for p in d['panels'] if p['id']==18)
        params=parse_qs(urlsplit(panel['options']['iframeURL']).query)
        self.assertEqual(params['datasource'],['custom-uid'])
        self.assertEqual(params['base'],['http://test-aas:8081'])
        self.assertEqual(params['runtime'],['urn:test'])
        version=params['v'][0]
        viewer=Path(__file__).resolve().parents[1]/'viewer'
        self.assertIn('app.js?v='+version,(viewer/'index.html').read_text(encoding='utf-8'))
        self.assertIn('grafana_transport.js?v='+version,(viewer/'app.js').read_text(encoding='utf-8'))
    def test_3d_panel_and_existing_panels_do_not_overlap(self):
        d=build('http://aas-env:8081','urn:test')
        panel=next(p for p in d['panels'] if p['id']==18)
        self.assertEqual(panel['type'],'innius-video-panel')
        self.assertIn('mode=live',panel['options']['iframeURL'])
        self.assertEqual(panel['targets'],[])
        for p in d['panels']:
            if p['id']!=18:self.assertGreaterEqual(p['gridPos']['y'],14)
        for url in ('javascript:alert(1)','http://user:secret@example.com/'):
            with self.assertRaises(ValueError):build('http://aas-env:8081','urn:test',viewer_url=url)
    def test_uid_and_reused_queries(self):
        for uid in ('aas-infinity','custom-uid'):
            d=build('http://aas-env:8081',cfg.manifest()['submodels']['TwinRuntime'],uid)
            urls=[t for p in d['panels'] for t in p.get('targets',[]) if 'url' in t]
            self.assertEqual(len(urls),2)
            self.assertTrue(all(t['datasource']['uid']==uid for t in urls))
            self.assertTrue(all('/submodel-elements/' in t['url'] and t['url'].endswith('/%24value') for t in urls))
    def test_empty_history_is_null_point_not_jsonata_no_results(self):
        d=build('http://aas-env:8081','urn:test')
        history=next(p for p in d['panels'] if p['id']==2)['targets'][0]['root_selector']
        self.assertIn('$count($rows)>0?',history);self.assertIn('"BarrelTemperature":null',history)
        self.assertNotIn('$assert',json.dumps(d)) # installed Infinity Go parser does not implement it
    def test_publication_state_boundaries(self):
        s=initial_snapshot();self.assertEqual(publication_state(s,100),'NO_DATA')
        s.update(Sequence=1,Timestamp=100,Connection='ConnectedSimulated')
        for now,state in [(100,'LIVE'),(104.999,'LIVE'),(105,'STALE'),(97,'CLOCK_SKEW')]:self.assertEqual(publication_state(s,now),state)
        s['Connection']='Disconnected';self.assertEqual(publication_state(s,100),'STOPPED')
    def test_dashboard_keeps_query_errors_separate(self):
        d=build('http://aas-env:8081','urn:test');selector=next(p for p in d['panels'] if p['id']==1)['targets'][0]['root_selector']
        for code in ('NO_DATA','STOPPED','CLOCK_SKEW','STALE','LIVE'):self.assertIn(code,selector)
        self.assertIn('$number("PET Current schema mismatch")',selector)
        self.assertNotIn('연결 끊김 / 데이터 없음',json.dumps(d,ensure_ascii=False))


class RepositorySeedTests(unittest.TestCase):
    class HTTP:
        def __init__(self,objects=None):self.objects=objects or {};self.posts=[]
        def request(self,method,path,body=None,retries=None):
            if method=='GET':return (200,self.objects[path]) if path in self.objects else (404,{})
            self.posts.append(path);self.objects[path+'/'+b64(body['id'])]=copy.deepcopy(body);return 201,{}
    def env(self):return {'assetAdministrationShells':[{'id':'urn:aas'}],'submodels':[{'id':'urn:sm'}],'conceptDescriptions':[{'id':'urn:cd','idShort':'Test','modelType':'ConceptDescription'}]}
    def test_cd_upload_and_idempotency(self):
        h=self.HTTP();e=self.env()
        self.assertEqual(seed(h,e,concept_descriptions=True),'REPOSITORY_CREATED_ATTACHMENTS_NOT_UPLOADED')
        self.assertEqual(h.posts,['/concept-descriptions','/submodels','/shells'])
        self.assertEqual(seed(h,e,concept_descriptions=True),'SKIP_ALREADY_PRESENT');self.assertEqual(len(h.posts),3)
    def test_conflicting_cd_blocks_all_writes(self):
        h=self.HTTP({'/concept-descriptions/'+b64('urn:cd'):{'id':'urn:cd','idShort':'Different'}})
        with self.assertRaisesRegex(RuntimeError,'CD_CONFLICT'):seed(h,self.env(),concept_descriptions=True)
        self.assertEqual(h.posts,[])
    def test_existing_equal_cd_is_not_overwritten(self):
        e=self.env();h=self.HTTP({'/concept-descriptions/'+b64('urn:cd'):{'id':'urn:cd','idShort':'Test','description':[]}})
        seed(h,e,concept_descriptions=True);self.assertEqual(h.posts,['/submodels','/shells'])


if __name__=='__main__':unittest.main()

