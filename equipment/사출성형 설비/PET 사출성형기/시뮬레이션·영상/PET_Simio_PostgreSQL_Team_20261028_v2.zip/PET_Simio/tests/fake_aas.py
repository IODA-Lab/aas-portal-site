"""Strict, loopback-only AAS repository test double; never a standards certification."""
import argparse
import base64
import copy
import json
import math
import re
import threading
import time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import unquote,urlsplit
from aas_core import element_value,path_tokens


def decode(s): return base64.urlsafe_b64decode(s+'='*((-len(s))%4)).decode()


def lookup(sm,path):
    elems=sm.get('submodelElements',[]); cur=sm
    for token in path_tokens(path):
        cur=elems[token] if isinstance(token,int) else next((e for e in elems if e.get('idShort')==token),None)
        if cur is None: raise KeyError(path)
        elems=cur.get('value',[])
    return cur


def set_value(e,v):
    mt=e['modelType']
    if mt=='Property':
        if not isinstance(v,str): raise ValueError('BaSyx property values must be lexical strings')
        vt=e['valueType']
        if vt in ('xs:integer','xs:int','xs:long') and not re.fullmatch(r'-?\d+',v): raise ValueError('invalid integer')
        if vt in ('xs:double','xs:float','xs:decimal') and not math.isfinite(float(v)): raise ValueError('invalid number')
        if vt=='xs:boolean' and v not in ('true','false'): raise ValueError('invalid boolean')
        e['value']=v
    elif mt=='SubmodelElementCollection':
        if set(v)!={x['idShort'] for x in e['value']}: raise ValueError('SMC PATCH requires complete shape')
        for c in e['value']: set_value(c,v[c['idShort']])
    elif mt=='SubmodelElementList':
        if len(v)!=len(e['value']): raise ValueError('SML shape')
        for c,x in zip(e['value'],v): set_value(c,x)
    else: raise ValueError('unsupported ValueOnly type')


class FakeAAS:
    def __init__(self,env=None,token='pet-test-token',port=0,host='127.0.0.1'):
        self.data={'shells':{},'submodels':{}}; self.token=token
        if env:
            self.data['shells']={s['id']:copy.deepcopy(s) for s in env['assetAdministrationShells']}
            self.data['submodels']={s['id']:copy.deepcopy(s) for s in env['submodels']}
        self.delay=0; self.fail_status=0; self.requests=[]; self.lock=threading.Lock()
        owner=self
        class Handler(BaseHTTPRequestHandler):
            protocol_version='HTTP/1.1'
            def handle(self):
                try:super().handle()
                except (ConnectionResetError,ConnectionAbortedError,BrokenPipeError):pass
            def log_message(self,*args): pass
            def respond(self,status,body=None):
                b=json.dumps(body,ensure_ascii=False).encode() if body is not None else b''
                self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.send_header('Access-Control-Allow-Origin','*'); self.end_headers()
                try: self.wfile.write(b)
                except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError): pass
            def do_OPTIONS(self):
                self.send_response(204); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Methods','GET,POST,PUT,PATCH,OPTIONS'); self.send_header('Access-Control-Allow-Headers','Authorization,Content-Type'); self.send_header('Content-Length','0'); self.end_headers()
            def serve(self):
                size=int(self.headers.get('Content-Length',0)); raw=self.rfile.read(size) if size else b''
                if owner.delay: time.sleep(owner.delay)
                if owner.fail_status: return self.respond(owner.fail_status,{'error':'injected outage'})
                if self.command!='GET' and self.headers.get('Authorization')!='Bearer '+owner.token: return self.respond(401,{'error':'unauthorized'})
                try:
                    body=json.loads(raw) if raw else None
                    parts=unquote(urlsplit(self.path).path).strip('/').split('/')
                    kind=parts[0]
                    if kind not in owner.data: return self.respond(404,{})
                    with owner.lock:
                        owner.requests.append((self.command,self.path,size))
                        store=owner.data[kind]
                        if len(parts)==1:
                            if self.command=='GET': return self.respond(200,{'result':list(store.values())})
                            if self.command=='POST':
                                if body['id'] in store: return self.respond(409,{})
                                store[body['id']]=body; return self.respond(201)
                        obj=store[decode(parts[1])]
                        if len(parts)==2: return self.respond(200,obj)
                        if parts[2]=='$value': return self.respond(200,{e['idShort']:element_value(e) for e in obj['submodelElements']})
                        if parts[2]!='submodel-elements': return self.respond(404,{})
                        target=lookup(obj,parts[3]); value_only=len(parts)==5 and parts[4]=='$value'
                        if self.command=='GET': return self.respond(200,element_value(target) if value_only else target)
                        if self.command=='PATCH' and value_only:
                            candidate=copy.deepcopy(target); set_value(candidate,body); target.clear(); target.update(candidate); return self.respond(204)
                        if self.command=='PUT':
                            if body['idShort']!=target['idShort'] or body['modelType']!=target['modelType']: raise ValueError('PUT identity mismatch')
                            target.clear(); target.update(body); return self.respond(204)
                        return self.respond(405,{})
                except KeyError: return self.respond(404,{})
                except (ValueError,TypeError,IndexError): return self.respond(400,{'error':'invalid body/path'})
            do_GET=serve; do_POST=serve; do_PUT=serve; do_PATCH=serve
        self.server=ThreadingHTTPServer((host,port),Handler); self.server.daemon_threads=True
        self.url='http://127.0.0.1:'+str(self.server.server_port); self.thread=None
    def __enter__(self):
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start(); return self
    def __exit__(self,*args): self.server.shutdown(); self.server.server_close(); self.thread.join(2)


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--port',type=int,default=8081); p.add_argument('--host',default='127.0.0.1'); p.add_argument('--environment',default='aas/PET_Twin.environment.json'); a=p.parse_args()
    from pathlib import Path
    import os
    with FakeAAS(json.loads(Path(a.environment).read_text(encoding='utf-8')),token=os.environ.get('PET_AAS_TOKEN','pet-test-token'),port=a.port,host=a.host) as server:
        print('FAKE AAS TEST SERVER '+server.url,flush=True)
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt: pass
