import copy
import hashlib
import json
import unittest
from pathlib import Path
import pet_config as cfg
from tools.aas_model import read_aasx,walk,sem,at
from tools.validate_aas import structural
from tools.make_twin_aasx import initial_snapshot
from model.pet_process import PetProcess
from grafana.make_dashboard import build

class ContractTests(unittest.TestCase):
    def test_instance_isolation_and_preservation(self):
        reference=next((cfg.ROOT/'aas/reference').glob('*.aasx'));src,_=read_aasx(reference);twin,_=read_aasx(cfg.ROOT/'aas/PET_Twin.aasx');m=cfg.manifest()
        self.assertEqual(hashlib.sha256(reference.read_bytes()).hexdigest(),m['source_sha256'])
        self.assertEqual(src['assetAdministrationShells'][0]['assetInformation']['assetKind'],'Type')
        self.assertEqual(twin['assetAdministrationShells'][0]['assetInformation']['assetKind'],'Instance')
        self.assertEqual(structural(twin),[])
        for old in src['submodels']:
            new=next(s for s in twin['submodels'] if s['id']==m['id_map'][old['id']])
            self.assertNotEqual(old['id'],new['id']);self.assertEqual(old['semanticId'],new['semanticId']);self.assertEqual(new['kind'],'Instance')
            for path,e in walk(old.get('submodelElements',[])):
                if path.startswith('Segments.InternalSegment.Records.Record'):continue
                other=at(new,path);self.assertIsNotNone(other);self.assertEqual(e.get('semanticId'),other.get('semanticId'))
        self.assertEqual(src['conceptDescriptions'],twin['conceptDescriptions'][:len(src['conceptDescriptions'])])
        for cd in twin['conceptDescriptions'][len(src['conceptDescriptions']):]:
            for ds in cd['embeddedDataSpecifications']:
                self.assertEqual(ds['dataSpecification']['keys'][0]['value'],'https://admin-shell.io/DataSpecificationTemplates/DataSpecificationIec61360/3')
                content=ds['dataSpecificationContent']
                self.assertTrue(any(t['language']=='en' for t in content['definition']))
                if content['dataType'].endswith('_MEASURE'):self.assertTrue(content.get('unit'))
    def test_unmodeled_values_absent_and_pvm_keys_preserved(self):
        env,_=read_aasx(cfg.ROOT/'aas/PET_Twin.aasx');by={s['idShort']:s for s in env['submodels']}
        for _,e in walk(by['PredictiveMaintenance']['submodelElements']):
            if e.get('modelType')=='Property':self.assertNotIn('value',e)
        pvm=by['ProcessVariablesForManufacturingKPICalculation']
        self.assertTrue(any(e.get('value')=='PQ' for _,e in walk(pvm['submodelElements'])))
        self.assertTrue(all('value' not in e for _,e in walk(pvm['submodelElements']) if e.get('idShort')=='currentValue'))
    def test_all_demo_frames_match_engine_contract(self):
        try:import jsonschema
        except ImportError:self.skipTest('install requirements.txt for schema validation')
        sc=json.loads((cfg.ROOT/'contract/engine_api.schema.json').read_text(encoding='utf-8'));v=jsonschema.Draft202012Validator(sc)
        demo=json.loads((cfg.ROOT/'model/public/demo_cycle.json').read_text(encoding='utf-8'))
        for frame in demo['frames']:v.validate(frame)
        for name,path in [('runtime_smc',None),('process_public','process_public.json'),('demo_cycle','demo_cycle.json')]:
            obj=initial_snapshot() if path is None else json.loads((cfg.ROOT/'model/public'/path).read_text(encoding='utf-8'))
            jsonschema.validate(obj,json.loads((cfg.ROOT/'contract'/f'{name}.schema.json').read_text(encoding='utf-8')))
    def test_dashboard_paths_and_request_sharing(self):
        m=cfg.manifest();d=build('http://aas-env:8081',m['submodels']['TwinRuntime']);urls=[t['url'] for p in d['panels'] for t in p.get('targets',[]) if 'url' in t]
        self.assertEqual(len(urls),2);self.assertTrue(any('/Current/%24value' in x for x in urls));self.assertTrue(any('/History/%24value' in x for x in urls));self.assertEqual(d['uid'],'pet-injection-twin');self.assertIn('STALE',json.dumps(d))
    def test_runtime_variable_types_stable_during_movement(self):
        from aas_core import value_body
        from tests.fake_aas import set_value
        env,_=read_aasx(cfg.ROOT/'aas/PET_Twin.aasx');rt=next(s for s in env['submodels'] if s['idShort']=='TwinRuntime');cur=at(rt,'Current');e=PetProcess()
        for i in range(1500):
            e.step()
            if i%13==0:set_value(cur,value_body({**initial_snapshot(),**e.state()}))

if __name__=='__main__':unittest.main()
