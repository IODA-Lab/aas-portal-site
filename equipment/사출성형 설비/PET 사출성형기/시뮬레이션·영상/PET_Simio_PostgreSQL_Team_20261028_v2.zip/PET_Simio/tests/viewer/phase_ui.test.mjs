import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {liveStatus,motions} from '../../viewer/phase_ui.js';
const current={Sequence:1,Timestamp:100,Connection:'ConnectedSimulated'};
test('live status distinguishes empty, stopped, stale and clock skew',()=>{
  assert.equal(liveStatus({...current,Sequence:0},100000).code,'waiting');
  assert.equal(liveStatus({...current,Connection:'Disconnected'},100000).code,'stopped');
  assert.equal(liveStatus(current,104999).code,'live');
  assert.equal(liveStatus(current,105000).code,'stale');
  assert.equal(liveStatus(current,97000).code,'clock');
});
test('all engine phases have a motion explanation',()=>{
  const process=JSON.parse(fs.readFileSync(new URL('../../model/public/process_public.json',import.meta.url)));
  for(const step of process.steps)assert.ok(motions[step.name]);
});
