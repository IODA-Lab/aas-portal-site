// Optional browser integration: npm install --no-save playwright; use installed Edge.
const {chromium}=require(require.resolve('playwright',{paths:[process.env.PET_NODE_MODULES||process.cwd()]}));
const {spawn}=require('node:child_process');const fs=require('node:fs');const assert=require('node:assert/strict');
const python=process.env.PET_PYTHON||'python';
const children=[];function start(args,env={}){let c=spawn(python,args,{cwd:process.cwd(),env:{...process.env,...env},windowsHide:true,stdio:['ignore','pipe','pipe']});c.log='';c.stdout.on('data',d=>c.log+=d);c.stderr.on('data',d=>c.log+=d);children.push(c);return c;}
async function ready(url){for(let i=0;i<80;i++){try{if((await fetch(url)).ok)return;}catch{}await new Promise(r=>setTimeout(r,100));}throw new Error('server startup timed out');}
(async()=>{let b;let checks=[];const errors=[];try{
 start(['tools/serve_viewer.py','--port','18092']);start(['-m','tests.fake_aas','--port','18081']);
 await ready('http://127.0.0.1:18092/viewer/');await ready('http://127.0.0.1:18081/shells');
 b=await chromium.launch({channel:'msedge',headless:true});const p=await b.newPage({viewport:{width:1440,height:1100}});p.on('pageerror',e=>errors.push(String(e)));
 await p.goto('http://127.0.0.1:18092/viewer/');await p.waitForFunction(()=>document.body.dataset.phase);
 await p.locator('#speed').selectOption('4');await p.waitForFunction(()=>['Hold','CoolMeter'].includes(document.body.dataset.phase));await p.locator('#pause').click();
 const t=await p.locator('#time').innerText();await p.waitForTimeout(250);assert.equal(await p.locator('#time').innerText(),t);checks.push('offline playback / pause / speed');
 await p.screenshot({path:'docs/img/viewer_demo.png',fullPage:true});
 assert.equal(await p.locator('canvas').count(),2);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);checks.push('desktop layout / WebGL');
 await p.setViewportSize({width:390,height:844});await p.screenshot({path:'docs/img/viewer_mobile.png',fullPage:true});assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);checks.push('mobile layout');
 await p.setViewportSize({width:1440,height:1100});await p.goto('http://127.0.0.1:18092/viewer/?mode=live&aas=http://127.0.0.1:18081');await p.waitForFunction(()=>document.body.dataset.status==='disconnected');assert.equal(await p.locator('#barrel').innerText(),'—');checks.push('disconnected values hidden');
 const pub=start(['sim_publisher.py','--mode','local','--aas-url','http://127.0.0.1:18081','--seconds','6'],{PET_AAS_TOKEN:'pet-test-token'});
 await p.waitForFunction(()=>document.body.dataset.status==='live');await p.screenshot({path:'docs/img/viewer_live_fake.png',fullPage:true});checks.push('Python -> Fake AAS -> live browser');
 await new Promise((r,j)=>pub.on('exit',code=>code===0?r():j(new Error('publisher exit '+code+' '+pub.log))));
 await p.waitForFunction(()=>document.body.dataset.status==='disconnected');assert.equal(await p.locator('#pressure').innerText(),'—');checks.push('normal shutdown shown disconnected');
 const secret=await fetch('http://127.0.0.1:18092/equipment.env');assert.equal(secret.status,404);checks.push('private config not served');assert.deepEqual(errors,[]);
 const result={status:'PASS',checks,consoleErrors:errors};fs.mkdirSync('output',{recursive:true});fs.writeFileSync('output/browser_result.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 }finally{if(b)await b.close();for(const c of children)c.kill();}})().catch(e=>{console.error(e);process.exitCode=1;});
