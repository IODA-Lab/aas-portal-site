import test from 'node:test';
import assert from 'node:assert/strict';
import {currentQuery,decodeCurrent} from '../../viewer/grafana_transport.js';

function response(mutate=()=>{}){
  const names=currentQuery('urn:test').columns.map(c=>c.text).reverse();
  const frame={schema:{fields:names.map(name=>({name}))},data:{values:names.map(name=>[name==='Samples'?'[]':name==='Connection'?'ConnectedSimulated':'0'])}};
  mutate(frame);
  return {results:{A:{frames:[frame]}}};
}
test('query selects the whole Current row with unambiguous JSONata and configured endpoint',()=>{
  const q=currentQuery('urn:test','custom-uid','http://test-aas:8081/');
  assert.equal(q.datasource.uid,'custom-uid');
  assert.equal(q.url,'http://test-aas:8081/submodels/dXJuOnRlc3Q/submodel-elements/Current/%24value');
  assert.equal(q.root_selector,'($r := $; [$r])');
});
test('decode by field name regardless of order; preserve zero and empty samples',()=>{
  const data=decodeCurrent(response());
  assert.equal(data.Sequence,'0'); assert.equal(data.Samples,'[]');
  assert.equal(data.Connection,'ConnectedSimulated');
});
test('missing or null fields stay query failures, never fabricated running data',()=>{
  assert.throws(()=>decodeCurrent(response(f=>{f.data.values[f.schema.fields.findIndex(x=>x.name==='Samples')]=[null];})),/필드 누락: Samples/);
  assert.throws(()=>decodeCurrent({results:{A:{frames:[]}}}),/필드 누락/);
  assert.throws(()=>decodeCurrent({results:{A:{error:'HTTP 503'}}}),/HTTP 503/);
});
