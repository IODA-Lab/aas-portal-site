import test from 'node:test';
import assert from 'node:assert/strict';
import {takeoutPose,TAKEOUT as c} from '../../viewer/takeout_motion.js';
import {viewpoints,viewForPhase} from '../../viewer/camera_views.js';
const pose=(Phase,PhaseProgress,MoldOpen=500)=>takeoutPose({Phase,PhaseProgress,MoldOpen});
test('takeout descends, grips, retracts from core, lifts before lateral transfer',()=>{
  assert.ok(pose('Eject',.12).y<c.high);
  assert.equal(pose('Eject',.45).x,c.pickX);assert.equal(pose('Eject',.45).carrying,true);
  assert.equal(pose('Eject',.7).x,c.clearX);assert.equal(pose('Eject',.7).y,c.pick);
  assert.ok(pose('Eject',.9).y>c.pick);assert.equal(pose('Eject',1).y,c.high);
  assert.equal(pose('Transfer',.2).y,c.high);assert.equal(pose('Transfer',.2).carrying,true);
  assert.equal(pose('Transfer',.65).carrying,false);assert.equal(pose('Transfer',.65).released,true);
});
test('open/eject/transfer/clamp boundaries have continuous robot positions',()=>{
  for(const [a,b] of [['Open','Eject'],['Eject','Transfer'],['Transfer','Clamp']]){
    for(const k of ['x','y','z','angle'])assert.ok(Math.abs(pose(a,1)[k]-pose(b,0)[k])<1e-9,`${a}/${b} ${k}`);
  }
});
test('lateral path clears enclosure and low motion stays in mold gap or conveyor bay',()=>{
  for(const phase of ['Open','Eject','Transfer','Clamp'])for(let i=0;i<=1000;i++){
    const p=pose(phase,i/1000);
    // Receiver half-height .615 m, enclosure roof top 3.425 m.
    if(p.z>1e-6&&p.z<c.outZ-1e-6)assert.ok(p.y-.615>3.425);
    if(p.y<c.high-1e-6)assert.ok(p.z===0||Math.abs(p.z-c.outZ)<1e-9);
    if(p.z===0&&p.y<c.high){
      assert.ok(p.x-.30>-1.92&&p.x+.05<-.325); // open mold gap
      assert.ok(.605<.73-.075); // receiver clears the four tie bars
    }
    if(phase==='Eject'&&p.y>c.pick+.01&&p.carrying)assert.equal(p.x,c.clearX);
  }
});
test('incomplete mold opening inhibits descent and grabbing',()=>{
  for(const opening of [0,250,489])for(const u of [.2,.45,.6,.9]){
    const p=pose('Eject',u,opening);assert.equal(p.y,c.high);assert.equal(p.carrying,false);
  }
});
test('each phase has a closer inspection view; return uses overall',()=>{
  const distance=v=>Math.hypot(...v.eye.map((n,i)=>n-v.target[i]));
  for(const phase of ['Feed','Warmup','Clamp','Inject','Hold','CoolMeter','Open','Eject','Transfer']){
    const name=viewForPhase(phase);assert.notEqual(name,'overall');assert.ok(distance(viewpoints[name])<distance(viewpoints.overall));
  }
  assert.equal(viewForPhase(null),'overall');assert.equal(viewForPhase('Eject'),'robot');
});
