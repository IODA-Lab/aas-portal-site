import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {PhaseLoop} from '../../viewer/phase_loop.js';
import {takeoutPose} from '../../viewer/takeout_motion.js';
import {viewForPhase} from '../../viewer/camera_views.js';
const data=JSON.parse(fs.readFileSync(new URL('../../model/public/demo_cycle.json',import.meta.url)));
test('combined takeout preserves continuity, full progress and carrying across the join',()=>{
  const before=JSON.stringify(data),loop=new PhaseLoop(data);loop.select('TakeoutSequence');loop.setSpeed(1);
  const clip=loop.sequences.get(loop.phase);assert.equal(clip.duration,14);
  assert.equal(viewForPhase(loop.phase),'conveyor');
  const a=loop.step(5.99),pa=takeoutPose(a),progress=loop.progress;
  assert.equal(a.Phase,'Eject');assert.equal(loop.opacity,1);
  loop.togglePause();assert.deepEqual(loop.step(30),a);assert.equal(loop.progress,progress);
  loop.togglePause();const b=loop.step(.02),pb=takeoutPose(b);
  assert.equal(b.Phase,'Transfer');assert.equal(loop.stage,'playing');assert.equal(loop.opacity,1);
  assert.ok(loop.progress>progress);assert.ok(loop.progress>.42&&loop.progress<.44);
  assert.ok(pa.carrying&&pb.carrying);
  for(const k of ['x','y','z','angle'])assert.ok(Math.abs(pa[k]-pb[k])<.02,k);
  assert.equal(takeoutPose(loop.step(5.2)).released,true);
  loop.step(2.79);assert.equal(loop.stage,'hold');assert.equal(loop.progress,1);
  loop.step(loop.endHold+loop.resetDuration+loop.startHold+.01);
  assert.equal(loop.step(0).Phase,'Eject');assert.equal(loop.stage,'playing');assert.ok(loop.progress<.01);
  loop.clear();assert.equal(loop.step(1),null);assert.equal(JSON.stringify(data),before);
});
test('combined replay is unavailable when either operation is absent or not adjacent',()=>{
  for(const frames of [data.frames.filter(f=>f.Phase!=='Transfer'),data.frames.filter(f=>f.Phase!=='Eject')]){
    const loop=new PhaseLoop({...data,frames});assert.equal(loop.has('TakeoutSequence'),false);
    assert.throws(()=>loop.select('TakeoutSequence'),/단계 기록 없음/);
  }
  const frames=data.frames.map(f=>({...f}));
  const i=frames.findIndex(f=>f.Phase==='Transfer');frames[i].Phase='Open';
  assert.equal(new PhaseLoop({...data,frames}).has('TakeoutSequence'),false);
});
test('default has no override and clear restores automatic selection',()=>{
  const loop=new PhaseLoop(data);assert.equal(loop.step(1),null);
  loop.select('Inject');assert.equal(loop.step(.1).Phase,'Inject');
  loop.clear();assert.equal(loop.step(1),null);
});
test('every operation stays in its own recorded phase across multiple loops',()=>{
  const before=JSON.stringify(data),loop=new PhaseLoop(data);assert.equal(loop.clips.size,9);
  for(const phase of loop.clips.keys()){
    loop.select(phase);const clip=loop.clips.get(phase);
    for(let i=0;i<500;i++){
      const s=loop.step(.05);assert.equal(s.Phase,phase);
      assert.equal(s.Produced,s.Good+s.Reject);
      assert.ok(s.SimTime>=clip.start&&s.SimTime<clip.start+clip.duration);
      if(s.Injection||s.Holding)assert.equal(s.MoldOpen,0);
    }
  }
  assert.equal(JSON.stringify(data),before);
});
test('selection restarts from the beginning and has visible mold/screw travel',()=>{
  const loop=new PhaseLoop(data);
  for(const [phase,key] of [['Open','MoldOpen'],['Clamp','MoldOpen'],['Inject','ScrewPosition'],['Eject','Takeout']]){
    loop.select(phase);const start=loop.step(0)[key];
    const end=loop.step(loop.clips.get(phase).duration*.8)[key];assert.notEqual(start,end);
    loop.select(phase);assert.equal(loop.step(0)[key],start);
  }
  assert.throws(()=>loop.select('unknown'),/단계 기록 없음/);
});
test('half speed default, speed change preserves position, pause holds exact state',()=>{
  const loop=new PhaseLoop(data);loop.select('Open');assert.equal(loop.speed,.5);
  const s=loop.step(.4);assert.ok(Math.abs(loop.time-.2)<1e-9);
  loop.setSpeed(.1);assert.deepEqual(loop.step(0),s);
  loop.togglePause();const frozen=loop.step(0);
  assert.deepEqual(loop.step(30),frozen);assert.equal(loop.time,.2);
  loop.togglePause();loop.step(1);assert.ok(Math.abs(loop.time-.3)<1e-9);
  loop.restart();assert.equal(loop.time,0);assert.equal(loop.paused,false);assert.equal(loop.speed,.1);
  assert.throws(()=>loop.setSpeed(0),/범위/);assert.throws(()=>loop.setSpeed(NaN),/범위/);
});
test('repeat holds the end and resets only while faded, without reversing operation',()=>{
  const loop=new PhaseLoop(data);loop.select('Open');loop.setSpeed(1);
  const clip=loop.clips.get('Open'),end=loop.step(clip.duration);
  assert.equal(loop.stage,'hold');assert.equal(loop.opacity,1);
  assert.deepEqual(loop.step(loop.endHold/2),end);
  const middle=loop.step(loop.endHold/2+loop.resetDuration/2+1e-8);
  assert.equal(loop.stage,'reset');assert.ok(loop.opacity<1e-10);
  assert.equal(middle.MoldOpen,clip.frames[0].MoldOpen);
  loop.togglePause();const opacity=loop.opacity;
  assert.deepEqual(loop.step(20),middle);assert.equal(loop.opacity,opacity);
  loop.togglePause();loop.step(loop.resetDuration/2+loop.startHold+.01);
  assert.equal(loop.stage,'playing');assert.equal(loop.opacity,1);
});
