# PET 디지털 트윈
# Simio + PostgreSQL 가이드

Windows PostgreSQL 포함판 | 2026년 10월 28일 | 24캐비티 / 27.5초

이 ZIP은 공정 계산을 Simio로 옮긴 버전입니다. Windows에서 Simio 모델을 실행하고 Docker에서 AAS 서버·Grafana·데이터 전달기를 실행합니다. 기존 Python 시뮬레이션 엔진은 자동으로 실행되지 않습니다.

## 먼저 알아둘 사항

검증한 환경은 Simio 20.294.55654 학생 에디션입니다. 수신자 PC에도 이 모델과 호환되는 Simio와 사용 권한이 필요합니다. 학생 에디션 모델을 상용 에디션에서 그대로 열 수 있다고 가정하지 마세요. 호환성 메시지가 뜨면 담당자에게 전달하고, 라이선스나 모델 보호를 우회하지 않습니다. Simio 설치 프로그램·라이선스·제조사 DLL은 ZIP에 포함하지 않습니다.

Docker Desktop의 Linux containers 엔진을 켜야 합니다. Python은 전달기 컨테이너 안에서 실행하므로 PC에 별도 설치할 필요가 없습니다. 직접 빌드하는 경우에만 .NET 10 SDK가 필요하며, 일반 실행에는 함께 제공한 PET 출력 확장 DLL을 사용합니다.

모든 값은 합성 데이터입니다. 실제 사출성형기·PLC를 제어하지 않으며, 3D 모델은 일반 구조 모식도입니다. Simio 내부에는 상태와 공정 프로세스가 있고, 상세 장비 3D는 Grafana 웹 화면에 표시됩니다.

## 전달 경로와 접속 주소

Simio 공정 → C# 출력 → 전달기 → AAS → Grafana로 실시간 연결됩니다. 전달기는 같은 관측값을 디스크 대기열에도 넣고, 별도 저장기가 PostgreSQL에 누적합니다. Python은 공정을 계산하지 않습니다.

이전 버전도 AAS Current를 약 1초마다 갱신했습니다. 이번 추가 기능은 PostgreSQL의 장기 이력 저장입니다. MongoDB는 AAS 모델·최근 이력을, PostgreSQL은 운전 시계열·완료 사이클 기록을 보관합니다.

```text
팀원용 Grafana: http://localhost:3004/d/pet-injection-twin
팀원용 AAS:     http://localhost:8084
PostgreSQL:     localhost:15432 / pet_history
Docker 프로젝트: pet-simio-team
```

기존 제작자 환경 3000/8081 및 이전 Python 팀원 환경 3003/8083과 구분합니다. 기존 컨테이너와 볼륨을 지우거나 초기화하지 않습니다. 최초 이미지·플러그인·DB 드라이버 설치에는 인터넷이 필요합니다.

<!-- PAGE -->

# 1 압축 풀기와 최초 설치

ZIP을 ‘모두 압축 풀기’로 C:\PET_Simio_Team 같은 로컬 폴더에 풉니다. ZIP 안에서 바로 실행하지 마세요. 아래 PET_Simio 폴더를 통째로 유지합니다. OneDrive 동기화 폴더보다는 일반 로컬 폴더가 파일 공유 문제를 줄이는 데 유리합니다.

```text
C:\PET_Simio_Team\
  00_먼저읽기.txt
  PET_Simio_PostgreSQL_실행가이드.pdf
  PET_Simio\
    launch\Install_Simio_Extension.bat
    launch\Start_Simio_Team.bat
    launch\Stop_Simio_Team.bat
    launch\Status_Simio_Team.bat
    simio\PET_24Cavity_27_5s.spfx
    simio\NativeTelemetry\
    viewer\  model\  aas\  grafana\  docs\
```

## 1-1 프로그램 준비

Docker Desktop을 설치하고 Linux containers 엔진을 실행합니다. 호환되는 Simio를 설치하고 정상적으로 실행되는지 확인합니다. 이후 출력 확장을 설치할 때는 Simio를 닫아 둡니다. 브라우저는 Chrome 또는 Edge를 사용합니다.

Docker 공식 Windows 설치 안내:
https://docs.docker.com/desktop/setup/install/windows-install/

Simio 공식 홈페이지:
https://www.simio.com/

## 1-2 PET 출력 확장 설치 - 최초 한 번

PET_Simio\launch\Install_Simio_Extension.bat을 더블클릭합니다. Installed: ...\SimioUserExtensions\PetSimioTelemetry.dll 문구가 나오면 완료입니다. 확장은 Windows의 ‘문서’ 폴더 아래 SimioUserExtensions 바로 밑에 설치됩니다. 문서가 OneDrive로 연결된 PC도 자동으로 해당 위치를 사용합니다.

Simio가 실행 중이면 설치가 중단됩니다. 모델을 저장하고 Simio를 닫은 뒤 다시 실행합니다. 일반 설치에는 .NET SDK가 필요하지 않습니다. DLL 교체 후에는 반드시 Simio를 다시 열어야 합니다. 기존 DLL은 .previous로 보관합니다.

<!-- PAGE -->

# 2 실행하고 Grafana 열기

## 실행 순서

1. Docker Desktop을 열고 엔진이 준비될 때까지 기다립니다.
2. simio\PET_24Cavity_27_5s.spfx를 Simio에서 엽니다. 모델 호환성·Missing Step 오류가 없어야 합니다.
3. Shift+F6 또는 Run 메뉴의 Fast Forward를 누릅니다. PETTelemetry 확장이 실제 시간 1배속으로 출력을 제한하므로 빠른 실행 모드를 사용합니다. 모델 하나만 실행합니다. MCP 서버는 필요 없습니다.
4. launch\Start_Simio_Team.bat을 더블클릭합니다. 첫 실행은 이미지 다운로드·AAS 최초 적재로 수 분 걸릴 수 있습니다.
5. SIMIO LIVE Sequence=... Phase=... Produced=... 문구가 나오면 아래 주소를 엽니다. 준비가 늦으면 Status_Simio_Team.bat으로 확인합니다.

```text
http://localhost:3004/d/pet-injection-twin
```

## 로그인

계정은 admin입니다. 비밀번호는 처음 실행할 때 PC별로 생성됩니다. PET_Simio 폴더에 생성된 simio-team.local.env를 메모장으로 열어 PET_SIMIO_GRAFANA_PASSWORD= 뒤의 값만 입력합니다. 이 파일에는 로컬 출력 폴더 경로도 들어 있습니다. 삭제하거나 팀원에게 보내지 않습니다. 파일을 삭제해도 이미 저장된 Grafana 비밀번호는 바뀌지 않습니다.

## 정상 동작 확인

3D 상단은 ‘AAS 수신 중 · 합성 데이터’, 상태 패널은 ‘API 정상 / 수신 중’, 경보는 None을 표시합니다. 현재 단계와 스크루 위치가 바뀌고 총생산은 24개 단위로 증가합니다. 처음 공급 1초·가열 6초 후 정상 반복 사이클은 27.5초입니다. 최근 사이클 값은 첫 사이클이 완료된 후 나타납니다.

그래프는 새 실행 환경에서 기록이 쌓여야 채워집니다. 3D는 약 1초 간격으로 받은 자세 기록을 보간하며, Grafana 수치 패널은 기본 5초마다 새로고침합니다. 같은 순간에도 표시 단계가 조금 다를 수 있습니다. 예전 화면이 보이면 Ctrl+Shift+R을 누릅니다.

Start 창을 닫아도 Docker 전달기는 계속 실행됩니다. 그러나 Simio는 실행 중으로 유지해야 합니다. Docker만 켜 놓고 Simio를 종료하면 새 공정 데이터가 나오지 않습니다.

<!-- PAGE -->

# 3 3D와 반복 재생 사용법

실시간 운전을 확인할 때는 특정 단계의 반복을 선택하지 않습니다. 반복이 선택돼 있다면 ‘실시간 복귀’를 누릅니다. Simio 상태가 AAS를 거쳐 3D 자세와 공정 단계에 반영됩니다.

| 조작 | 의미 |
|---|---|
| 기본 상태 | 현재 AAS 공정 순서에 따라 자동 재생 |
| 각 단계 버튼 | 해당 동작 기록을 반복하고 관련 부위로 시점 이동 |
| 취출 → 컨베이어 인계 연속 반복 | 잡기·상승·횡이동·내려놓기·복귀를 이어서 관찰 |
| 반복 속도 | 0.1~2배속, 기본 0.5배속 |
| 일시정지 / 처음부터 | 선택한 기록 재생을 멈추거나 처음부터 재생 |
| 실시간 복귀 | 현재 AAS 상태와 전체 설비 시점으로 복귀 |
| 내부 보기 / 모델 시점 | 외장·내부 기구 및 관찰 부위 선택 |
| 모델 위에서 드래그 / 휠 | 모델 회전 / 확대·축소 |
| 오른쪽 공정·재생 메뉴에서 휠 | 모델 화면은 고정하고 오른쪽 메뉴만 위아래 이동 |

반복 버튼과 속도 조절은 웹 뷰어의 관찰용 기능입니다. Simio 실행 속도나 AAS 값을 바꾸지 않습니다. 반복 중의 3D 표시와 아래 실시간 수치가 다른 것은 정상입니다. 연결 확인은 수신 Sequence·마지막 수신 경과·AAS Session으로 판단합니다.

## 공정 구성

반복 공정은 형체 1.5초 → 사출 1.5초 → 보압 3초 → 냉각/계량 6초 → 금형 열림 1.5초 → 취출 6초 → 컨베이어 인계 8초입니다. 합계 27.5초이며, 냉각과 다음 샷 계량은 함께 진행됩니다. 모든 수치와 불량 판정은 설명용 시뮬레이션 가정입니다.

## ‘빠른 실행’인데 왜 실제 시간으로 움직이나요?

Simio는 자체 이벤트를 계산하고, C# 출력 확장은 50ms 간격의 상태를 실제 시간에 맞춰 내보냅니다. 따라서 Fast Forward를 선택해도 이 모델의 출력은 1배속입니다. 다른 시간 가속이나 설정 변경으로 속도가 일치하지 않으면 전달기가 중단될 수 있습니다. 임의의 데이터를 만들어 화면을 계속 움직이지 않습니다.

<!-- PAGE -->

# 3-1 중요 지표와 화면 사용법

이 배포판은 UI 3.0입니다. 3D와 모든 지표를 보는 기본 대시보드, 핵심 값만 모은 별도 화면을 모두 포함합니다. 두 화면은 같은 AAS 현재값·최근 이력을 읽습니다.

## 3D를 보면서 중요한 지표 확인

3D 바로 아래 ‘어떤 지표가 중요한가요?’ 줄을 누르면 안내가 펼쳐집니다. 연결·경보, 품질, 공정 안정성, 생산성별로 어떤 값을 먼저 봐야 하는지 설명합니다. 다시 누르면 안내만 접힙니다. 아래 운전 지표는 계속 표시됩니다.

별표 대신 은은한 청록색으로 구분했습니다. 중요 숫자 패널에는 짙은 청록색 배경을, 중요 추세에는 차분한 청록색 선을 사용합니다. 이 색은 우선 확인할 항목이라는 뜻이며, 정상 범위·안전 상태·경보 판정 색상이 아닙니다.

| 우선 확인할 지표 | 확인하는 이유 |
|---|---|
| 설비 운전·연결 상태 / 경보 | 데이터가 최신인지, 이상 운전이 있는지 먼저 확인 |
| 불량 / 실린더 대표온도 / 금형 온도 | 누적 불량의 증가와 온도 변화를 함께 비교 |
| 사출 압력 | 사출·보압 동작 중 반복되는 압력 패턴 확인 |
| 최근 사이클 | 완료된 한 사이클의 소요 시간과 생산성 변화 확인 |

## 핵심 값만 따로 보기

상단 ‘중요 데이터 보기’를 누르면 별도 요약 화면으로 이동합니다. 연결·단계·경보, 생산·양품·불량·사이클 시간, 온도·압력과 추세를 모아 봅니다. ‘전체 대시보드로 돌아가기’로 3D 화면에 복귀하며 조회 시간 범위를 유지합니다.

## 스크롤과 데이터가 비어 있을 때

3D 셀 안에서는 모델 화면이 고정됩니다. 오른쪽 공정·재생 메뉴에 마우스를 올려 휠을 움직이면 그 메뉴만 스크롤됩니다. 모델 위의 휠은 확대·축소입니다. 아래 지표로 이동할 때는 3D 바깥에서 대시보드 페이지를 스크롤합니다.

‘API 정상 / 발행 종료’ 또는 ‘데이터 지연’이면 현재값은 숨깁니다. Simio 실행 상태를 확인한 후 Start_Simio_Team.bat을 다시 실행합니다. 경고 아이콘은 별도의 조회 실패이므로 오류 내용을 확인합니다. 이 화면의 추세는 AAS 최근 60개 기록이며, PostgreSQL 전체 이력은 8장의 명령으로 조회합니다.

이전 화면이나 별표가 남아 있으면 Ctrl+Shift+R을 누릅니다. 이전 ZIP을 사용하던 PC는 9장의 업데이트 절차로 기존 env 파일과 DB 볼륨을 유지합니다.

<!-- PAGE -->

# 4 종료·재실행·절전 복구

## 정상 종료

먼저 launch\Stop_Simio_Team.bat을 실행합니다. 전달기가 마지막 값과 종료 상태를 반영한 다음 저장기를 거쳐 팀원용 Grafana·AAS·MongoDB·PostgreSQL을 정지합니다. Volumes and model retained 문구를 확인한 뒤 Simio를 중지하고 닫습니다. 필요하면 모델 변경 내용을 저장합니다.

이 종료 스크립트는 pet-simio-team 프로젝트만 정지합니다. 기존 3000/8081 또는 Python 팀원용 컨테이너와 볼륨을 삭제하지 않습니다. docker compose down -v, docker volume rm은 일반 종료 명령이 아닙니다.

## 다음 날 다시 실행

Docker Desktop 실행 → 저장한 Simio 모델 열기 → Shift+F6 → Start_Simio_Team.bat 순서입니다. 기존 프로젝트 폴더와 simio-team.local.env를 유지합니다. 확장 DLL 설치는 PC에 처음 설치하거나 수정된 DLL로 교체할 때만 필요합니다.

MongoDB와 Grafana 볼륨에 저장된 누적 수량·이력·로그인 설정을 이어 사용합니다. Simio는 다시 시작하면 공급·가열부터 시작하며 중간 동작의 자세가 그대로 복구되는 것은 아닙니다. 전달기는 새로운 Simio 세션의 증가분을 기존 AAS 누적값에 이어 붙입니다. 연결 전 Simio에서 생산된 수량을 과거 AAS 실적으로 소급하지 않습니다.

## 노트북을 닫았거나 Simio를 일시정지한 경우

절전·Simio 중단으로 원본 갱신이 3초 이상 끊기면 전달기가 종료됩니다. 재개 후 Simio가 진행 중인지 확인하고 Start_Simio_Team.bat을 다시 실행합니다. 모델을 초기화하거나 새로 열었을 때도 새 세션으로 다시 연결해야 합니다. 계속 기다려도 자동으로 Python 시뮬레이션으로 대체되지 않습니다.

단순 외부 인터넷 단절과 PC 절전은 다릅니다. 최초 이미지·플러그인 다운로드가 끝난 로컬 구성은 일상적인 데이터 통신에 외부 인터넷을 사용하지 않습니다. Docker Desktop이 멈췄다면 먼저 다시 켭니다.

## 상태만 확인

launch\Status_Simio_Team.bat은 컨테이너와 실제 AAS 수신 상태를 읽습니다. Simio를 대신 실행하지는 않습니다. 화면만 움직이는지보다 SIMIO LIVE 문구와 아래 5장의 원본 검증을 함께 확인합니다. AAS 기본 이력은 최근 60개 기록의 순환 버퍼입니다. PostgreSQL은 별도로 운전값과 완료 사이클을 누적합니다. 8장의 DB 조회로 저장 상태도 확인합니다.

<!-- PAGE -->

# 5 PowerShell 검증 명령

아래 명령은 압축을 푼 PET_Simio 폴더에서 실행합니다. 탐색기 주소창에 powershell을 입력하면 해당 위치에서 창이 열립니다. PC 전체 실행 정책을 바꾸지 않고 해당 스크립트만 실행합니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass `
  -File .\launch\Simio_Team.ps1 -Action Status
```

## 실제 AAS가 Simio 값을 받는지 확인

다음 명령을 실행해 3초 전후 Sequence가 증가하고 Session이 simio-로 시작하는지 확인합니다. Connection은 ConnectedSimulated, TimestampISO는 현재 시각에 가까워야 합니다. 브라우저의 실시간 복귀를 선택하면 해당 값으로 3D가 동작합니다.

```powershell
$m=Get-Content aas/twin_manifest.json -Raw -Encoding utf8 |
  ConvertFrom-Json
$b=[Text.Encoding]::UTF8.GetBytes($m.submodels.TwinRuntime)
$id=[Convert]::ToBase64String($b).TrimEnd('=')
$id=$id.Replace('+','-').Replace('/','_')
$u='http://127.0.0.1:8084/submodels/'+$id+
  '/submodel-elements/Current/%24value'
Invoke-RestMethod $u |
  Select-Object Session,Sequence,Connection,Phase,Produced
Start-Sleep -Seconds 3
Invoke-RestMethod $u |
  Select-Object Session,Sequence,Connection,Phase,Produced
```

## 원본 출력과 로그

Simio 출력은 Windows의 %LOCALAPPDATA%\PETSimio\Live에 생성됩니다. 파일 이름은 pet_live_simio-로 시작하며 실행마다 달라집니다. 전달기에는 이 폴더가 읽기 전용으로 연결됩니다. 모델이 멈추면 파일도 더 이상 갱신되지 않습니다.

```powershell
docker compose --env-file simio-team.local.env `
  -f docker-compose.simio-team.yml ps
docker compose --env-file simio-team.local.env `
  -f docker-compose.simio-team.yml logs --tail 80 `
  bridge aas-env grafana > simio_diagnostics.log
```

화면·발생 시각·최초 실행인지 여부·위 로그를 담당자에게 전달합니다. simio-team.local.env의 비밀번호는 보내지 않습니다.

<!-- PAGE -->

# 6 문제 해결과 배포 범위

| 증상 | 확인과 조치 |
|---|---|
| Simio에서 모델이 열리지 않음 | 학생 모델 호환성과 Simio 버전 확인. 라이선스 메시지를 담당자에게 전달 |
| Missing Step / PETTelemetry 없음 | Simio 종료 → Install_Simio_Extension.bat → 모델 다시 열기. DLL은 문서/SimioUserExtensions 바로 아래 |
| DLL 설치 실패 | 실행 중인 Simio를 닫았는지 확인. 설치 대상 경로와 오류를 전달 |
| WAIT_SIMIO / fresh sources=0 | Simio에서 정확한 모델 하나를 Shift+F6로 실행. 원본 폴더 갱신 확인 후 Start 재실행 |
| fresh sources가 2 이상 | PET 모델을 여러 개 실행했는지 확인. 하나만 실행한 뒤 오래된 파일이 신선도 범위를 벗어나도록 기다림 |
| Simio source stale / clock 오류 | 절전·일시정지·Simio 오류·PC 부하 확인. 원인 해소 후 Start 재실행 |
| 접근 거부 / 출력 파일 오류 | Simio 오류 원문과 보안 프로그램 로그 확인. 동봉된 최신 DLL인지 확인. 보호 기능을 임의로 해제하지 않음 |
| 포트 사용 중 | 3004/8084 충돌 확인. 기존 서비스를 임의로 삭제하지 않음 |
| Docker mount / 공유 오류 | simio-team.local.env의 출력 폴더가 현재 사용자 경로인지, Docker Desktop이 폴더를 읽을 수 있는지 확인 |
| 로그인 실패 | 해당 PC에서 생성된 simio-team.local.env 비밀번호 사용. env가 없다면 복구 요청, 볼륨 초기화 금지 |
| API 정상 / 발행 대기 | AAS만 준비됨. Simio 실행 상태와 bridge 로그 확인 |
| 패널 경고 / 조회 실패 | AAS·Grafana 로그와 aas-infinity 데이터소스 확인. Empty 데이터와 쿼리 실패를 구분 |
| PARTIAL_SEED / CD_CONFLICT | 기존 모델의 일부 적재나 정의 충돌. 자동 초기화하지 않고 로그 전달 |

## ZIP에 포함되는 것

저장된 Simio 모델, 자체 제작 C# 출력 확장 DLL과 소스, AAS 모델·매핑, 전달 코드, Grafana·3D 리소스, 실행 스크립트, PostgreSQL 저장 코드·SQL, 이 PDF와 Markdown 가이드입니다. 프로젝트의 기존 Python 데모 소스는 참고용으로 보존될 수 있지만 Start_Simio_Team은 이를 실행하지 않습니다.

개인 비밀번호, 실시간 출력·운전 로그, 제작자 가상환경, Docker 데이터 볼륨, Simio 설치 프로그램·라이선스·제조사 DLL은 포함하지 않습니다. 새 팀원 PC는 별도 AAS 이력을 시작합니다. 제작자 PC의 누적 생산 실적이 ZIP을 통해 복제되지는 않습니다.

이 배포판은 Windows Simio와 같은 PC의 Docker Desktop을 기준으로 검증합니다. 설치 경로·보안 정책·Simio 에디션이 다른 PC에서는 위 순서로 확인해야 합니다. 일반 실행에 쓰는 파일은 이름에 Simio_Team이 있는 배치 파일입니다. Start_Team, Start_PET_Live는 이전 Python 환경용입니다.


<!-- PAGE -->

# 7 무엇이 PostgreSQL에 저장되나요?

## 기존 실시간 AAS와 새 영구 이력

기존 버전에서도 Simio 값은 AAS Current에 약 1초마다 반영됐고, History에는 최근 60개 기록이 순환 저장됐습니다. 이 버전은 그 흐름을 유지하면서 사이클 완료를 감지할 때도 즉시 Current 갱신을 요청합니다. 네트워크·서버 처리 시간에 따라 화면 반영에는 지연이 있을 수 있습니다.

PostgreSQL은 최근 기록을 덮어쓰지 않고 계속 쌓습니다. AAS와 PostgreSQL은 동일한 관측 데이터를 각각 전달받으며, 하나의 분산 트랜잭션은 아닙니다. DB 저장 성공만으로 같은 순간의 AAS 쓰기 성공까지 증명되지는 않습니다. 각각의 상태를 확인합니다.

| 테이블 | 저장 내용 |
|---|---|
| pet_twin.telemetry | 약 1초 간격 및 사이클 완료 시의 운전값. 시각·원본 세션·AAS Sequence·단계·누적 수량·온도·압력·스크루 위치 |
| pet_twin.cycles | 완료 사이클마다 1건. 원본 사이클 번호·완료 관측 시각·사이클 시간·배치 생산/양품/불량·대응 AAS 누적값 |
| 두 테이블의 payload | 추가 AAS 값과 원본 식별 정보를 JSONB 형태로 보존. 사이클에는 원본 상태도 포함 |

0.05초 간격의 모든 3D 자세를 장기 저장하는 구성은 아닙니다. DB 운전 이력은 약 1초 간격이며, 완료 사이클은 빠짐없이 감지하도록 전달기가 매 원본 샘플을 검사합니다. 설비 ID·원본 Simio 세션·샘플/사이클 번호 조합으로 중복 저장을 방지합니다.

## 사이클 번호와 첫 기록 해석

cycle_number는 해당 Simio 실행의 원본 사이클 번호입니다. AAS 누적 사이클은 이전 실행에서 이어질 수 있으므로 서로 다를 수 있습니다. cycles.aas_completed_cycles가 대응 AAS 누적값입니다. 배치 수량과 AAS 총생산도 구분해 읽습니다.

실행 도중 전달기를 연결했다면 첫 사이클 전체를 관찰하지 못했을 수 있습니다. observed_full_cycle=false로 표시합니다. 특히 취출 후 연결한 경우 첫 배치의 양품·불량을 역산하지 않고 NULL로 저장합니다. 다음 온전한 사이클부터 정상 집계합니다. 중도 경보로 완료되지 않은 사이클은 완료 테이블에 넣지 않으며 운전값의 Alarm으로 확인합니다.

<!-- PAGE -->

# 8 DB 접속과 조회

DB 클라이언트에서 아래 값으로 접속합니다. PostgreSQL은 이 PC의 루프백 주소에만 공개됩니다. 다른 PC에서 직접 접속하려고 방화벽이나 포트 공개 범위를 임의로 바꾸지 않습니다.

| 항목 | 값 |
|---|---|
| 호스트 / 포트 | localhost / 15432 |
| 데이터베이스 | pet_history |
| 사용자 | pet |
| 비밀번호 | simio-team.local.env의 PET_POSTGRES_PASSWORD 값 |
| 스키마 | pet_twin |

## PowerShell에서 빠르게 확인

PET_Simio 폴더에서 실행합니다. 별도 Python이나 DB 클라이언트를 PC에 설치하지 않아도 됩니다. 아래 명령은 테이블 건수·최근 기록·저장 대기 건수를 보여 줍니다.

```powershell
docker compose --env-file simio-team.local.env `
  -f docker-compose.simio-team.yml exec -T archive `
  python tools/db_report.py
```

telemetry_rows가 계속 증가하고, cycle_rows가 약 27.5초마다 증가해야 합니다. archive.connected=true는 DB 연결 상태이며 pending은 아직 DB에 확정되지 않은 건수입니다. 정상 운전 중에도 잠깐 1~2건 보일 수 있습니다. 장시간 증가만 하면 archive와 postgres 로그를 확인합니다.

## SQL 예시

```sql
SELECT observed_at, phase, produced, injection_pressure_bar
FROM pet_twin.telemetry
ORDER BY observed_at DESC LIMIT 20;

SELECT cycle_number, completed_at, cycle_time_seconds,
       batch_produced, batch_good, batch_reject,
       observed_full_cycle
FROM pet_twin.cycles
ORDER BY completed_at DESC LIMIT 20;
```

시각은 PostgreSQL timestamptz로 저장합니다. 클라이언트 시간대 설정에 따라 UTC 또는 한국 시각으로 표시됩니다. source_session이 달라지면 별도의 Simio 실행입니다. 단순히 cycle_number만으로 여러 실행의 기록을 합치지 않습니다.

<!-- PAGE -->

# 9 장애 복구·백업·업데이트

## PostgreSQL이 잠시 중단된 경우

Simio와 전달기가 계속 실행 중이면 AAS는 계속 갱신되고, 관측된 기록은 simio-outbox Docker 볼륨의 디스크 대기열에 남습니다. DB가 복구되면 저장기가 자동 재시도합니다. DB에 확정한 뒤 대기열에서 지우므로 중간 재시작에도 같은 기록을 중복 삽입하지 않습니다.

이 보장은 전달기가 정상적으로 관측하여 대기열에 기록한 데이터에 해당합니다. PC 절전·Simio 종료·전달기 자체 중단 기간의 데이터를 만들어 복원하지 않습니다. 디스크 용량 부족이나 볼륨 삭제 역시 복구 대상이 아닙니다. 중단 기간은 공백으로 남습니다.

저장 대기열은 archive 서비스가 처리하므로 Simio가 멈춘 뒤에도 DB가 살아 있으면 이미 대기 중인 기록은 반영됩니다. 수동 종료 시에는 Stop_Simio_Team.bat을 먼저 실행하고 Simio를 닫습니다. DB가 내려가 있어 대기열을 비우지 못해도 볼륨에 남겨 다음 실행에서 처리합니다.

## 백업

PostgreSQL 실행 중 launch/Backup_PostgreSQL.bat을 실행합니다. backups 폴더에 시각이 붙은 .dump 파일을 만듭니다. pg_dump의 custom 형식이며 pg_restore로 별도 DB에 복원할 수 있습니다. 기존 DB를 덮어쓰는 자동 복원은 제공하지 않습니다. 로그나 ZIP을 다시 만드는 작업과 DB 백업은 다릅니다.

이력 자동 삭제는 하지 않으므로 DB 크기가 계속 증가합니다. 디스크 사용량을 확인하고 정기적으로 백업합니다. 장기 보존 기간이나 삭제 정책은 팀에서 별도로 정해야 합니다. 20Hz 전체 자세가 아닌 1초 운전값을 저장해도 장기간 운전하면 용량이 커집니다.

## 이전 Simio ZIP에서 업데이트

기존 팀원용 Stop_Simio_Team.bat으로 종료한 후, 새 ZIP을 별도 폴더에 풉니다. 같은 PC의 기존 이력을 이어 쓸 경우 기존 simio-team.local.env를 새 PET_Simio 폴더에 복사합니다. 기존 볼륨은 삭제하지 않습니다. 새 Start는 기존 Grafana 비밀번호를 유지하고 PostgreSQL 비밀번호만 추가 생성합니다.

PostgreSQL 볼륨이 이미 있는데 비밀번호 항목이 사라졌다면 자동으로 새 비밀번호를 만들지 않습니다. 원래 env 파일을 복구해야 합니다. 새 PC에서는 제작자의 env 파일을 받지 말고 처음 실행 시 자체 생성합니다.

이 기능은 팀원용 3004/8084 환경에 포함됩니다. 제작자용 3000/8081 실행 파일에는 PostgreSQL 저장이 자동으로 붙지 않습니다. 두 환경을 혼용하지 말고 이번 ZIP의 Start_Simio_Team.bat을 사용합니다.
