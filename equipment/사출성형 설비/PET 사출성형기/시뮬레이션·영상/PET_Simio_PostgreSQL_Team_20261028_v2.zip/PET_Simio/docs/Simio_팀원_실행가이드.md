# PET 디지털 트윈
# Simio 팀원 실행 가이드

Windows 배포판 | 2026년 10월 28일 | 24캐비티 / 27.5초

이 ZIP은 공정 계산을 Simio로 옮긴 버전입니다. Windows에서 Simio 모델을 실행하고 Docker에서 AAS 서버·Grafana·데이터 전달기를 실행합니다. 기존 Python 시뮬레이션 엔진은 자동으로 실행되지 않습니다.

## 먼저 알아둘 사항

검증한 환경은 Simio 20.294.55654 학생 에디션입니다. 수신자 PC에도 이 모델과 호환되는 Simio와 사용 권한이 필요합니다. 학생 에디션 모델을 상용 에디션에서 그대로 열 수 있다고 가정하지 마세요. 호환성 메시지가 뜨면 담당자에게 전달하고, 라이선스나 모델 보호를 우회하지 않습니다. Simio 설치 프로그램·라이선스·제조사 DLL은 ZIP에 포함하지 않습니다.

Docker Desktop의 Linux containers 엔진을 켜야 합니다. Python은 전달기 컨테이너 안에서 실행하므로 PC에 별도 설치할 필요가 없습니다. 직접 빌드하는 경우에만 .NET 10 SDK가 필요하며, 일반 실행에는 함께 제공한 PET 출력 확장 DLL을 사용합니다.

모든 값은 합성 데이터입니다. 실제 사출성형기·PLC를 제어하지 않으며, 3D 모델은 일반 구조 모식도입니다. Simio 내부에는 상태와 공정 프로세스가 있고, 상세 장비 3D는 Grafana 웹 화면에 표시됩니다.

## 전달 경로와 접속 주소

Simio 공정 → C# PETTelemetry 출력 → Docker의 Python 전달기 → BaSyx AAS / MongoDB → Grafana 수치·그래프·3D 순서입니다. Python 전달기는 공정이나 생산수량을 계산하지 않습니다.

```text
팀원용 Grafana: http://localhost:3004/d/pet-injection-twin
팀원용 AAS:     http://localhost:8084
Docker 프로젝트: pet-simio-team
```

기존 제작자 환경 3000/8081 및 이전 Python 팀원 환경 3003/8083과 구분합니다. 기존 컨테이너와 볼륨을 지우거나 초기화하지 않습니다. 최초 이미지·Grafana 플러그인 다운로드에는 인터넷이 필요합니다.

<!-- PAGE -->

# 1 압축 풀기와 최초 설치

ZIP을 ‘모두 압축 풀기’로 C:\PET_Simio_Team 같은 로컬 폴더에 풉니다. ZIP 안에서 바로 실행하지 마세요. 아래 PET_Simio 폴더를 통째로 유지합니다. OneDrive 동기화 폴더보다는 일반 로컬 폴더가 파일 공유 문제를 줄이는 데 유리합니다.

```text
C:\PET_Simio_Team\
  00_먼저읽기.txt
  PET_Simio_팀원_실행가이드.pdf
  PET_Simio\
    launch\Install_Simio_Extension.bat
    launch\Start_Simio_Team.bat
    launch\Stop_Simio_Team.bat
    launch\Status_Simio_Team.bat
    simio\PET_24Cavity_27_5s.spfx
    simio\NativeTelemetry\
    viewer\  model\  aas\  grafana\  docs\
```

## 1-1 프로그램 준비

Docker Desktop을 설치하고 Linux containers 엔진을 실행합니다. 호환되는 Simio를 설치하고 정상적으로 실행되는지 확인합니다. 이후 출력 확장을 설치할 때는 Simio를 닫아 둡니다. 브라우저는 Chrome 또는 Edge를 사용합니다.

Docker 공식 Windows 설치 안내:
https://docs.docker.com/desktop/setup/install/windows-install/

Simio 공식 홈페이지:
https://www.simio.com/

## 1-2 PET 출력 확장 설치 - 최초 한 번

PET_Simio\launch\Install_Simio_Extension.bat을 더블클릭합니다. Installed: ...\SimioUserExtensions\PetSimioTelemetry.dll 문구가 나오면 완료입니다. 확장은 Windows의 ‘문서’ 폴더 아래 SimioUserExtensions 바로 밑에 설치됩니다. 문서가 OneDrive로 연결된 PC도 자동으로 해당 위치를 사용합니다.

Simio가 실행 중이면 설치가 중단됩니다. 모델을 저장하고 Simio를 닫은 뒤 다시 실행합니다. 일반 설치에는 .NET SDK가 필요하지 않습니다. DLL 교체 후에는 반드시 Simio를 다시 열어야 합니다. 기존 DLL은 .previous로 보관합니다.

<!-- PAGE -->

# 2 실행하고 Grafana 열기

## 실행 순서

1. Docker Desktop을 열고 엔진이 준비될 때까지 기다립니다.
2. simio\PET_24Cavity_27_5s.spfx를 Simio에서 엽니다. 모델 호환성·Missing Step 오류가 없어야 합니다.
3. Shift+F6 또는 Run 메뉴의 Fast Forward를 누릅니다. PETTelemetry 확장이 실제 시간 1배속으로 출력을 제한하므로 빠른 실행 모드를 사용합니다. 모델 하나만 실행합니다. MCP 서버는 필요 없습니다.
4. launch\Start_Simio_Team.bat을 더블클릭합니다. 첫 실행은 이미지 다운로드·AAS 최초 적재로 수 분 걸릴 수 있습니다.
5. SIMIO LIVE Sequence=... Phase=... Produced=... 문구가 나오면 아래 주소를 엽니다. 준비가 늦으면 Status_Simio_Team.bat으로 확인합니다.

```text
http://localhost:3004/d/pet-injection-twin
```

## 로그인

계정은 admin입니다. 비밀번호는 처음 실행할 때 PC별로 생성됩니다. PET_Simio 폴더에 생성된 simio-team.local.env를 메모장으로 열어 PET_SIMIO_GRAFANA_PASSWORD= 뒤의 값만 입력합니다. 이 파일에는 로컬 출력 폴더 경로도 들어 있습니다. 삭제하거나 팀원에게 보내지 않습니다. 파일을 삭제해도 이미 저장된 Grafana 비밀번호는 바뀌지 않습니다.

## 정상 동작 확인

3D 상단은 ‘AAS 수신 중 · 합성 데이터’, 상태 패널은 ‘API 정상 / 수신 중’, 경보는 None을 표시합니다. 현재 단계와 스크루 위치가 바뀌고 총생산은 24개 단위로 증가합니다. 처음 공급 1초·가열 6초 후 정상 반복 사이클은 27.5초입니다. 최근 사이클 값은 첫 사이클이 완료된 후 나타납니다.

그래프는 새 실행 환경에서 기록이 쌓여야 채워집니다. 3D는 약 1초 간격으로 받은 자세 기록을 보간하며, Grafana 수치 패널은 기본 5초마다 새로고침합니다. 같은 순간에도 표시 단계가 조금 다를 수 있습니다. 예전 화면이 보이면 Ctrl+Shift+R을 누릅니다.

Start 창을 닫아도 Docker 전달기는 계속 실행됩니다. 그러나 Simio는 실행 중으로 유지해야 합니다. Docker만 켜 놓고 Simio를 종료하면 새 공정 데이터가 나오지 않습니다.

<!-- PAGE -->

# 3 3D와 반복 재생 사용법

실시간 운전을 확인할 때는 특정 단계의 반복을 선택하지 않습니다. 반복이 선택돼 있다면 ‘실시간 복귀’를 누릅니다. Simio 상태가 AAS를 거쳐 3D 자세와 공정 단계에 반영됩니다.

| 조작 | 의미 |
|---|---|
| 기본 상태 | 현재 AAS 공정 순서에 따라 자동 재생 |
| 각 단계 버튼 | 해당 동작 기록을 반복하고 관련 부위로 시점 이동 |
| 취출 → 컨베이어 인계 연속 반복 | 잡기·상승·횡이동·내려놓기·복귀를 이어서 관찰 |
| 반복 속도 | 0.1~2배속, 기본 0.5배속 |
| 일시정지 / 처음부터 | 선택한 기록 재생을 멈추거나 처음부터 재생 |
| 실시간 복귀 | 현재 AAS 상태와 전체 설비 시점으로 복귀 |
| 내부 보기 / 모델 시점 | 외장·내부 기구 및 관찰 부위 선택 |
| 드래그 / 스크롤 | 모델 회전 / 확대·축소 |

반복 버튼과 속도 조절은 웹 뷰어의 관찰용 기능입니다. Simio 실행 속도나 AAS 값을 바꾸지 않습니다. 반복 중의 3D 표시와 아래 실시간 수치가 다른 것은 정상입니다. 연결 확인은 수신 Sequence·마지막 수신 경과·AAS Session으로 판단합니다.

## 공정 구성

반복 공정은 형체 1.5초 → 사출 1.5초 → 보압 3초 → 냉각/계량 6초 → 금형 열림 1.5초 → 취출 6초 → 컨베이어 인계 8초입니다. 합계 27.5초이며, 냉각과 다음 샷 계량은 함께 진행됩니다. 모든 수치와 불량 판정은 설명용 시뮬레이션 가정입니다.

## ‘빠른 실행’인데 왜 실제 시간으로 움직이나요?

Simio는 자체 이벤트를 계산하고, C# 출력 확장은 50ms 간격의 상태를 실제 시간에 맞춰 내보냅니다. 따라서 Fast Forward를 선택해도 이 모델의 출력은 1배속입니다. 다른 시간 가속이나 설정 변경으로 속도가 일치하지 않으면 전달기가 중단될 수 있습니다. 임의의 데이터를 만들어 화면을 계속 움직이지 않습니다.

<!-- PAGE -->

# 4 종료·재실행·절전 복구

## 정상 종료

먼저 launch\Stop_Simio_Team.bat을 실행합니다. 전달기가 마지막 값과 종료 상태를 반영한 다음 팀원용 Grafana·AAS·MongoDB를 정지합니다. Volumes and model retained 문구를 확인한 뒤 Simio를 중지하고 닫습니다. 필요하면 모델 변경 내용을 저장합니다.

이 종료 스크립트는 pet-simio-team 프로젝트만 정지합니다. 기존 3000/8081 또는 Python 팀원용 컨테이너와 볼륨을 삭제하지 않습니다. docker compose down -v, docker volume rm은 일반 종료 명령이 아닙니다.

## 다음 날 다시 실행

Docker Desktop 실행 → 저장한 Simio 모델 열기 → Shift+F6 → Start_Simio_Team.bat 순서입니다. 기존 프로젝트 폴더와 simio-team.local.env를 유지합니다. 확장 DLL 설치는 PC에 처음 설치하거나 수정된 DLL로 교체할 때만 필요합니다.

MongoDB와 Grafana 볼륨에 저장된 누적 수량·이력·로그인 설정을 이어 사용합니다. Simio는 다시 시작하면 공급·가열부터 시작하며 중간 동작의 자세가 그대로 복구되는 것은 아닙니다. 전달기는 새로운 Simio 세션의 증가분을 기존 AAS 누적값에 이어 붙입니다. 연결 전 Simio에서 생산된 수량을 과거 AAS 실적으로 소급하지 않습니다.

## 노트북을 닫았거나 Simio를 일시정지한 경우

절전·Simio 중단으로 원본 갱신이 3초 이상 끊기면 전달기가 종료됩니다. 재개 후 Simio가 진행 중인지 확인하고 Start_Simio_Team.bat을 다시 실행합니다. 모델을 초기화하거나 새로 열었을 때도 새 세션으로 다시 연결해야 합니다. 계속 기다려도 자동으로 Python 시뮬레이션으로 대체되지 않습니다.

단순 외부 인터넷 단절과 PC 절전은 다릅니다. 최초 이미지·플러그인 다운로드가 끝난 로컬 구성은 일상적인 데이터 통신에 외부 인터넷을 사용하지 않습니다. Docker Desktop이 멈췄다면 먼저 다시 켭니다.

## 상태만 확인

launch\Status_Simio_Team.bat은 컨테이너와 실제 AAS 수신 상태를 읽습니다. Simio를 대신 실행하지는 않습니다. 화면만 움직이는지보다 SIMIO LIVE 문구와 아래 5장의 원본 검증을 함께 확인합니다. 기본 이력은 최근 60개 기록의 순환 버퍼이며 장기간 전체 이력을 보관하는 시스템은 아닙니다.

<!-- PAGE -->

# 5 PowerShell 검증 명령

아래 명령은 압축을 푼 PET_Simio 폴더에서 실행합니다. 탐색기 주소창에 powershell을 입력하면 해당 위치에서 창이 열립니다. PC 전체 실행 정책을 바꾸지 않고 해당 스크립트만 실행합니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass `
  -File .\launch\Simio_Team.ps1 -Action Status
```

## 실제 AAS가 Simio 값을 받는지 확인

다음 명령을 실행해 3초 전후 Sequence가 증가하고 Session이 simio-로 시작하는지 확인합니다. Connection은 ConnectedSimulated, TimestampISO는 현재 시각에 가까워야 합니다. 브라우저의 실시간 복귀를 선택하면 해당 값으로 3D가 동작합니다.

```powershell
$m=Get-Content aas/twin_manifest.json -Raw -Encoding utf8 |
  ConvertFrom-Json
$b=[Text.Encoding]::UTF8.GetBytes($m.submodels.TwinRuntime)
$id=[Convert]::ToBase64String($b).TrimEnd('=')
$id=$id.Replace('+','-').Replace('/','_')
$u='http://127.0.0.1:8084/submodels/'+$id+
  '/submodel-elements/Current/%24value'
Invoke-RestMethod $u |
  Select-Object Session,Sequence,Connection,Phase,Produced
Start-Sleep -Seconds 3
Invoke-RestMethod $u |
  Select-Object Session,Sequence,Connection,Phase,Produced
```

## 원본 출력과 로그

Simio 출력은 Windows의 %LOCALAPPDATA%\PETSimio\Live에 생성됩니다. 파일 이름은 pet_live_simio-로 시작하며 실행마다 달라집니다. 전달기에는 이 폴더가 읽기 전용으로 연결됩니다. 모델이 멈추면 파일도 더 이상 갱신되지 않습니다.

```powershell
docker compose --env-file simio-team.local.env `
  -f docker-compose.simio-team.yml ps
docker compose --env-file simio-team.local.env `
  -f docker-compose.simio-team.yml logs --tail 80 `
  bridge aas-env grafana > simio_diagnostics.log
```

화면·발생 시각·최초 실행인지 여부·위 로그를 담당자에게 전달합니다. simio-team.local.env의 비밀번호는 보내지 않습니다.

<!-- PAGE -->

# 6 문제 해결과 배포 범위

| 증상 | 확인과 조치 |
|---|---|
| Simio에서 모델이 열리지 않음 | 학생 모델 호환성과 Simio 버전 확인. 라이선스 메시지를 담당자에게 전달 |
| Missing Step / PETTelemetry 없음 | Simio 종료 → Install_Simio_Extension.bat → 모델 다시 열기. DLL은 문서/SimioUserExtensions 바로 아래 |
| DLL 설치 실패 | 실행 중인 Simio를 닫았는지 확인. 설치 대상 경로와 오류를 전달 |
| WAIT_SIMIO / fresh sources=0 | Simio에서 정확한 모델 하나를 Shift+F6로 실행. 원본 폴더 갱신 확인 후 Start 재실행 |
| fresh sources가 2 이상 | PET 모델을 여러 개 실행했는지 확인. 하나만 실행한 뒤 오래된 파일이 신선도 범위를 벗어나도록 기다림 |
| Simio source stale / clock 오류 | 절전·일시정지·Simio 오류·PC 부하 확인. 원인 해소 후 Start 재실행 |
| 접근 거부 / 출력 파일 오류 | Simio 오류 원문과 보안 프로그램 로그 확인. 동봉된 최신 DLL인지 확인. 보호 기능을 임의로 해제하지 않음 |
| 포트 사용 중 | 3004/8084 충돌 확인. 기존 서비스를 임의로 삭제하지 않음 |
| Docker mount / 공유 오류 | simio-team.local.env의 출력 폴더가 현재 사용자 경로인지, Docker Desktop이 폴더를 읽을 수 있는지 확인 |
| 로그인 실패 | 해당 PC에서 생성된 simio-team.local.env 비밀번호 사용. env가 없다면 복구 요청, 볼륨 초기화 금지 |
| API 정상 / 발행 대기 | AAS만 준비됨. Simio 실행 상태와 bridge 로그 확인 |
| 패널 경고 / 조회 실패 | AAS·Grafana 로그와 aas-infinity 데이터소스 확인. Empty 데이터와 쿼리 실패를 구분 |
| PARTIAL_SEED / CD_CONFLICT | 기존 모델의 일부 적재나 정의 충돌. 자동 초기화하지 않고 로그 전달 |

## ZIP에 포함되는 것

저장된 Simio 모델, 자체 제작 C# 출력 확장 DLL과 소스, AAS 모델·매핑, 전달 코드, Grafana·3D 리소스, 실행 스크립트, 이 PDF와 편집 가능한 Markdown 가이드입니다. 프로젝트의 기존 Python 데모 소스는 참고용으로 보존될 수 있지만 Start_Simio_Team은 이를 실행하지 않습니다.

개인 비밀번호, 실시간 출력·운전 로그, 제작자 가상환경, Docker 데이터 볼륨, Simio 설치 프로그램·라이선스·제조사 DLL은 포함하지 않습니다. 새 팀원 PC는 별도 AAS 이력을 시작합니다. 제작자 PC의 누적 생산 실적이 ZIP을 통해 복제되지는 않습니다.

이 배포판은 Windows Simio와 같은 PC의 Docker Desktop을 기준으로 검증합니다. 설치 경로·보안 정책·Simio 에디션이 다른 PC에서는 위 순서로 확인해야 합니다. 일반 실행에 쓰는 파일은 이름에 Simio_Team이 있는 배치 파일입니다. Start_Team, Start_PET_Live는 이전 Python 환경용입니다.
