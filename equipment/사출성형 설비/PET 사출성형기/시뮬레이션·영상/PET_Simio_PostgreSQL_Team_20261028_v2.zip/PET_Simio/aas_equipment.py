"""PET mapping and bounded, asynchronous AAS writer. The engine never does I/O."""
import copy
import datetime
import json
import logging
import threading
import time
from collections import deque
from pathlib import Path
from aas_core import AasHttp,AasError,fmt,parse_value,element_value,iso_duration
import pet_config as cfg
from tools.aas_model import at,walk
from tools.make_twin_aasx import MAPPING,initial_snapshot

LOG=logging.getLogger(__name__)


def iso(ts): return datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')


def parse_snapshot(raw):
    defaults=initial_snapshot()
    if not isinstance(raw,dict) or set(raw)!=set(defaults): raise ValueError('runtime structure mismatch; migrate/reseed explicitly')
    out={k:parse_value(v,'xs:boolean' if isinstance(defaults[k],bool) else 'xs:long' if isinstance(defaults[k],int) else 'xs:double' if isinstance(defaults[k],float) else 'xs:string') for k,v in raw.items()}
    if any(v is None for v in out.values()): raise ValueError('invalid persisted runtime values')
    return out


class PetProfile:
    def __init__(self,manifest=None):
        self.manifest=manifest or cfg.manifest(); self.ids=self.manifest['submodels']
        env=json.loads((cfg.ROOT/'aas/PET_Twin.environment.json').read_text(encoding='utf-8'))
        self.models={s['idShort']:s for s in env['submodels']}
        self.mapping=json.loads((cfg.ROOT/'aas/property_mapping.json').read_text(encoding='utf-8'))

    def operational_groups(self,s):
        od=copy.deepcopy(self.models['OperationalData'])
        for m in self.mapping:
            if m['status']=='MAPPED_SIMULATION': at(od,m['path'])['value']=fmt(s[m['engine_key']],m['valueType'])
        # PUT full monitoring SMC preserves metadata and unset unmodeled properties.
        return [(p,e) for p,e in walk(od['submodelElements']) if p.count('.')==1 and e['modelType']=='SubmodelElementCollection' and any(m['status']=='MAPPED_SIMULATION' and m['path'].startswith(p+'.') for m in self.mapping)]

    def ts_records(self,history):
        records=copy.deepcopy(at(self.models['TimeSeries'],'Segments.InternalSegment.Records'))
        for slot,s in history.items():
            e=records['value'][slot]
            for _,field in walk(e['value']):
                name=field.get('idShort')
                if name=='Time': field['value']=str(int(round(s['SimTime'])))
                elif name in MAPPING and MAPPING[name][0] in s: field['value']=fmt(s[MAPPING[name][0]],field['valueType'])
        return records


class AasTwinWriter:
    def __init__(self,url,token='',profile=None,flush_s=None,timeout=None):
        self.profile=profile or PetProfile(); self.N=self.profile.manifest['slots']
        self.flush_s=cfg.TS_FLUSH_S if flush_s is None else flush_s
        self.http=AasHttp(url,token=token,timeout=cfg.TIMEOUT if timeout is None else timeout,retries=1)
        self.lock=threading.Lock(); self.wake=threading.Event(); self.closing=False
        self.latest=None; self.history={}; self.sent_sequence=-1; self.flushed_sequence=-1; self.persisted_sequence=-1
        self.metrics={'records_dropped':0,'errors':0,'auth_failures':0,'windows':0,'flushes':0,'connected':False,'lag_s':0.0}
        self.thread=None; self.initial=None

    def prepare(self,allow_stale=True):
        raw=self.http.get_value(self.profile.ids['TwinRuntime'],'Current')
        if raw is None: raise RuntimeError('PET runtime missing: seed the separate twin first')
        s=parse_snapshot(raw)
        if s['Connection']=='ConnectedSimulated' and time.time()-s['Timestamp']<cfg.STALE_S:
            raise RuntimeError('another active writer; one writer per equipment is required')
        if not allow_stale and s['Connection']!='Disconnected': raise RuntimeError('unclean prior shutdown')
        raw_history=self.http.get_value(self.profile.ids['TwinRuntime'],'History')
        if not isinstance(raw_history,dict) or len(raw_history)!=self.N: raise ValueError('ring size differs')
        for name,r in raw_history.items():
            # History omits pose/event payloads; reconstruct for type checking.
            row=parse_snapshot({**r,'Samples':'[]','Events':'[]'})
            if row['Sequence']>0: self.history[int(name[6:])]=row
        newest=max([s]+list(self.history.values()),key=lambda x:x['Sequence'])
        # Current may have committed one window ahead of History before an interruption.
        if newest['Sequence']>0: self.history[(newest['Sequence']-1)%self.N]=copy.deepcopy(newest)
        self.persisted_sequence=newest['Sequence']
        self.metrics['records_dropped']=newest['DroppedRecords']
        # History can have committed before a crash during the official TS write. Reconcile all retained slots once.
        self.initial=newest; self.sent_sequence=s['Sequence']; self.flushed_sequence=0
        return copy.deepcopy(newest)

    def configure_cycle_target(self,seconds):
        """Update only the simulation recipe target after the single-writer check."""
        if self.initial is None or self.thread is not None: raise RuntimeError('configure after prepare and before start')
        paths=[p for p,e in walk(self.profile.models['ProcessParameters']['submodelElements']) if e.get('idShort')=='CycleTimeTarget']
        if len(paths)!=1: raise ValueError('ambiguous cycle target mapping')
        sid=self.profile.ids['ProcessParameters'];path=paths[0];element=self.http.get(sid,path)
        if not element or element.get('modelType')!='Property' or element.get('valueType')!='xs:duration':
            raise ValueError('cycle target schema mismatch')
        target=iso_duration(seconds)
        if element.get('value')!=target:self.http.patch_value(sid,path,target)

    def start(self):
        if self.initial is None: raise RuntimeError('prepare before starting')
        self.thread=threading.Thread(target=self._loop,name='pet-aas-writer',daemon=True); self.thread.start()

    def add_sample(self,s):
        with self.lock:
            if self.closing: raise RuntimeError('writer is closing')
            if s['Sequence']<=max(self.persisted_sequence,self.latest['Sequence'] if self.latest else -1): return False
            slot=(s['Sequence']-1)%self.N; old=self.history.get(slot)
            if old and old['Sequence']>self.persisted_sequence:
                self.metrics['records_dropped']+=1
                LOG.warning('unsent record evicted; loss=%s',self.metrics['records_dropped'])
            s=copy.deepcopy(s); s['DroppedRecords']=self.metrics['records_dropped']
            self.latest=s; self.history[slot]=s; self.metrics['windows']+=1
        self.wake.set(); return True

    def set_process(self,s): return self.add_sample(s)

    def _flush(self,history,s):
        p=self.profile; rt=p.ids['TwinRuntime']
        # Existing slots only; idempotent PUT/PATCH. No runtime POST and no duplicate append.
        empty={k:v for k,v in initial_snapshot().items() if k not in ('Samples','Events')}
        values={f'Record{i:04d}':{k:v for k,v in history.get(i,empty).items() if k not in ('Samples','Events')} for i in range(self.N)}
        self.http.patch_value(rt,'History',values)
        records=p.ts_records(history)
        for slot,row in history.items():
            if row['Sequence']>self.flushed_sequence:
                self.http.put(p.ids['TimeSeries'],f'Segments.InternalSegment.Records.Record{slot:04d}',records['value'][slot])
        ordered=sorted(history.values(),key=lambda r:r['Sequence'])
        if ordered:
            first,last=ordered[0],ordered[-1]
            # Reference relative Time is seconds from the same simulation origin.
            origin=last['Timestamp']-last['SimTime']
            meta={'RecordCount':len(ordered),'StartTime':iso(origin),'EndTime':iso(last['Timestamp']),'Duration':'PT'+str(last['SimTime'])+'S','State':'running' if s['Connection']=='ConnectedSimulated' else 'completed','LastUpdate':iso(time.time())}
            for k,v in meta.items(): self.http.patch_value(p.ids['TimeSeries'],'Segments.InternalSegment.'+k,v)
        for path,body in p.operational_groups(s): self.http.put(p.ids['OperationalData'],path,body)
        with self.lock:
            self.flushed_sequence=s['Sequence']; self.persisted_sequence=max(self.persisted_sequence,s['Sequence']); self.metrics['flushes']+=1

    def _loop(self):
        next_flush=0.0; failure_delay=0.2
        while True:
            self.wake.wait(0.1); self.wake.clear()
            with self.lock:
                s=copy.deepcopy(self.latest); history=copy.deepcopy(self.history); closing=self.closing
            if s is None:
                if closing: return
                continue
            try:
                if closing: s['Connection']='Disconnected'
                if s['Sequence']!=self.sent_sequence or closing:
                    self.http.patch_value(self.profile.ids['TwinRuntime'],'Current',s)
                    self.sent_sequence=s['Sequence']
                if closing or time.monotonic()>=next_flush:
                    self._flush(history,s); next_flush=time.monotonic()+self.flush_s
                self.metrics['connected']=True; self.metrics['lag_s']=max(0,time.time()-s['Timestamp']); failure_delay=0.2
                if closing: self.http.close(); return
            except (AasError,ConnectionError,OSError) as exc:
                self.metrics['connected']=False; self.metrics['errors']+=1
                if isinstance(exc,AasError) and exc.status in (401,403): self.metrics['auth_failures']+=1
                LOG.warning('AAS write failed (%s); buffered=%s, lost=%s',getattr(exc,'status',type(exc).__name__),len(history),self.metrics['records_dropped'])
                time.sleep(failure_delay); failure_delay=min(5,failure_delay*2)

    def stats(self):
        with self.lock: m=dict(self.metrics)
        m.update(requests=self.http.n_req,bytes_out=self.http.bytes_out,retries=self.http.n_retry,connection_errors=self.http.n_conn_err,request_ms_max=self.http.ms_max,sent_sequence=self.sent_sequence,flushed_sequence=self.flushed_sequence)
        return m

    def close(self,timeout=10):
        with self.lock: self.closing=True
        self.wake.set()
        if self.thread: self.thread.join(timeout)
        return not (self.thread and self.thread.is_alive())
