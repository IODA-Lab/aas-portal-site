"""AAS consumer: compute session KPIs, explicitly expose unavailable RUL."""
import argparse
import time
import json
import pet_config as cfg
from aas_core import AasHttp
from aas_equipment import parse_snapshot
from kpi import compute
from tools.aas_model import walk


def step(h,m):
    s=parse_snapshot(h.get_value(m['submodels']['TwinRuntime'],'Current'))
    fresh=s['Connection']=='ConnectedSimulated' and 0<=time.time()-s['Timestamp']<=cfg.STALE_S
    out={**compute(s),'Status':'Computed' if fresh else 'Stale','SourceSequence':s['Sequence'],'RULStatus':'NotImplemented','Timestamp':time.time()}
    h.patch_value(m['submodels']['TwinRuntime'],'Analytics',out)
    # Only quantities with matching definitions; no invented shift-time/OEE variables.
    pvm_id=m['submodels'].get('ProcessVariablesForManufacturingKPICalculation')
    if pvm_id:
        pvm=h.get(pvm_id)
        for path,e in walk(pvm.get('submodelElements',[])):
            if e.get('modelType')!='SubmodelElementCollection':continue
            key=next((x.get('value') for x in e.get('value',[]) if x.get('idShort')=='key'),None)
            if key in ('PQ','GQ','SQ'):
                h.patch_value(pvm_id,path+'.currentValue',s[{'PQ':'Produced','GQ':'Good','SQ':'Reject'}[key]])
    return out


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--once',action='store_true'); p.add_argument('--period',type=float,default=10); p.add_argument('--aas-url',default=cfg.AAS_URL); a=p.parse_args()
    h=AasHttp(cfg.validate_url(a.aas_url,write=True),token=cfg.token()); m=cfg.manifest()
    try:
        while True:
            try: print(json.dumps(step(h,m)),flush=True)
            except (ConnectionError,RuntimeError,ValueError) as e:
                print(type(e).__name__,flush=True)
                if a.once: raise SystemExit(1)
            if a.once: break
            time.sleep(max(1,a.period))
    except KeyboardInterrupt: pass
    finally: h.close()
