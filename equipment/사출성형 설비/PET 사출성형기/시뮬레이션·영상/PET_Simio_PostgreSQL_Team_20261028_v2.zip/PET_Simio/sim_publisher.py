"""Offline or AAS-connected PET synthetic equipment. Ctrl+C drains the writer."""
import argparse
import json
import logging
import sys
import time
import uuid
from pathlib import Path
import pet_config as cfg
from model.pet_process import PetProcess
from aas_equipment import AasTwinWriter,iso
from tools.make_twin_aasx import initial_snapshot


def run(args):
    mode=args.mode; writer=None; initial=None
    if mode!='offline':
        if args.fast or args.speed!=1: raise ValueError('network publication requires realtime 1x; accelerated playback is offline only')
        url=cfg.validate_url(args.aas_url or cfg.AAS_URL,write=True,local=mode=='local')
        writer=AasTwinWriter(url,token=cfg.token()); initial=writer.prepare()
    eng=PetProcess(seed=args.seed,scenario=args.scenario,init=initial)
    if writer:
        try:
            writer.configure_cycle_target(sum(eng.duration(i) for i in range(2,len(eng.steps))))
            writer.start()
        except Exception:
            writer.http.close();raise
    start_t=eng.t; start_cycles=eng.completed_cycles; wall0=time.time(); mono0=time.monotonic()
    session=str(uuid.uuid4()); seq=initial['Sequence'] if initial else 0
    started=iso(wall0-start_t); next_window=eng.t+eng.cfg['publish_s']; samples=[]; events=[]
    f=None
    if args.output:
        path=Path(args.output); path.parent.mkdir(parents=True,exist_ok=True); f=path.open('w',encoding='utf-8')
    last=initial_snapshot(); ticks=0; max_step=0; last_stats=time.monotonic(); result=0
    def emit():
        nonlocal seq,last,samples,events
        seq+=1
        ts=wall0+(eng.t-start_t)/args.speed if mode=='offline' else time.time()
        last={**eng.state(),'Timestamp':ts,'TimestampISO':iso(ts),'StartedISO':started,'Sequence':seq,'Session':session,'Connection':'ConnectedSimulated','Samples':json.dumps(samples,separators=(',',':')),'Events':json.dumps(events,separators=(',',':')),'DroppedRecords':0}
        if writer: writer.add_sample(last)
        if f: f.write(json.dumps(last,ensure_ascii=False)+'\n')
        samples=[]; events=[]
    try:
        while not args.cycles or eng.completed_cycles-start_cycles<args.cycles:
            if getattr(args,'stop_file',None) and Path(args.stop_file).is_file():
                print('Stop requested; flushing last window and disconnecting.',flush=True); break
            if args.seconds and eng.t-start_t>=args.seconds: break
            if not args.fast:
                delay=mono0+(eng.t-start_t+eng.tick)/args.speed-time.monotonic()
                if delay>0: time.sleep(delay)
            t0=time.perf_counter(); eng.step(); max_step=max(max_step,(time.perf_counter()-t0)*1000); ticks+=1
            events.extend(eng.events)
            if ticks%max(1,round(eng.hz/eng.cfg['pose_hz']))==0: samples.append(eng.state())
            for ev in eng.events:
                if ev['type'] in ('cycle_done','alarm'): print(json.dumps(ev,ensure_ascii=False),flush=True)
            if eng.t+1e-9>=next_window: emit(); next_window+=eng.cfg['publish_s']
            if eng.mode=='Alarm' and not args.seconds:
                print('Alarm latched; use a bounded --seconds fault demonstration.'); result=2; break
            if time.monotonic()-last_stats>=10:
                print(json.dumps(writer.stats() if writer else {'mode':'offline','sim_s':eng.t}),flush=True); last_stats=time.monotonic()
    except KeyboardInterrupt:
        print('Stopping and flushing...')
    finally:
        emit()
        if writer and not writer.close(timeout=args.flush_timeout): result=3
        if f: f.close()
    stats={'mode':mode,'sim_s':eng.t,'cycles':eng.completed_cycles-start_cycles,'produced':eng.produced,'good':eng.good,'reject':eng.reject,'max_step_ms':max_step,'writer':writer.stats() if writer else None,'exit_code':result}
    if args.stats_json:
        p=Path(args.stats_json); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(stats,indent=2),encoding='utf-8')
    print(json.dumps(stats,ensure_ascii=False,indent=2)); return result


def main():
    p=argparse.ArgumentParser(); p.add_argument('--mode',choices=['offline','local','live'],default=cfg.TWIN_MODE); p.add_argument('--aas-url',default=''); p.add_argument('--cycles',type=int,default=0); p.add_argument('--seconds',type=float,default=0); p.add_argument('--seed',type=int,default=0); p.add_argument('--speed',type=float,default=1); p.add_argument('--fast',action='store_true'); p.add_argument('--scenario',choices=['normal','cooling_failure','overpressure','overheat','interlock'],default='normal'); p.add_argument('--output'); p.add_argument('--stats-json'); p.add_argument('--flush-timeout',type=float,default=10)
    p.add_argument('--stop-file',help='optional local stop signal; same final flush as Ctrl+C')
    a=p.parse_args()
    if a.speed<=0 or a.cycles<0 or a.seconds<0: p.error('invalid duration or speed')
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    try: return run(a)
    except (ValueError,RuntimeError,ConnectionError) as e: print(type(e).__name__+': '+str(e),file=sys.stderr); return 1


if __name__=='__main__': sys.exit(main())
