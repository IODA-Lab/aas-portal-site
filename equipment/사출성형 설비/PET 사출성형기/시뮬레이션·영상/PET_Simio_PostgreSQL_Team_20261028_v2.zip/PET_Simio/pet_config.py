"""PET-only settings. Environment overrides equipment.env; no remote default."""
import json
import os
import math
from pathlib import Path
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parent


def load_env_file(path):
    if not path or not Path(path).is_file(): return
    for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
        line=line.strip()
        if line and not line.startswith('#') and '=' in line:
            k,v=line.split('=',1)
            if k.strip().startswith('PET_'): os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))


load_env_file(os.environ.get('PET_ENV_FILE',str(ROOT/'equipment.env')))


def number(name,default,lo,hi,integer=False):
    v=float(os.environ.get(name,default))
    if not math.isfinite(v) or not lo<=v<=hi or (integer and int(v)!=v): raise ValueError(name+' out of range')
    return int(v) if integer else v


def manifest():
    p=ROOT/'aas/twin_manifest.json'
    if not p.exists(): raise RuntimeError('PENDING_AASX: run tools/make_twin_aasx.py with a real PET source')
    m=json.loads(p.read_text(encoding='utf-8'))
    if m['equipment_id']!=EQUIPMENT_ID: raise ValueError('rebuild twin for PET_EQUIPMENT_ID')
    if m['slots']!=TS_MAX_RECORDS: raise ValueError('ring size differs: rebuild twin before seeding a new server')
    return m


def validate_url(url,write=False,local=False):
    u=urlsplit(url)
    if not u.hostname or u.username or u.password or u.query or u.fragment: raise ValueError('explicit clean AAS URL required')
    loopback=u.hostname in ('127.0.0.1','localhost','::1')
    internal=os.environ.get('PET_ALLOW_INTERNAL_HTTP')=='1' and u.hostname in ('aas-env','pet-fake-aas','aas-ro')
    if u.scheme!='https' and not (u.scheme=='http' and (loopback or internal)): raise ValueError('remote AAS requires HTTPS')
    if local and not loopback: raise ValueError('local test requires loopback AAS')
    if write and not loopback and not internal and not token(): raise ValueError('PET_AAS_TOKEN is required')
    return url.rstrip('/')


def token(): return os.environ.get('PET_AAS_TOKEN','').strip()


AAS_URL=os.environ.get('PET_AAS_URL','').rstrip('/')
EQUIPMENT_ID=os.environ.get('PET_EQUIPMENT_ID','PET-SIM-01')
TWIN_MODE=os.environ.get('PET_TWIN_MODE','offline')
if TWIN_MODE not in ('offline','local','live'): raise ValueError('PET_TWIN_MODE must be offline|local|live')
TS_MAX_RECORDS=number('PET_TS_MAX_RECORDS',60,2,1200,True)
TS_FLUSH_S=number('PET_TS_FLUSH_S',5,1,60)
TIMEOUT=number('PET_AAS_TIMEOUT',2,0.1,30)
STALE_S=number('PET_STALE_S',5,2,60)


if __name__=='__main__':
    print(json.dumps({'PET_AAS_URL':AAS_URL,'PET_AAS_TOKEN':'set' if token() else 'absent','PET_EQUIPMENT_ID':EQUIPMENT_ID,'PET_TWIN_MODE':TWIN_MODE,'PET_TS_MAX_RECORDS':TS_MAX_RECORDS,'PET_TS_FLUSH_S':TS_FLUSH_S},indent=2))
