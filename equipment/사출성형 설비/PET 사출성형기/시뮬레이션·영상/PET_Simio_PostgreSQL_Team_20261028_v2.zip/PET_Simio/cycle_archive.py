"""Durable Simio observations awaiting PostgreSQL. No simulation calculations."""
import json
import sqlite3
import time
from pathlib import Path


class Outbox:
    def __init__(self,path):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(path,timeout=5)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS pending (id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL, created REAL NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS status (name TEXT PRIMARY KEY, value TEXT NOT NULL)')
        self.db.commit()

    def put(self,kind,event):
        number=event['sample_index'] if kind=='telemetry' else event['cycle_number']
        key=f"{event['equipment_id']}:{event['session']}:{kind}:{number}"
        encoded=json.dumps(event,separators=(',',':'),allow_nan=False)
        with self.db:self.db.execute('INSERT OR IGNORE INTO pending VALUES (?,?,?,?)',(key,kind,encoded,time.time()))

    def batch(self,limit=100):
        return self.db.execute('SELECT id,kind,payload FROM pending ORDER BY created,id LIMIT ?',(limit,)).fetchall()

    def acknowledge(self,rows):
        with self.db:self.db.executemany('DELETE FROM pending WHERE id=?',[(row[0],) for row in rows])

    def count(self):return self.db.execute('SELECT count(*) FROM pending').fetchone()[0]

    def set_status(self,**values):
        with self.db:
            self.db.execute('INSERT INTO status VALUES (?,?) ON CONFLICT(name) DO UPDATE SET value=excluded.value',('archive',json.dumps(values)))

    def status(self):
        row=self.db.execute('SELECT value FROM status WHERE name=?',('archive',)).fetchone()
        return {**(json.loads(row[0]) if row else {}),'pending':self.count()}

    def close(self):self.db.close()


class CycleTracker:
    def __init__(self,equipment,packet):
        self.equipment=equipment
        self.session=packet['session']
        raw=packet['samples'][-1]
        self.cycle=int(raw['CompletedCycles'])
        self.full_cycle=raw['Phase'] in ('Feed','Warmup') and self.cycle==0
        # A bridge can attach after ejection but before completion. In that
        # case the first batch's good/reject counts cannot be reconstructed.
        self.totals=tuple(raw[k] for k in ('Produced','Good','Reject')) if raw['Produced']==self.cycle*raw['Cavities'] else None

    def observe(self,raw,aas_values):
        cycle=int(raw['CompletedCycles'])
        if cycle==self.cycle:return None
        if cycle!=self.cycle+1:raise ValueError('cycle counter gap; missing cycles are not fabricated')
        totals=tuple(int(raw[k]) for k in ('Produced','Good','Reject'))
        delta=tuple(n-p for n,p in zip(totals,self.totals)) if self.totals is not None else None
        if delta and (min(delta)<0 or delta[0]!=delta[1]+delta[2]):raise ValueError('invalid cycle quantity delta')
        event={'equipment_id':self.equipment,'session':self.session,'sample_index':int(raw['SampleIndex']),
               'cycle_number':cycle,'received_at':time.time(),'source_sim_s':raw['SimTime'],
               'cycle_time_s':raw['CycleTime'],'batch_produced':delta[0] if delta else None,
               'batch_good':delta[1] if delta else None,'batch_reject':delta[2] if delta else None,
               'observed_full_cycle':self.full_cycle,'native':dict(raw),'aas_values':dict(aas_values)}
        self.cycle=cycle;self.totals=totals;self.full_cycle=True
        return event


def telemetry_event(equipment,raw,snapshot):
    return {'equipment_id':equipment,'session':snapshot['Session'],'sample_index':int(raw['SampleIndex']),
            'cycle_number':int(raw['CompletedCycles']),'source_sim_s':raw['SimTime'],
            'received_at':snapshot['Timestamp'],
            'aas_values':{k:v for k,v in snapshot.items() if k not in ('Samples','Events')}}


def flush_once(outbox,sink):
    rows=outbox.batch()
    if not rows:return 0
    sink.write(rows)  # Returns only after the PostgreSQL transaction commits.
    outbox.acknowledge(rows)
    return len(rows)
