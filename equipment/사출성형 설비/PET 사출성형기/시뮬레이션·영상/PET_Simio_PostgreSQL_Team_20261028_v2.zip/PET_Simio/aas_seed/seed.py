"""Non-destructive AASX seed. All IDs absent -> create; all present -> skip; mixed -> stop."""
import argparse
import json
import sys
import uuid
import urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
import pet_config as cfg
from aas_core import AasHttp,b64,AasError
from tools.aas_model import read_aasx


def seed(http,env,aasx=None,concept_descriptions=False):
    items=[('submodels',s) for s in env['submodels']]+[('shells',s) for s in env['assetAdministrationShells']]
    present=[]
    for kind,obj in items:
        status,_=http.request('GET',f'/{kind}/{b64(obj["id"])}')
        if status not in (200,404): raise RuntimeError('seed preflight HTTP '+str(status))
        present.append(status==200)
    if all(present): return 'SKIP_ALREADY_PRESENT'
    if any(present): raise RuntimeError('PARTIAL_SEED: inspect/backup existing IDs before explicit repair; no overwrite')
    if concept_descriptions:
        # Shared CDs may already exist. Never overwrite a conflicting definition.
        missing=[]
        for cd in env.get('conceptDescriptions',[]):
            status,body=http.request('GET','/concept-descriptions/'+b64(cd['id']))
            if status==404: missing.append(cd)
            elif status==200:
                existing=json.loads(body) if isinstance(body,(bytes,str)) else body
                def normalized(v):
                    if isinstance(v,dict):return {k:normalized(x) for k,x in v.items() if x not in (None,[],{}) and k!='modelType'}
                    if isinstance(v,list):return [normalized(x) for x in v]
                    return v
                if normalized(existing)!=normalized(cd):raise RuntimeError('CD_CONFLICT: '+cd['id'])
            else:raise RuntimeError('ConceptDescription preflight HTTP '+str(status))
        for cd in missing:
            status,_=http.request('POST','/concept-descriptions',cd,retries=0)
            if status not in (200,201,204):raise RuntimeError('CD seed failed HTTP '+str(status)+'; inspect existing IDs before retry')
    if aasx:
        # BaSyx's package upload keeps ConceptDescriptions and supplementary package files.
        boundary=uuid.uuid4().hex
        body=(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="PET_Twin.aasx"\r\nContent-Type: application/asset-administration-shell-package\r\n\r\n').encode()+Path(aasx).read_bytes()+f'\r\n--{boundary}--\r\n'.encode()
        headers={'Content-Type':'multipart/form-data; boundary='+boundary,**http._auth}
        request=urllib.request.Request(http.base_url+'/upload',data=body,method='POST',headers=headers)
        with urllib.request.urlopen(request,timeout=60) as response:
            if response.status not in (200,201,204):raise RuntimeError('package upload failed')
        for kind,obj in items:
            status,_=http.request('GET',f'/{kind}/{b64(obj["id"])}')
            if status!=200:raise RuntimeError('package uploaded but identifiers not present; inspect server')
        return 'PACKAGE_UPLOADED'
    for kind,obj in items:
        status,_=http.request('POST','/'+kind,obj,retries=0)
        if status not in (200,201,204): raise RuntimeError('seed failed HTTP '+str(status)+'; inspect partial seed before retry')
    # Concept descriptions are carried by the AASX package; generic repository APIs do not expose them uniformly.
    return 'REPOSITORY_CREATED_ATTACHMENTS_NOT_UPLOADED' if concept_descriptions else 'CREATED'


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--aas-url',default=cfg.AAS_URL); p.add_argument('--aasx',type=Path,default=ROOT/'aas/PET_Twin.aasx'); p.add_argument('--apply',action='store_true'); p.add_argument('--repository',action='store_true',help='explicit BaSyx repository seed including CDs; supplementary files are NOT uploaded'); p.add_argument('--fake-rest',action='store_true',help='test-only generic REST seed; no supplementary-file upload'); a=p.parse_args()
    env,_=read_aasx(a.aasx)
    if not a.apply:
        print(json.dumps({'status':'PLAN_ONLY','aas':[s['id'] for s in env['assetAdministrationShells']],'submodels':[s['id'] for s in env['submodels']]},indent=2))
    else:
        h=AasHttp(cfg.validate_url(a.aas_url,write=True),token=cfg.token())
        try: print(seed(h,env,None if (a.fake_rest or a.repository) else a.aasx,concept_descriptions=a.repository))
        except urllib.error.HTTPError as e:
            if e.code==413:
                print('UPLOAD_TOO_LARGE: BaSyx multipart size limit. No automatic reset or retry. Use --repository explicitly to seed AAS/Submodels/CDs without supplementary files, or ask the server administrator to review upload limits.',file=sys.stderr)
                sys.exit(2)
            raise
        finally: h.close()
