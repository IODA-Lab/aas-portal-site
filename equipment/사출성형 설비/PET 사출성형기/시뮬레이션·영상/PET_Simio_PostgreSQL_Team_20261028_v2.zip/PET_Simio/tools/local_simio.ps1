param(
    [ValidateSet('Start','Stop','Status')][string]$Action='Status',
    [string]$AasUrl='http://localhost:8081'
)
$ErrorActionPreference='Stop'
$PetProjectRoot=Split-Path -Parent $PSScriptRoot
$out=Join-Path $PetProjectRoot 'output'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$statePath=Join-Path $out 'local-simio.json'
$state=$null; $proc=$null
if(Test-Path -LiteralPath $statePath){
    $state=Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $candidate=Get-Process -Id $state.pid -ErrorAction SilentlyContinue
    if($candidate -and $candidate.ProcessName -match '^python' -and $candidate.StartTime.ToUniversalTime().ToString('o') -eq $state.started){$proc=$candidate}
}
if($Action -eq 'Status'){
    if($proc){Write-Output "SIMIO BRIDGE RUNNING PID=$($state.pid) URL=$($state.aasUrl)"}else{Write-Output 'SIMIO BRIDGE STOPPED'}
    exit 0
}
if($Action -eq 'Stop'){
    if(-not $proc){Write-Output 'Already stopped';exit 0}
    if($state.stopFile -notmatch '^local-simio-[a-f0-9-]+\.stop$'){throw 'Invalid stop filename'}
    [IO.File]::WriteAllText((Join-Path $out $state.stopFile),'stop')
    if(-not $proc.WaitForExit(20000)){throw 'Bridge still flushing. No forced termination performed.'}
    Write-Output 'Simio bridge stopped; AAS history retained.'
    exit 0
}
if($proc){Write-Output "Already running PID=$($state.pid)";exit 0}
$python=Join-Path $PetProjectRoot '.venv/Scripts/python.exe'
if(-not(Test-Path -LiteralPath $python)){$python=(Get-Command python).Source}
Push-Location $PetProjectRoot
try{
    # Confirm this is the PET model before stopping the legacy writer.
    & $python -X utf8 simio_bridge.py --check-source
    if($LASTEXITCODE -ne 0){throw 'Simio source is not fresh realtime data. The previous Python writer was retained.'}
    & powershell -NoProfile -ExecutionPolicy Bypass -File tools/local_publisher.ps1 -Action Stop
    if($LASTEXITCODE -ne 0){throw 'Existing Python writer did not stop cleanly.'}
    $runId=[Guid]::NewGuid().ToString()
    $stopName="local-simio-$runId.stop"
    $log=Join-Path $out "local-simio-$runId.log"
    $err=Join-Path $out "local-simio-$runId.err.log"
    $argsList=@('-u','-X','utf8','simio_bridge.py','--aas-url',$AasUrl,'--stop-file',('"'+(Join-Path $out $stopName)+'"'))
    $started=Start-Process -FilePath $python -ArgumentList $argsList -WorkingDirectory $PetProjectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $log -RedirectStandardError $err
    @{pid=$started.Id;started=$started.StartTime.ToUniversalTime().ToString('o');aasUrl=$AasUrl;stopFile=$stopName;log=$log;errorLog=$err} | ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding utf8
    Start-Sleep -Seconds 6
    if($started.HasExited){Get-Content -LiteralPath $err;throw "Simio bridge exited: $($started.ExitCode)"}
    Write-Output "SIMIO BRIDGE RUNNING PID=$($started.Id); log=$log"
}finally{Pop-Location}
