"""Compare every extracted reference file against its untouched input ZIP."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def audit(archive,originals,pet_source=None,pet_copy=None):
    results=[];base=originals.resolve()
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            if item.is_dir():continue
            p=(base/item.filename).resolve()
            if not p.is_relative_to(base):raise ValueError('archive path outside original directory')
            digest=hashlib.sha256(z.read(item)).hexdigest()
            actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
            results.append({'path':item.filename,'sha256':digest,'unchanged':digest==actual})
    pet=None
    if pet_source and pet_copy:
        a=hashlib.sha256(pet_source.read_bytes()).hexdigest();b=hashlib.sha256(pet_copy.read_bytes()).hexdigest()
        pet={'source_sha256':a,'copy_sha256':b,'unchanged':a==b}
    return {'status':'PASS' if all(x['unchanged'] for x in results) and (pet is None or pet['unchanged']) else 'FAIL','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files_checked':len(results),'pet_reference':pet,'files':results}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--zip',type=Path,required=True);p.add_argument('--originals',type=Path,required=True);p.add_argument('--pet-source',type=Path);p.add_argument('--pet-copy',type=Path);p.add_argument('--out',type=Path,default=Path('output/original_integrity.json'));a=p.parse_args()
    r=audit(a.zip,a.originals,a.pet_source,a.pet_copy);a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in r.items() if k!='files'},ensure_ascii=False));raise SystemExit(r['status']!='PASS')
