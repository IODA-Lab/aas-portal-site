"""Read-only Docker/BaSyx/Grafana diagnostics. No reset, seed, restart, or writes."""
import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from aas_core import b64
from aas_equipment import parse_snapshot
from tools.aas_model import at,walk
import pet_config as cfg


def fetch(url,token=''):
    req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token} if token else {})
    try:
        with urllib.request.urlopen(req,timeout=8) as r:return r.status,json.load(r)
    except urllib.error.HTTPError as e:return e.code,{'error':str(e)}
    except (OSError,ValueError) as e:return 0,{'error':type(e).__name__+': '+str(e)}


def publication_state(s,now=None):
    now=time.time() if now is None else now
    if s['Sequence']==0:return 'NO_DATA'
    if s['Connection']!='ConnectedSimulated':return 'STOPPED'
    age=now-s['Timestamp']
    if age < -2:return 'CLOCK_SKEW'
    if age >= 5:return 'STALE'
    return 'LIVE'


def check(a):
    m=cfg.manifest();report={'aas_url':a.aas_url,'grafana_url':a.grafana_url,'checks':[]};checks=report['checks']
    def add(name,status,**kw):checks.append({'check':name,'status':status,**kw})
    try:
        raw=subprocess.run(['docker','inspect',a.grafana_container,a.aas_container,'--format','{{json .NetworkSettings.Networks}}'],capture_output=True,text=True,timeout=15,check=True)
        networks=[json.loads(s) for s in raw.stdout.splitlines()];shared=set(networks[0])&set(networks[1]);dns=shared-{'bridge','host','none'}
        add('docker_shared_dns_network','PASS' if dns else 'FAIL',shared=sorted(shared),dns_networks=sorted(dns))
        probe=subprocess.run(['docker','exec',a.grafana_container,'wget','-q','-O','/dev/null',a.aas_internal+'/shells'],capture_output=True,text=True,timeout=15)
        add('grafana_to_aas_http','PASS' if probe.returncode==0 else 'FAIL',exit_code=probe.returncode,error=probe.stderr.strip()[:500])
    except (OSError,subprocess.SubprocessError,ValueError) as e:add('docker_access','UNVERIFIED',error=str(e)[:500])
    for kind,name,id in [('shells','AAS',m['aas_id'])]+[('submodels',k,v) for k,v in m['submodels'].items()]:
        status,_=fetch(a.aas_url+'/'+kind+'/'+b64(id),cfg.token());add('model:'+name,'PASS' if status==200 else 'FAIL',http=status)
    rt=a.aas_url+'/submodels/'+b64(m['submodels']['TwinRuntime'])+'/submodel-elements/'
    st,current=fetch(rt+'Current/%24value',cfg.token());snapshot=None
    if st==200:
        try:
            snapshot=parse_snapshot(current);code=publication_state(snapshot)
            add('current_query','PASS',path=rt+'Current/%24value',publication=code,sequence=snapshot['Sequence'],produced=snapshot['Produced'],cycles=snapshot['CompletedCycles'],connection=snapshot['Connection'],age_s=round(time.time()-snapshot['Timestamp'],3))
            if a.interval>0:
                time.sleep(a.interval);st2,raw=fetch(rt+'Current/%24value',cfg.token());after=parse_snapshot(raw) if st2==200 else None
                updating=bool(after and after['Sequence']>snapshot['Sequence'] and publication_state(after)=='LIVE')
                add('publisher_advancing','PASS' if updating else 'FAIL' if a.require_updating else 'WARN',before=snapshot['Sequence'],after=after['Sequence'] if after else None)
        except (ValueError,KeyError,TypeError) as e:add('current_schema','FAIL',error=str(e))
    else:add('current_query','FAIL',http=st,error=current.get('error'))
    st,hist=fetch(rt+'History/%24value',cfg.token())
    if st==200 and isinstance(hist,dict):
        seq=[int(r.get('Sequence',0)) for r in hist.values() if int(r.get('Sequence',0))>0]
        add('history_query','PASS',slots=len(hist),records=len(seq),unique=len(seq)==len(set(seq)),last_sequence=max(seq,default=0))
    else:add('history_query','FAIL',http=st)
    # Read each real OD path from the server's full model, not inferred path labels.
    st,od=fetch(a.aas_url+'/submodels/'+b64(m['submodels']['OperationalData']),cfg.token())
    mappings=json.loads((ROOT/'aas/property_mapping.json').read_text(encoding='utf-8'));errors=[];values={}
    for row in mappings:
        if row['status']!='MAPPED_SIMULATION':continue
        el=at(od,row['path']) if st==200 else None
        if not el or el.get('valueType')!=row['valueType'] or el.get('semanticId')!=row['semanticId']:errors.append(row['path'])
        else:values[row['path']]=el.get('value')
    add('operational_property_paths','PASS' if not errors else 'FAIL',mapped=len(values),errors=errors,values=values)
    status,health=fetch(a.grafana_url+'/api/health');add('grafana_health','PASS' if status==200 and health.get('database')=='ok' else 'FAIL',http=status,version=health.get('version'))
    status,ds=fetch(a.grafana_url+'/api/datasources/uid/aas-infinity',os.getenv('PET_GRAFANA_TOKEN',''))
    if status==401:add('grafana_datasource','AUTH_REQUIRED',detail='Logged-in UI: AAS-Server / aas-infinity. Optional PET_GRAFANA_TOKEN enables API check; never use the AAS token here.')
    else:add('grafana_datasource','PASS' if status==200 and ds.get('name')=='AAS-Server' and ds.get('type')=='yesoreyeram-infinity-datasource' and a.aas_internal in ds.get('jsonData',{}).get('allowedHosts',[]) else 'FAIL',http=status,name=ds.get('name'),uid=ds.get('uid'))
    dashboard=json.loads((ROOT/'grafana/dashboards/pet_dashboard.json').read_text(encoding='utf-8'))
    targets=[t for p in dashboard['panels'] for t in p.get('targets',[]) if t.get('source')=='url']
    expected=a.aas_internal+'/submodels/'+b64(m['submodels']['TwinRuntime'])+'/submodel-elements/'
    ok=len(targets)==2 and all(t['datasource']['uid']=='aas-infinity' and t['url'] in (expected+'Current/%24value',expected+'History/%24value') for t in targets)
    add('dashboard_contract','PASS' if ok else 'FAIL',queries=[{'url':t['url'],'uid':t['datasource']['uid']} for t in targets])
    report['status']='FAIL' if any(c['status']=='FAIL' for c in checks) else 'PASS_WITH_AUTH_REQUIRED' if any(c['status'] in ('AUTH_REQUIRED','UNVERIFIED') for c in checks) else 'PASS'
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--aas-url',default='http://localhost:8081');p.add_argument('--aas-internal',default='http://aas-env:8081');p.add_argument('--grafana-url',default='http://localhost:3000');p.add_argument('--grafana-container',default='pet-grafana');p.add_argument('--aas-container',default='aas-env');p.add_argument('--interval',type=float,default=2);p.add_argument('--require-updating',action='store_true');p.add_argument('--out',type=Path,default=ROOT/'output/local_stack_check.json');a=p.parse_args()
    if not 0<=a.interval<=30:p.error('interval must be 0..30 seconds')
    cfg.validate_url(a.aas_url);r=check(a);a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(r,ensure_ascii=False,indent=2));sys.exit(r['status']=='FAIL')
