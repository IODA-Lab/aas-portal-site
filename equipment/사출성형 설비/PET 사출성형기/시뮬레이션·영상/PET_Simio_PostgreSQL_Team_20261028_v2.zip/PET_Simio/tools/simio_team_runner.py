"""Seed an isolated team AAS, then relay native Simio; no Python process engine."""
import argparse
import signal
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pet_config as cfg
from aas_core import AasHttp
from aas_seed.seed import seed
from tools.aas_model import read_aasx
from simio_bridge import discover_packet, run


def interrupted(*_):
    raise KeyboardInterrupt


def main():
    signal.signal(signal.SIGTERM,interrupted)
    http=AasHttp(cfg.AAS_URL,timeout=3,retries=0)
    try:
        for _ in range(90):
            try:
                status,_=http.request('GET','/shells')
                if status==200:break
            except (ConnectionError,OSError):pass
            time.sleep(2)
        else:raise RuntimeError('BaSyx unavailable; check aas-env logs')
        environment,_=read_aasx(cfg.ROOT/'aas/PET_Twin.aasx')
        print(seed(http,environment,concept_descriptions=True),flush=True)
    finally:
        http.close()
    for attempt in range(90):
        try:
            discover_packet()
            break
        except (ValueError,OSError,KeyError):
            if attempt%10==0:print('WAIT_SIMIO: open PET_24Cavity_27_5s.spfx and press Shift+F6 on Windows.',flush=True)
            time.sleep(2)
    else:raise RuntimeError('No fresh Simio source. Start the model, then Start_Simio_Team.bat again.')
    return run(argparse.Namespace(packet=None,aas_url=cfg.AAS_URL,seconds=0,stop_file=None,check_source=False))


if __name__=='__main__':
    try:sys.exit(main())
    except KeyboardInterrupt:sys.exit(0)
    except (ValueError,RuntimeError,OSError) as exc:
        print(str(exc),file=sys.stderr,flush=True);sys.exit(1)
