"""Read-only PostgreSQL and durable queue status, run in the archive container."""
import json
import os
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import psycopg
from psycopg.rows import dict_row
from cycle_archive import Outbox


def report():
    with psycopg.connect(connect_timeout=3,row_factory=dict_row) as db:
        counts=db.execute('SELECT (SELECT count(*) FROM pet_twin.telemetry) AS telemetry_rows, (SELECT count(*) FROM pet_twin.cycles) AS cycle_rows').fetchone()
        cycles=db.execute('SELECT source_session,cycle_number,cycle_time_seconds,batch_produced,batch_good,batch_reject,observed_full_cycle,completed_at,aas_completed_cycles,aas_produced FROM pet_twin.cycles ORDER BY completed_at DESC LIMIT 5').fetchall()
        last=db.execute('SELECT source_session,aas_sequence,produced,phase,observed_at FROM pet_twin.telemetry ORDER BY observed_at DESC LIMIT 1').fetchone()
    queue=Outbox(os.environ['PET_ARCHIVE_OUTBOX']);status=queue.status();queue.close()
    return {**counts,'latest_telemetry':last,'latest_cycles':cycles,'archive':status,'checked_at':time.time()}


if __name__=='__main__':print(json.dumps(report(),default=str))
