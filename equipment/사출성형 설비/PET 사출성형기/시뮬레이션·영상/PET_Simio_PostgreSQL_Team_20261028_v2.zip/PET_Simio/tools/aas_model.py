"""AASX OPC relationship reader, XML/JSON conversion and lossless inventory."""
import json
import posixpath
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

TYPES={s[0].lower()+s[1:]:s for s in ['AssetAdministrationShell','Submodel','ConceptDescription','Property','MultiLanguageProperty','Range','File','Blob','ReferenceElement','RelationshipElement','AnnotatedRelationshipElement','SubmodelElementCollection','SubmodelElementList','Entity','Operation','Capability','BasicEventElement','DataSpecificationIec61360']}
ARRAYS={'assetAdministrationShells','submodels','conceptDescriptions','submodelElements','displayName','description','keys','qualifiers','embeddedDataSpecifications','specificAssetIds','supplementalSemanticIds','isCaseOf','statements','inputVariables','outputVariables','inoutputVariables','annotations','preferredName','shortName','definition','valueReferencePairs'}


def local(tag): return tag.rsplit('}',1)[-1]


def from_xml(el):
    tag=local(el.tag)
    if not len(el):
        return el.text or ''
    if tag in ARRAYS: return [from_xml(c) for c in el]
    if tag=='dataSpecificationContent': return from_xml(el[0])
    if tag=='value' and local(el[0].tag) not in ('type','keys'): return [from_xml(c) for c in el]
    o={}
    if tag in TYPES: o['modelType']=TYPES[tag]
    for c in el:
        key=local(c.tag); value=from_xml(c)
        if key in ('orderRelevant',): value=str(value).lower()=='true'
        # Empty optional numeric values are represented by absence, not empty lexical numbers.
        if key=='value' and value=='' and tag=='property': continue
        o[key]=value
    return o


def resolve(base,target):
    p=posixpath.normpath(posixpath.join(posixpath.dirname(base),target)) if not target.startswith('/') else target[1:]
    if p.startswith('../') or p=='..': raise ValueError('AASX relationship escapes package')
    return p


def relationships(z,part=''):
    rel=posixpath.join(posixpath.dirname(part),'_rels',posixpath.basename(part)+'.rels') if part else '_rels/.rels'
    return [(e.attrib['Type'].rsplit('/',1)[-1],resolve(part,e.attrib['Target'])) for e in ET.fromstring(z.read(rel)) if e.attrib.get('TargetMode')!='External']


def read_aasx(path):
    with zipfile.ZipFile(path) as z:
        origins=[p for t,p in relationships(z) if t=='aasx-origin']
        specs=[p for origin in origins for t,p in relationships(z,origin) if t=='aas-spec']
        if len(specs)!=1: raise ValueError('exactly one aas-spec environment required; select explicit source')
        part=specs[0]; raw=z.read(part)
        env=json.loads(raw) if part.endswith('.json') else from_xml(ET.fromstring(raw))
        if not env.get('assetAdministrationShells') or not env.get('submodels'): raise ValueError('empty AAS environment')
        return env,part


def write_aasx(source,destination,env):
    _,old=read_aasx(source); new=old.rsplit('.',1)[0]+'.json'
    oldrel=posixpath.join(posixpath.dirname(old),'_rels',posixpath.basename(old)+'.rels')
    newrel=posixpath.join(posixpath.dirname(new),'_rels',posixpath.basename(new)+'.rels')
    with zipfile.ZipFile(source) as src, zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            n=item.filename; data=src.read(n)
            if n==old: continue
            if n.endswith('.rels'):
                root=ET.fromstring(data)
                for rel in root:
                    if rel.attrib.get('Type','').endswith('/aas-spec'):
                        target=rel.attrib['Target']; rel.set('Target',target.rsplit('.',1)[0]+'.json')
                data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
            if n=='[Content_Types].xml':
                root=ET.fromstring(data); ns=root.tag.split('}')[0]+'}'
                for c in root:
                    if c.attrib.get('PartName')=='/'+old: c.set('PartName','/'+new); c.set('ContentType','application/json')
                if not any(c.attrib.get('Extension')=='json' for c in root): ET.SubElement(root,ns+'Default',Extension='json',ContentType='application/json')
                data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
            dst.writestr(newrel if n==oldrel else n,data)
        dst.writestr(new,json.dumps(env,ensure_ascii=False,indent=2))


def walk(elements,prefix=''):
    for i,e in enumerate(elements):
        p=(prefix+'.' if prefix else '')+e.get('idShort',f'[{i}]')
        if prefix.endswith(']') and not e.get('idShort'): p=prefix
        yield p,e
        mt=e.get('modelType')
        if mt=='SubmodelElementCollection': yield from walk(e.get('value',[]),p)
        elif mt=='SubmodelElementList':
            for j,child in enumerate(e.get('value',[])):
                yield from walk([child],f'{p}[{j}]')
        elif mt=='Entity': yield from walk(e.get('statements',[]),p)


def at(sm,path):
    return next((e for p,e in walk(sm.get('submodelElements',[])) if p==path),None)


def sem(e): return [k['value'] for k in e.get('semanticId',{}).get('keys',[])]


def inventory(env):
    cds={c['id']:c for c in env.get('conceptDescriptions',[])}
    rows=[]
    for sm in env['submodels']:
        for p,e in walk(sm.get('submodelElements',[])):
            cd=cds.get(next(iter(sem(e)),''),{})
            spec=[x.get('dataSpecificationContent',{}) for x in cd.get('embeddedDataSpecifications',[])]
            rows.append({'submodel':sm['idShort'],'submodel_id':sm['id'],'path':p,'modelType':e.get('modelType'),'valueType':e.get('valueType'),'value':e.get('value'),'semanticId':e.get('semanticId'),'unit':next((x.get('unit') for x in spec if x.get('unit')),None),'iec61360':spec})
    return {'shells':env['assetAdministrationShells'],'submodels':[{k:v for k,v in s.items() if k!='submodelElements'} for s in env['submodels']],'elements':rows,'conceptDescriptions':list(cds.values())}
