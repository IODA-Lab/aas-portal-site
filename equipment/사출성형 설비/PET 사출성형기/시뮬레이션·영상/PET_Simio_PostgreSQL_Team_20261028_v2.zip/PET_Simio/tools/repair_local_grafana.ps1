param(
    [switch]$Apply,
    [string]$GrafanaContainer = 'pet-grafana',
    [string]$AasContainer = 'aas-env',
    [string]$NetworkName = 'pet-aas-local'
)
$ErrorActionPreference = 'Stop'
$PetProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $PetProjectRoot
foreach ($value in @($GrafanaContainer, $AasContainer, $NetworkName)) {
    if ($value -notmatch '^[a-zA-Z0-9][a-zA-Z0-9_.-]*$') { throw 'Invalid container/network name' }
}
function Invoke-PetDocker {
    param([string[]]$DockerArgs)
    & docker @DockerArgs
    if ($LASTEXITCODE -ne 0) { throw "Docker failed: $($DockerArgs[0])" }
}
$gf = (Invoke-PetDocker @('inspect', $GrafanaContainer) | ConvertFrom-Json)[0]
$aas = (Invoke-PetDocker @('inspect', $AasContainer) | ConvertFrom-Json)[0]
Write-Output "Grafana: $GrafanaContainer; AAS: $AasContainer; DNS network: $NetworkName"
Write-Output 'Plan: add shared DNS network, backup Grafana DB/provisioning, install PET-only datasource/dashboard, restart only Grafana.'
Write-Output 'No container recreation, volume deletion, AAS reset, password change, or automatic AAS seeding.'
if (-not $Apply) { Write-Output 'PLAN_ONLY: use -Apply after reviewing the plan.'; exit 0 }
$backup = Join-Path $PetProjectRoot ('output/local-repair-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup | Out-Null
@{ grafana = @{ name=$gf.Name; image=$gf.Config.Image; networks=$gf.NetworkSettings.Networks; mounts=$gf.Mounts }; aas=@{name=$aas.Name; image=$aas.Config.Image; networks=$aas.NetworkSettings.Networks; mounts=$aas.Mounts} } | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $backup 'before.json') -Encoding utf8
$networks = Invoke-PetDocker @('network','ls','--format','{{.Name}}')
if ($NetworkName -notin $networks) { Invoke-PetDocker @('network','create',$NetworkName) }
foreach ($container in @($GrafanaContainer,$AasContainer)) {
    $info=(Invoke-PetDocker @('inspect',$container) | ConvertFrom-Json)[0]
    if ($NetworkName -notin $info.NetworkSettings.Networks.PSObject.Properties.Name) {
        Invoke-PetDocker @('network','connect',$NetworkName,$container)
    }
}
# Stop Grafana only so the SQLite backup is consistent. Keep the existing named volume.
Invoke-PetDocker @('exec',$GrafanaContainer,'mkdir','-p','/var/lib/grafana/pet-dashboards')
Invoke-PetDocker @('stop','--time','30',$GrafanaContainer)
try {
    Invoke-PetDocker @('cp',"${GrafanaContainer}:/var/lib/grafana/grafana.db",(Join-Path $backup 'grafana.db'))
    Invoke-PetDocker @('cp',"${GrafanaContainer}:/etc/grafana/provisioning",(Join-Path $backup 'provisioning'))
    $provider = @'
apiVersion: 1
providers:
  - name: PET-local-repair
    folder: PET
    type: file
    disableDeletion: true
    updateIntervalSeconds: 10
    options:
      path: /var/lib/grafana/pet-dashboards
'@
    $providerPath=Join-Path $backup 'pet-provider.yml'
    [IO.File]::WriteAllText($providerPath,$provider,[Text.UTF8Encoding]::new($false))
    Invoke-PetDocker @('cp',(Join-Path $PetProjectRoot 'grafana/provisioning/datasources/datasources.yml'),"${GrafanaContainer}:/etc/grafana/provisioning/datasources/pet-aas.yml")
    Invoke-PetDocker @('cp',$providerPath,"${GrafanaContainer}:/etc/grafana/provisioning/dashboards/pet-dashboard.yml")
    Invoke-PetDocker @('cp',(Join-Path $PetProjectRoot 'grafana/dashboards/pet_dashboard.json'),"${GrafanaContainer}:/var/lib/grafana/pet-dashboards/pet_dashboard.json")
    Invoke-PetDocker @('cp',(Join-Path $PetProjectRoot 'grafana/dashboards/pet_key_metrics.json'),"${GrafanaContainer}:/var/lib/grafana/pet-dashboards/pet_key_metrics.json")
} finally {
    Invoke-PetDocker @('start',$GrafanaContainer)
}
Write-Output "Backup: $backup"
& (Join-Path $PSScriptRoot 'sync_grafana_viewer.ps1') -Container $GrafanaContainer
Write-Output 'Applied. Refresh http://localhost:3000/d/pet-injection-twin and verify AAS-Server / aas-infinity.'
