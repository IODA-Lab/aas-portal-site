"""Read-only AAS load sampler; request rate, latency and payload budget."""
import argparse
import json
import statistics
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import pet_config as cfg
from aas_core import AasHttp


def measure(url,count=10,interval=1):
    h=AasHttp(cfg.validate_url(url),token=cfg.token());m=cfg.manifest();samples=[];sizes=[];errors=0;t0=time.monotonic()
    try:
        for i in range(count):
            start=time.perf_counter()
            try:
                data=h.get_value(m['submodels']['TwinRuntime'],'Current');sizes.append(len(json.dumps(data).encode()));samples.append((time.perf_counter()-start)*1000)
            except (ConnectionError,RuntimeError):errors+=1
            if i<count-1:time.sleep(max(.1,interval))
    finally:h.close()
    return {'requests':count,'errors':errors,'rps':count/max(.001,time.monotonic()-t0),'latency_p95_ms':sorted(samples)[min(len(samples)-1,int(len(samples)*.95))] if samples else None,'mean_response_bytes':statistics.mean(sizes) if sizes else None,'cpu_memory':'Use docker stats --no-stream on the server; not inferable from REST latency'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--aas-url',default=cfg.AAS_URL);p.add_argument('--count',type=int,default=10);p.add_argument('--interval',type=float,default=1);a=p.parse_args()
    if not 1<=a.count<=1000:p.error('count 1..1000')
    print(json.dumps(measure(a.aas_url,a.count,a.interval),indent=2))
