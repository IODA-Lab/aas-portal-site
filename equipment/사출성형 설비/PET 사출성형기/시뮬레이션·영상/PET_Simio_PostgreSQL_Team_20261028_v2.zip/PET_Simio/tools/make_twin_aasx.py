"""Build a separately identified simulation Instance from the actual PET reference."""
import argparse
import copy
import hashlib
import json
import sys
import uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools.aas_model import read_aasx,write_aasx,inventory,walk,at,sem
from aas_core import prop,smc,ref
from model.pet_process import PetProcess

NS=uuid.UUID('355bca91-38ce-4a24-9510-d855ec713431')
def identifier(name): return 'urn:uuid:'+str(uuid.uuid5(NS,name))

# source leaf -> engine key, exact source unit. No barrel-zone/melt-temperature substitution.
MAPPING={
 'DeviceRunState':('RunState',None),'MoldingRunState':('RunState',None),
 'CycleTimeActual':('CycleTime','s'),'ShotCountActual':('CompletedCycles','shots'),
 'CumulativeShotCount':('CompletedCycles','shots'),'GoodPreformCountActual':('Good','preforms'),
 'InjectionPressureActual':('InjectionPressure','bar'),'HoldingPressureActual':('HoldingPressure','bar'),
 'ScrewSpeedActual':('ScrewRPM','rpm'),'ClampingForceActual':('ClampingForce','kN'),
 'MoldTemperatureActual':('MoldTemperature','°C'),'MoldingAlarmStatus':('Alarm',None),
 'LastUpdateTimestamp':('TimestampISO',None),'OperationStartTimestamp':('StartedISO',None)
}
UNITS={'SimTime':'s','Timestamp':'s','RunSeconds':'s','CycleSumSeconds':'s','CycleTime':'s','BarrelTemperature':'°C','MoldTemperature':'°C','InjectionPressure':'bar','HoldingPressure':'bar','InjectionSetpoint':'bar','HoldingSetpoint':'bar','ClampingForce':'kN','MoldOpen':'mm','ScrewPosition':'mm','ScrewRPM':'rpm','ScrewAngle':'degree','Produced':'preforms','Good':'preforms','Reject':'preforms','CompletedCycles':'shots'}


def initial_snapshot():
    s=PetProcess().state()
    s.update(Timestamp=0.0,TimestampISO='1970-01-01T00:00:00Z',StartedISO='1970-01-01T00:00:00Z',Sequence=0,Session='',Connection='Disconnected',Samples='[]',Events='[]',DroppedRecords=0)
    return s


def datatype(v):
    return 'xs:boolean' if isinstance(v,bool) else 'xs:long' if isinstance(v,int) else 'xs:double' if isinstance(v,float) else 'xs:string'


def runtime_element(name,values):
    return smc(name,[prop(k,v,datatype(v),identifier('cd/'+k)) for k,v in values.items()],identifier('cd/'+name))


def clear_values(e):
    if isinstance(e,dict):
        if e.get('modelType') in ('Property','MultiLanguageProperty','Range','Blob','File'):
            for k in ('value','min','max'): e.pop(k,None)
        else:
            for v in e.values(): clear_values(v)
    elif isinstance(e,list):
        for v in e: clear_values(v)


def build(source,out=ROOT/'aas',equipment='PET-SIM-01',slots=60):
    source=Path(source); out=Path(out); out.mkdir(parents=True,exist_ok=True)
    env,_=read_aasx(source); original=copy.deepcopy(env); inv=inventory(env)
    if not any('PET' in s.get('idShort','').upper() for s in env['assetAdministrationShells']): raise ValueError('source is not identified as PET; explicit model review required')
    if len(env['assetAdministrationShells'])!=1: raise ValueError('select a single PET AAS')
    byname={s['idShort']:s for s in env['submodels']}
    for required in ['OperationalData','TimeSeries']:
        if required not in byname: raise ValueError('missing '+required)
    idmap={s['id']:identifier(equipment+'/'+s['id']) for s in env['submodels']+env['assetAdministrationShells']}
    for shell in env['assetAdministrationShells']:
        old=shell['id']; shell['id']=idmap[old]; shell['idShort']='PETSimulationTwin'
        shell['derivedFrom']={'type':'ModelReference','keys':[{'type':'AssetAdministrationShell','value':old}]}
        shell['assetInformation']['assetKind']='Instance'; shell['assetInformation']['globalAssetId']=identifier(equipment+'/asset')
        shell['description']=[{'language':'en','text':'SIMULATION ONLY. Reference example metadata is not verified manufacturer specification.'}]
        for s in shell.get('submodels',[]):
            for k in s['keys']: k['value']=idmap.get(k['value'],k['value'])
    for sm in env['submodels']:
        sm['id']=idmap[sm['id']]; sm['kind']='Instance'
        # Template-only cardinality qualifiers have no runtime value semantics.
        for _,e in [('',sm),*walk(sm.get('submodelElements',[]))]:
            if 'qualifiers' in e:
                e['qualifiers']=[q for q in e['qualifiers'] if q.get('kind')!='TemplateQualifier']
                if not e['qualifiers']: del e['qualifiers']
        if sm['idShort'] in ('OperationalData','PredictiveMaintenance'):
            clear_values(sm)
        if sm['idShort']=='ProcessVariablesForManufacturingKPICalculation':
            for _,e in walk(sm.get('submodelElements',[])):
                if e.get('idShort')=='currentValue': e.pop('value',None)
    engine=PetProcess(); recipe=engine.recipe
    recipe_values={'InjectionPressureSetpoint':recipe['injection_setpoint_bar'],'HoldingPressureSetpoint':recipe['holding_setpoint_bar'],'HoldingTimeSetpoint':'PT'+str(engine.duration(4))+'S','ScrewSpeedSetpoint':recipe['screw_rpm'],'CoolingTimeSetpoint':'PT'+str(engine.duration(5))+'S','MoldTemperatureSetpoint':recipe['mold_target_c'],'ClampingForceSetpoint':recipe['clamp_force_kn'],'TargetPreformWeight':recipe['preform_weight_g'],'CycleTimeTarget':'PT'+str(sum(engine.duration(i) for i in range(2,9)))+'S'}
    if 'ProcessParameters' in byname:
        for _,e in walk(byname['ProcessParameters']['submodelElements']):
            name=e.get('idShort','')
            if name in recipe_values:e['value']=str(recipe_values[name])
            elif e.get('modelType')=='Property' and (name.endswith('Setpoint') or name in ('MaxInjectionPressureLimit','TargetPreformCount','MaxAcetaldehydeTarget')):e.pop('value',None)
        byname['ProcessParameters']['description']=[{'language':'en','text':'SimulationAssumption: modeled recipe values are from process_scenario.json. Remaining descriptive entries are reference examples, not measured equipment data.'}]
    if 'TechnicalData' in byname:
        for _,e in walk(byname['TechnicalData']['submodelElements']):
            if e.get('idShort')=='NumberOfCavities':e['value']=str(recipe['cavities'])
        byname['TechnicalData']['description']=[{'language':'en','text':'Reference example specifications, not verified manufacturer data. NumberOfCavities adapted to the simulation assumption; geometry and dynamics are illustrative.'}]
    mapping=[]
    for row in inv['elements']:
        if row['submodel']!='OperationalData' or row['modelType']!='Property': continue
        leaf=row['path'].split('.')[-1]; pair=MAPPING.get(leaf)
        if pair and pair[1]!=row['unit']: raise ValueError('unit mismatch: '+leaf)
        mapping.append({**{k:row[k] for k in ('path','valueType','unit','semanticId')},'source_submodel_id':row['submodel_id'],'submodel_id':idmap[row['submodel_id']],'engine_key':pair[0] if pair else None,'status':'MAPPED_SIMULATION' if pair else 'UNMODELED','provenance':'Simulated' if pair else 'NotComputed'})
    ts=byname['TimeSeries']; template=copy.deepcopy(at(ts,'Metadata.Record'))
    if template is None: raise ValueError('PENDING_MAPPING: unsupported TimeSeries layout')
    clear_values(ts)
    records=at(ts,'Segments.InternalSegment.Records')
    if records is None or records['modelType']!='SubmodelElementCollection': raise ValueError('PENDING_MAPPING: unsupported Records structure')
    records['value']=[]
    for i in range(slots):
        e=copy.deepcopy(template); e['idShort']=f'Record{i:04d}'; clear_values(e); records['value'].append(e)
    for name,val in [('RecordCount','0'),('State','completed'),('SamplingInterval','1'),('SamplingRate','1')]:
        at(ts,'Segments.InternalSegment.'+name)['value']=val
    snapshot=initial_snapshot(); history={k:v for k,v in snapshot.items() if k not in ('Samples','Events')}
    runtime={'modelType':'Submodel','idShort':'TwinRuntime','id':identifier(equipment+'/TwinRuntime'),'kind':'Instance','semanticId':ref(identifier('cd/TwinRuntime')),
             'description':[{'language':'en','text':'Project extension, not an IDTA template. All process values are synthetic.'}],
             'submodelElements':[runtime_element('Current',snapshot),smc('History',[runtime_element(f'Record{i:04d}',history) for i in range(slots)]),runtime_element('Analytics',{'Status':'NotComputed','SourceSequence':0,'QualityRate':0.0,'RejectRate':0.0,'Utilization':0.0,'ThroughputPerHour':0.0,'MeanCycleTime':0.0,'RULStatus':'NotImplemented','Timestamp':0.0})]}
    env['submodels'].append(runtime)
    env['assetAdministrationShells'][0].setdefault('submodels',[]).append({'type':'ModelReference','keys':[{'type':'Submodel','value':runtime['id']}]})
    # Project-owned UUID URNs, never fabricated dictionary IRDIs.
    known={c['id'] for c in env['conceptDescriptions']}
    for path,e in [('',runtime),*walk(runtime['submodelElements'])]:
        for cid in sem(e):
            if cid in known: continue
            known.add(cid); key=e.get('idShort','TwinRuntime'); unit=UNITS.get(key)
            dtype='BOOLEAN' if e.get('valueType')=='xs:boolean' else 'INTEGER_MEASURE' if unit and e.get('valueType')=='xs:long' else 'REAL_MEASURE' if unit else 'INTEGER_COUNT' if e.get('valueType')=='xs:long' else 'REAL_COUNT' if e.get('valueType')=='xs:double' else 'STRING'
            spec={'modelType':'DataSpecificationIec61360','preferredName':[{'language':'en','text':key}], 'definition':[{'language':'en','text':'PET simulation extension '+key+'. See interface contract for exact formula and provenance.'}],'dataType':dtype}
            if unit: spec['unit']=unit
            env['conceptDescriptions'].append({'modelType':'ConceptDescription','id':cid,'idShort':key,'embeddedDataSpecifications':[{'dataSpecification':ref('https://admin-shell.io/DataSpecificationTemplates/DataSpecificationIec61360/3'),'dataSpecificationContent':spec}]})
    m={'version':'1.0.0','equipment_id':equipment,'slots':slots,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_name':source.name,'aas_id':env['assetAdministrationShells'][0]['id'],'source_aas_id':original['assetAdministrationShells'][0]['id'],'submodels':{s['idShort']:s['id'] for s in env['submodels']},'id_map':idmap,'provenance':'Simulated','normative_validation':'NOT_YET_RUN'}
    for name,data in [('reference_inventory.json',inv),('property_mapping.json',mapping),('twin_manifest.json',m),('PET_Twin.environment.json',env)]:
        (out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    write_aasx(source,out/'PET_Twin.aasx',env)
    return m


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--source',type=Path,required=True); p.add_argument('--out',type=Path,default=ROOT/'aas'); p.add_argument('--equipment-id',default='PET-SIM-01'); p.add_argument('--slots',type=int,default=60)
    a=p.parse_args()
    if not 2<=a.slots<=1200: p.error('slots must be 2..1200')
    print(json.dumps(build(a.source,a.out,a.equipment_id,a.slots),indent=2))
