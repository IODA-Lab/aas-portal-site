"""Integration check: pause only the team PostgreSQL, then verify durable replay."""
import base64
import json
import subprocess
import time
from pathlib import Path
from verify_team import get
ROOT=Path(__file__).resolve().parents[1]
DC=['docker','compose','--project-name','pet-simio-team','--env-file',str(ROOT/'simio-team.local.env'),'-f',str(ROOT/'docker-compose.simio-team.yml')]


def docker(*args):
    return subprocess.check_output(DC+list(args),cwd=ROOT,encoding='utf8')


def current():
    manifest=json.loads((ROOT/'aas/twin_manifest.json').read_text(encoding='utf8'))
    sid=base64.urlsafe_b64encode(manifest['submodels']['TwinRuntime'].encode()).decode().rstrip('=')
    return get('http://127.0.0.1:8084/submodels/'+sid+'/submodel-elements/Current/%24value')


def main():
    before=json.loads(docker('exec','-T','archive','python','tools/db_report.py'))
    a=current()
    print('Stopping only the team PostgreSQL for 30s; Simio and AAS stay active.',flush=True)
    try:
        docker('stop','-t','10','postgres')
        time.sleep(30)
        queued=json.loads(docker('exec','-T','bridge','python','-c','import os,json;from cycle_archive import Outbox;q=Outbox(os.environ["PET_ARCHIVE_OUTBOX"]);rows=q.batch(10000);print(json.dumps({"total":q.count(),"cycles":sum(r[1]=="cycle" for r in rows),"ids":[r[0] for r in rows]}));q.close()'))
        b=current()
        assert int(b['Sequence'])>int(a['Sequence']) and b['Connection']=='ConnectedSimulated'
        assert queued['total']>=20 and queued['cycles']>=1,queued
        print('AAS kept updating; queued records='+str(queued['total']),flush=True)
    finally:
        docker('start','postgres')
    deadline=time.monotonic()+60
    while True:
        try:
            after=json.loads(docker('exec','-T','archive','python','tools/db_report.py'))
            if after['archive'].get('connected') and after['archive']['pending']<=2 and after['cycle_rows']>=before['cycle_rows']+queued['cycles'] and after['telemetry_rows']>=before['telemetry_rows']+queued['total']-queued['cycles']:break
        except subprocess.CalledProcessError:pass
        if time.monotonic()>deadline:raise TimeoutError('PostgreSQL backlog did not recover')
        time.sleep(2)
    # A replay after commit must not duplicate an immutable cycle record.
    replay='''import os,json
from cycle_archive import Outbox
from tools.postgres_archiver import PostgresSink
import psycopg
with psycopg.connect() as db:
 e=db.execute("SELECT payload FROM pet_twin.cycles ORDER BY completed_at LIMIT 1").fetchone()[0]
 key=(e["equipment_id"],e["session"],e["cycle_number"])
row=("replay-test","cycle",json.dumps(e))
sink=PostgresSink();sink.write([row]);sink.write([row]);sink.close()
with psycopg.connect() as db:
 n=db.execute("SELECT count(*) FROM pet_twin.cycles WHERE equipment_id=%s AND source_session=%s AND cycle_number=%s",key).fetchone()[0]
 assert n==1,n
print("duplicate replay verified")'''
    print(docker('exec','-T','archive','python','-c',replay).strip())
    result={'passed':True,'aas_sequence_before':a['Sequence'],'aas_sequence_during_pg_outage':b['Sequence'],'queued_during_outage':queued['total'],'cycles_queued':queued['cycles'],'before':before,'after':after,'duplicate_replay':True}
    (ROOT/'output/postgres-outage-verification.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print('PASS: AAS continued, disk queue recovered, PostgreSQL cycle keys stayed unique.',flush=True)


if __name__=='__main__':main()
