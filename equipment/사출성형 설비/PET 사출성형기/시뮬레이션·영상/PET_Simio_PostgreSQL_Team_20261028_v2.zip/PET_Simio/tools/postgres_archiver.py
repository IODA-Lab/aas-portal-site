"""Drain the durable outbox to PostgreSQL, independently of Simio/AAS uptime."""
import json
import os
import signal
import sys
import threading
import time
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cycle_archive import Outbox,flush_once


class PostgresSink:
    def __init__(self):self.connection=None

    def connect(self):
        import psycopg
        self.connection=psycopg.connect(connect_timeout=3,options='-c statement_timeout=5000')
        with self.connection.transaction():
            self.connection.execute((Path(__file__).resolve().parents[1]/'db/schema.sql').read_text(encoding='utf8'))

    def write(self,rows):
        from psycopg.types.json import Jsonb
        if self.connection is None:self.connect()
        with self.connection.transaction():
            for _,kind,payload in rows:
                e=json.loads(payload);s=e['aas_values']
                timestamp=datetime.fromtimestamp(e['received_at'],timezone.utc)
                if kind=='telemetry':
                    values=(e['equipment_id'],e['session'],e['sample_index'],timestamp,s['Sequence'],e['cycle_number'],s['Phase'],s['Produced'],s['Good'],s['Reject'],s['BarrelTemperature'],s['MoldTemperature'],s['InjectionPressure'],s['ScrewPosition'],Jsonb(e))
                    self.connection.execute('INSERT INTO pet_twin.telemetry (equipment_id,source_session,sample_index,observed_at,aas_sequence,cycle_number,phase,produced,good,reject,barrel_temperature_c,mold_temperature_c,injection_pressure_bar,screw_position_mm,payload) VALUES ('+','.join(['%s']*15)+') ON CONFLICT DO NOTHING',values)
                elif kind=='cycle':
                    values=(e['equipment_id'],e['session'],e['cycle_number'],e['sample_index'],timestamp,e['source_sim_s'],e['cycle_time_s'],e['batch_produced'],e['batch_good'],e['batch_reject'],e['observed_full_cycle'],s['CompletedCycles'],s['Produced'],Jsonb(e))
                    self.connection.execute('INSERT INTO pet_twin.cycles (equipment_id,source_session,cycle_number,sample_index,completed_at,source_sim_seconds,cycle_time_seconds,batch_produced,batch_good,batch_reject,observed_full_cycle,aas_completed_cycles,aas_produced,payload) VALUES ('+','.join(['%s']*14)+') ON CONFLICT DO NOTHING',values)
                else:raise ValueError('unsupported outbox record type')

    def ping(self):
        if self.connection is None:self.connect()
        with self.connection.transaction():self.connection.execute('SELECT 1')

    def close(self):
        if self.connection is not None:self.connection.close()
        self.connection=None


def main():
    queue=Outbox(os.environ['PET_ARCHIVE_OUTBOX'])
    sink=PostgresSink();stop=threading.Event();previous=None;total=0
    signal.signal(signal.SIGTERM,lambda *_:stop.set())
    signal.signal(signal.SIGINT,lambda *_:stop.set())
    try:
        while not stop.is_set():
            try:
                sink.ping();n=flush_once(queue,sink);total+=n
                queue.set_status(connected=True,checked_at=time.time(),delivered_this_run=total,error=None)
                if previous is not True:print('POSTGRES_CONNECTED',flush=True)
                previous=True
                if not n:stop.wait(.5)
            except Exception as exc:
                sink.close()
                # Never log exception text: a driver error can contain credentials.
                queue.set_status(connected=False,checked_at=time.time(),delivered_this_run=total,error=type(exc).__name__)
                if previous is not False:print('POSTGRES_WAIT: '+type(exc).__name__+'; queued records retained',flush=True)
                previous=False;stop.wait(2)
    finally:sink.close();queue.close()


if __name__=='__main__':main()
