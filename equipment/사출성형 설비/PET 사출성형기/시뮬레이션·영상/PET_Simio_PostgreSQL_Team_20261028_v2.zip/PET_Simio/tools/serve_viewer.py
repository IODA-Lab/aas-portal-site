"""Serve public assets only. Never exposes configuration, tokens, source or AAS archives."""
import argparse
import mimetypes
import base64
import json
import threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote,urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
ROOT=Path(__file__).resolve().parents[1]


class PublicHandler(BaseHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Content-Security-Policy', "frame-ancestors http://localhost:3000 http://127.0.0.1:3000 http://localhost:3002 http://127.0.0.1:3002")
        self.send_header('X-Content-Type-Options','nosniff')
        super().end_headers()

    def current(self):
        # Fixed read-only endpoint: never accept arbitrary target URLs or expose credentials.
        try:
            with urlopen(Request(self.server.current_url,headers={'Accept':'application/json'}),timeout=2.5) as r:
                data=r.read(2_000_001)
                if len(data)>2_000_000: raise ValueError('payload too large')
                if not isinstance(json.loads(data),dict): raise ValueError('invalid Current object')
            code=200
        except HTTPError as e:
            code=502; data=json.dumps({'error':'AAS_HTTP','upstream_status':e.code}).encode()
        except (URLError,TimeoutError,OSError,ValueError):
            code=503; data=b'{"error":"AAS_UNAVAILABLE_OR_INVALID_JSON"}'
        self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

    def do_GET(self):
        path=unquote(urlsplit(self.path).path).lstrip('/')
        if path=='api/current': self.current(); return
        if not path:
            self.send_response(302); self.send_header('Location','viewer/'); self.end_headers(); return
        if path.endswith('/'): path+='index.html'
        if not path.startswith(('viewer/','model/public/')): self.send_error(404); return
        f=(ROOT/path).resolve()
        if not any(f.is_relative_to((ROOT/p).resolve()) for p in ('viewer','model/public')) or not f.is_file(): self.send_error(404); return
        mime='text/javascript' if f.suffix in ('.js','.mjs') else mimetypes.guess_type(f)[0] or 'application/octet-stream'
        data=f.read_bytes(); self.send_response(200); self.send_header('Content-Type',mime); self.send_header('Content-Length',str(len(data))); self.send_header('Cache-Control','no-cache'); self.end_headers(); self.wfile.write(data)


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--port',type=int,default=8092); p.add_argument('--bind',default='127.0.0.1'); p.add_argument('--aas-url',default='http://localhost:8081'); p.add_argument('--stop-file',type=Path); a=p.parse_args()
    u=urlsplit(a.aas_url)
    if u.scheme not in ('http','https') or not u.hostname or u.username or u.password: p.error('Invalid AAS URL')
    manifest=json.loads((ROOT/'aas/twin_manifest.json').read_text(encoding='utf-8'))
    runtime=base64.urlsafe_b64encode(manifest['submodels']['TwinRuntime'].encode()).decode().rstrip('=')
    server=ThreadingHTTPServer((a.bind,a.port),PublicHandler)
    server.current_url=a.aas_url.rstrip('/')+'/submodels/'+runtime+'/submodel-elements/Current/%24value'
    done=threading.Event()
    def monitor():
        while not done.wait(.25):
            if a.stop_file and a.stop_file.exists(): server.shutdown();return
    if a.stop_file: threading.Thread(target=monitor,daemon=True).start()
    print(f'http://{a.bind}:{a.port}/viewer/?mode=live&embed=1',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: done.set();server.server_close()
