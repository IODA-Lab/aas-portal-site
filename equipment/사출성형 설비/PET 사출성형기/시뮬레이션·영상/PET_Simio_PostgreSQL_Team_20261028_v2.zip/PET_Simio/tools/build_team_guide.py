"""Render the team Markdown manual as a Korean PDF with embedded local fonts."""
import html
import os
import re
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image,Preformatted
ROOT=Path(__file__).resolve().parents[1]

def build(source='docs/팀원_실행가이드.md',destination='docs/PET_팀원_실행가이드.pdf',edition='2026.10.27'):
    fonts=Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'
    pdfmetrics.registerFont(TTFont('Korean',str(fonts/'malgun.ttf')))
    pdfmetrics.registerFont(TTFont('KoreanBold',str(fonts/'malgunbd.ttf')))
    pdfmetrics.registerFont(TTFont('Code',str(fonts/'consola.ttf')))
    styles={
      'title':ParagraphStyle('title',fontName='KoreanBold',fontSize=22,leading=31,spaceAfter=17,textColor=colors.HexColor('#152d40'),wordWrap='CJK'),
      'h2':ParagraphStyle('h2',fontName='KoreanBold',fontSize=12.5,leading=19,spaceBefore=12,spaceAfter=7,textColor=colors.HexColor('#205a6b'),keepWithNext=True,wordWrap='CJK'),
      'body':ParagraphStyle('body',fontName='Korean',fontSize=10,leading=16,spaceAfter=9,wordWrap='CJK'),
      'cell':ParagraphStyle('cell',fontName='Korean',fontSize=9,leading=14,wordWrap='CJK'),
      'head':ParagraphStyle('head',fontName='KoreanBold',fontSize=9,leading=14,textColor=colors.white,wordWrap='CJK'),
      'code':ParagraphStyle('code',fontName='Code',fontSize=8.7,leading=13,spaceBefore=5,spaceAfter=10),
      'tree':ParagraphStyle('tree',fontName='Korean',fontSize=9,leading=14,spaceBefore=5,spaceAfter=10),
    }
    out=ROOT/destination
    width=A4[0]-92
    story=[]
    lines=(ROOT/source).read_text(encoding='utf-8').splitlines()
    i=0
    while i<len(lines):
        line=lines[i].strip();i+=1
        if not line:continue
        if line=='<!-- PAGE -->':story.append(PageBreak());continue
        if line.startswith('```'):
            block=[];lang=line[3:]
            while i<len(lines) and not lines[i].startswith('```'):block.append(lines[i]);i+=1
            i+=1
            st=styles['tree' if lang=='text' else 'code']
            story.append(Preformatted('\n'.join(block),st));continue
        if line.startswith('|'):
            rows=[line]
            while i<len(lines) and lines[i].startswith('|'):rows.append(lines[i]);i+=1
            cells=[]
            for j,row in enumerate(rows):
                if re.match(r'^\|[\s|:-]+\|$',row):continue
                cells.append([Paragraph(html.escape(v.strip()),styles['head' if j==0 else 'cell']) for v in row.strip('|').split('|')])
            table=Table(cells,colWidths=[width*.34,width*.66],repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#25485e')),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#cbd5dc')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f2f6f8')]),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
            story.extend([table,Spacer(1,10)]);continue
        if line.startswith('!['):
            path=ROOT/'docs'/line.split('](',1)[1][:-1]
            from PIL import Image as PILImage
            with PILImage.open(path) as im:w,h=im.size
            story.extend([Image(str(path),width=width,height=width*h/w),Spacer(1,8)]);continue
        if line.startswith('# '):story.append(Paragraph(html.escape(line[2:]),styles['title']));continue
        if line.startswith('## '):story.append(Paragraph(html.escape(line[3:]),styles['h2']));continue
        text=html.escape(line)
        if line.startswith('https://') or line.startswith('http://'):
            url=line.split()[0]
            text=f'<link href="{html.escape(url,quote=True)}" color="#205a6b">{html.escape(url)}</link>'+html.escape(line[len(url):])
        story.append(Paragraph(text,styles['body']))
    def footer(c,doc):
        c.saveState();c.setFont('Korean',8);c.setFillColor(colors.HexColor('#607382'))
        c.drawString(46,27,'PET 디지털 트윈  |  팀원 실행 가이드  |  '+edition)
        c.drawRightString(A4[0]-46,27,str(doc.page));c.restoreState()
    SimpleDocTemplate(str(out),pagesize=A4,rightMargin=46,leftMargin=46,topMargin=40,bottomMargin=44,title='PET 사출성형기 디지털 트윈 실행 가이드',author='PET 디지털 트윈 프로젝트').build(story,onFirstPage=footer,onLaterPages=footer)
    print(out)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--simio',action='store_true')
    p.add_argument('--postgres',action='store_true')
    args=p.parse_args()
    if args.postgres:build('docs/Simio_PostgreSQL_팀원_실행가이드.md','docs/PET_Simio_PostgreSQL_실행가이드.pdf','Simio + PostgreSQL | 2026.10.28')
    elif args.simio:build('docs/Simio_팀원_실행가이드.md','docs/PET_Simio_팀원_실행가이드.pdf','Simio | 2026.10.28')
    else:build()
