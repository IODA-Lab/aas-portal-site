"""Read-only verification of the isolated team stack; credentials never printed."""
import base64
import json
import time
import urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def get(url,body=None,headers=None):
    data=None if body is None else json.dumps(body).encode()
    req=urllib.request.Request(url,data=data,headers={'Content-Type':'application/json',**(headers or {})})
    with urllib.request.urlopen(req,timeout=20) as r:return json.load(r)

def current():
    m=json.loads((ROOT/'aas/twin_manifest.json').read_text(encoding='utf-8'))
    sid=base64.urlsafe_b64encode(m['submodels']['TwinRuntime'].encode()).decode().rstrip('=')
    return get('http://127.0.0.1:8083/submodels/'+sid+'/submodel-elements/Current/%24value')

def run():
    config=dict(line.split('=',1) for line in (ROOT/'team.local.env').read_text().splitlines() if '=' in line)
    auth=base64.b64encode(('admin:'+config['PET_TEAM_GRAFANA_PASSWORD']).encode()).decode()
    headers={'Authorization':'Basic '+auth}
    a=current();time.sleep(3);b=current()
    assert int(b['Sequence'])>int(a['Sequence']),'Current did not update'
    assert b['Connection']=='ConnectedSimulated' and -2<time.time()-float(b['Timestamp'])<5
    ds=get('http://127.0.0.1:3003/api/datasources/uid/aas-infinity',headers=headers)
    assert ds['name']=='AAS-Server'
    dash=get('http://127.0.0.1:3003/api/dashboards/uid/pet-injection-twin',headers=headers)['dashboard']
    queries=[t for p in dash['panels'] for t in p.get('targets',[]) if 'url' in t]
    now=int(time.time()*1000)
    response=get('http://127.0.0.1:3003/api/ds/query',{'from':str(now-300000),'to':str(now),'queries':queries},headers)
    for result in response['results'].values():
        assert not result.get('error'),result.get('error')
        assert result.get('frames'),'No data frames'
    summary={'checked_at':time.strftime('%Y-%m-%dT%H:%M:%S%z'),'aas_live':True,'sequence_before':a['Sequence'],'sequence_after':b['Sequence'],'produced':b['Produced'],'grafana_datasource':ds['uid'],'grafana_queries':list(response['results']),'grafana_queries_ok':True,'phase':b['Phase']}
    (ROOT/'output').mkdir(exist_ok=True)
    (ROOT/'output/team-check.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':run()
