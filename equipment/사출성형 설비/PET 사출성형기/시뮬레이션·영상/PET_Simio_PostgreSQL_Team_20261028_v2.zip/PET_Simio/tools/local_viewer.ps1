param(
    [ValidateSet('Start','Stop','Status')][string]$Action='Status',
    [string]$AasUrl='http://localhost:8081'
)
$ErrorActionPreference='Stop'
$PetProjectRoot=Split-Path -Parent $PSScriptRoot
$out=Join-Path $PetProjectRoot 'output'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$statePath=Join-Path $out 'local-viewer.json'
$state=$null; $proc=$null
if (Test-Path -LiteralPath $statePath) {
    $state=Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $candidate=Get-Process -Id $state.pid -ErrorAction SilentlyContinue
    if ($candidate -and $candidate.ProcessName -match '^python' -and $candidate.StartTime.ToUniversalTime().ToString('o') -eq $state.started) { $proc=$candidate }
}
if ($Action -eq 'Status') {
    if ($proc) { Write-Output "RUNNING PID=$($state.pid) URL=$($state.aasUrl)" } else { Write-Output 'STOPPED' }
    exit 0
}
if ($Action -eq 'Stop') {
    if (-not $proc) { Write-Output 'Already stopped'; exit 0 }
    if ($state.stopFile -notmatch '^local-viewer-[a-f0-9-]+\.stop$') { throw 'Invalid local stop filename' }
    [IO.File]::WriteAllText((Join-Path $out $state.stopFile),'stop')
    if (-not $proc.WaitForExit(20000)) { throw 'Stop requested; viewer still running. Inspect logs. No forced termination performed.' }
    Write-Output 'Viewer stopped. AAS and publisher are unchanged.'
    exit 0
}
if ($proc) { Write-Output "Already running PID=$($state.pid)"; exit 0 }
$uri=[Uri]$AasUrl
if ($uri.Host -notin @('localhost','127.0.0.1','::1')) { throw 'This helper is for loopback BaSyx only.' }
$python=Join-Path $PetProjectRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $python)) { $python=(Get-Command python).Source }
$runId=[Guid]::NewGuid().ToString()
$stopName="local-viewer-$runId.stop"
$log=Join-Path $out "local-viewer-$runId.log"
$err=Join-Path $out "local-viewer-$runId.err.log"
$argsList=@('-u','-X','utf8','tools/serve_viewer.py','--aas-url',$AasUrl,'--stop-file',('"'+(Join-Path $out $stopName)+'"'))
$started=Start-Process -FilePath $python -ArgumentList $argsList -WorkingDirectory $PetProjectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $log -RedirectStandardError $err
$saved=@{pid=$started.Id;started=$started.StartTime.ToUniversalTime().ToString('o');aasUrl=$AasUrl;stopFile=$stopName;log=$log;errorLog=$err}
$saved | ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding utf8
Start-Sleep -Seconds 3
if ($started.HasExited) { Get-Content -LiteralPath $err; throw "Viewer exited: $($started.ExitCode)" }
Write-Output "RUNNING PID=$($started.Id); log=$log"
Write-Output 'Open: http://localhost:8092/viewer/?mode=live&embed=1'
Write-Output 'Stop: powershell -NoProfile -ExecutionPolicy Bypass -File tools/local_viewer.ps1 -Action Stop'

