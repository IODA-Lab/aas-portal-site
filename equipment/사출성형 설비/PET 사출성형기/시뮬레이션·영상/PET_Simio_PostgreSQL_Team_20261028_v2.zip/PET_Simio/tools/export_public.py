"""Generate schemas and public viewer data from the same Python process engine."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from model.pet_process import PetProcess
from tools.make_twin_aasx import initial_snapshot,UNITS


def write(path,data):
    p=ROOT/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')


def schema(value):
    if isinstance(value,dict): return {'type':'object','properties':{k:schema(v) for k,v in value.items()},'required':list(value),'additionalProperties':False}
    if isinstance(value,list): return {'type':'array','items':schema(value[0]) if value else {}}
    return {'type':'boolean' if isinstance(value,bool) else 'integer' if isinstance(value,int) else 'number' if isinstance(value,float) else 'string'}


def export():
    e=PetProcess(); samples=[e.state()]; n=0
    while e.completed_cycles<3:
        e.step(); n+=1
        if n%3==0: samples.append(e.state())
    public={'version':'1.0.0','provenance':'SimulationAssumption','steps':e.cfg['steps'],'timeline':e.nominal_timeline(),'recipe':e.recipe,'units':UNITS,'stale_s':5,'pose_hz':20}
    demo={'version':'1.0.0','source':'Python PetProcess','mode':'OfflineDemo','duration_s':e.t,'frames':samples}
    write('model/public/process_public.json',public); write('model/public/demo_cycle.json',demo)
    write('model/public/pet_model_spec.json',{'visual_version':'2.0','cavities_displayed':24,'views':['overall','feed','mold','injection','robot','conveyor'],'takeout_motion':'Overhead descent, grip, core extraction, lift, elevated transfer, conveyor placement; display assumption, not measured axes','inspection_modes':['internal','enclosure'],'reference_video':'https://youtube.com/shorts/zn_LNXwmpMc','reference_usage':'Visual reference only; no extracted meshes or textures. Dimensions and extra visual kinematics are SimulationAssumption.','units':'illustrative metres','manufacturer_geometry':False,'components':['base','hopper','heated_barrel','screw','fixed_platen','moving_platen','tie_bars','preform_mold','takeout_robot','external_conveyor']})
    mpath=ROOT/'aas/twin_manifest.json'
    if mpath.exists():
        m=json.loads(mpath.read_text(encoding='utf-8')); write('model/public/connection.json',{'runtime_id':m['submodels']['TwinRuntime'],'equipment_id':m['equipment_id'],'aas_url':''})
    for name,data in [('engine_api',samples[0]),('process_public',public),('demo_cycle',demo),('runtime_smc',initial_snapshot())]:
        sc={'$schema':'https://json-schema.org/draft/2020-12/schema','title':name,'version':'1.0.0',**schema(data)}
        if name in ('engine_api','runtime_smc'):
            sc['properties']['RunState']['enum']=['Running','Standby','Stopped','Alarm']; sc['properties']['Phase']['enum']=[x['name'] for x in e.cfg['steps']]
            for k in ['PhaseProgress','CycleProgress']: sc['properties'][k].update(minimum=0,maximum=1)
            for k in ['Produced','Good','Reject','CompletedCycles','ScrewPosition','MoldOpen','InjectionPressure']: sc['properties'][k]['minimum']=0
            for k,unit in UNITS.items():
                if k in sc['properties']: sc['properties'][k]['x-unit']=unit
        write('contract/'+name+'.schema.json',sc)
    write('contract/ts_record.json',{'version':'1.0.0','official_path':'Segments.InternalSegment.Records.RecordNNNN','template':'Metadata.Record','time':'relative integer simulation seconds','unmodeled':'value absent, never copied example values','history_path':'TwinRuntime.History','ordering':'Sequence ascending','retention':'PET_TS_MAX_RECORDS','aggregate':'last sample; pose samples at 20 Hz retained in Current only'})
    write('contract/single_writer.json',{'version':'1.0.0','equipment':['TwinRuntime.Current','TwinRuntime.History','OperationalData mapped monitoring collections','TimeSeries.Segments.InternalSegment'],'analytics':['TwinRuntime.Analytics','ProcessVariablesForManufacturingKPICalculation PQ/GQ/SQ currentValue'],'enforcement':'fresh heartbeat startup refusal; one process per equipment; no distributed lease in base AAS API','on_restart':'restore counters/sequence/history; restart from warmup; never resume partial shot'})
    write('contract/bundle_files.json',{'version':'1.0.0','include':['*.py','*.md','*.txt','*.yml','*.json','*.bat','*.ps1','*.sh','*.html','*.css','*.js','*.mjs','*.cjs','*.caddy','*.aasx','*.svg','LICENSE','.env.example','.gitignore','equipment.env.example'],'exclude':['.venv','__pycache__','output','dist','equipment.env','.env','secrets.local.env','*.pem','*.key']})
    print('public assets and contracts exported:',len(samples),'frames')


if __name__=='__main__': export()
