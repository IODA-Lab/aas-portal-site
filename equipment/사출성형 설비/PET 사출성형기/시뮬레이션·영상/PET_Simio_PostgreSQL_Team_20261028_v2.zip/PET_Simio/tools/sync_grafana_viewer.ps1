param([string]$Container='pet-grafana')
$ErrorActionPreference='Stop'
$PetProjectRoot=Split-Path -Parent $PSScriptRoot
Push-Location $PetProjectRoot
try {
    docker exec --user 0 $Container mkdir -p /usr/share/grafana/public/pet/viewer /usr/share/grafana/public/pet/model/public
    if ($LASTEXITCODE -ne 0) { throw 'Cannot prepare Grafana public viewer directory.' }
    docker cp 'viewer/.' "${Container}:/usr/share/grafana/public/pet/viewer/"
    if ($LASTEXITCODE -ne 0) { throw 'Viewer copy failed.' }
    docker cp 'model/public/.' "${Container}:/usr/share/grafana/public/pet/model/public/"
    if ($LASTEXITCODE -ne 0) { throw 'Public model copy failed.' }
    Write-Output 'Public viewer assets copied. No private configuration or AAS archive is exposed.'
} finally { Pop-Location }
