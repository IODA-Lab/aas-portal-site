"""Reproducible normative JSON-schema + explicit structural checks. Not certification."""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tools.aas_model import read_aasx,walk,sem


def structural(env):
    errors=[];ids=[o['id'] for k in ('assetAdministrationShells','submodels','conceptDescriptions') for o in env.get(k,[])]
    if len(ids)!=len(set(ids)):errors.append('duplicate identifiable IDs')
    smids={s['id'] for s in env['submodels']}
    for s in env['assetAdministrationShells']:
        for r in s.get('submodels',[]):
            if any(k['type']=='Submodel' and k['value'] not in smids for k in r['keys']):errors.append('unresolved shell Submodel reference')
    for sm in env['submodels']:
        for path,e in [('',sm),*walk(sm.get('submodelElements',[]))]:
            children=e.get('submodelElements',[]) if e.get('modelType')=='Submodel' else e.get('value',[]) if e.get('modelType') in ('SubmodelElementCollection','SubmodelElementList') else []
            if not isinstance(children,list):continue
            names=[x.get('idShort') for x in children]
            if e.get('modelType')=='SubmodelElementList':
                if any(names):errors.append(sm['idShort']+'.'+path+': idShort on list item')
            elif len(names)!=len(set(names)):errors.append(sm['idShort']+'.'+path+': duplicate child idShort')
    return errors


def validate(path,official=False):
    env,_=read_aasx(path);errors=structural(env); result={'path':str(path),'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'structural':{'status':'PASS' if not errors else 'FAIL','errors':errors},'official_json_schema':{'status':'NOT_RUN'},'idta_template_conformance':{'status':'NOT_VALIDATED','reason':'No full official template constraint comparison; preserved source semantic IDs checked separately.'},'kosmo_rules':{'status':'NOT_VALIDATED','reason':'Project KOSMO rulebook/validator not supplied.'}}
    if official:
        import jsonschema
        source=ROOT/'contract/official/aas-3.1.1.schema.json';sc=json.loads(source.read_text(encoding='utf-8'));validator=jsonschema.validators.validator_for(sc)(sc);issues=[];count=0;t0=time.monotonic()
        # Same normative schema, separate Environment sections for visible progress and bounded errors.
        for group in ('assetAdministrationShells','submodels','conceptDescriptions'):
            for obj in env.get(group,[]):
                for e in validator.iter_errors({group:[obj]}):issues.append({'path':group+'/'+obj.get('idShort',obj['id']),'message':e.message[:1500]})
                count+=1
                if group!='conceptDescriptions':print('Validated',obj.get('idShort'),flush=True)
        result['official_json_schema']={'status':'PASS' if not issues else 'FAIL','version':'IDTA-01001 v3.1.1','source':'https://raw.githubusercontent.com/admin-shell-io/aas-specs-metamodel/v3.1.1/schemas/json/aas.json','schema_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'identifiables':count,'seconds':round(time.monotonic()-t0,2),'errors':issues}
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('aasx',type=Path);p.add_argument('--official',action='store_true');p.add_argument('--out',type=Path,default=ROOT/'output/aas_validation.json');a=p.parse_args();result=validate(a.aasx,a.official);a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(any(v.get('status')=='FAIL' for v in result.values() if isinstance(v,dict)))
