"""Read-only verification of the isolated Simio team AAS and Grafana queries."""
import base64
import copy
import json
import time
from pathlib import Path
from verify_team import get

ROOT=Path(__file__).resolve().parents[1]


def main():
    config=dict(line.split('=',1) for line in (ROOT/'simio-team.local.env').read_text(encoding='utf8').splitlines() if '=' in line)
    headers={'Authorization':'Basic '+base64.b64encode(('admin:'+config['PET_SIMIO_GRAFANA_PASSWORD']).encode()).decode()}
    manifest=json.loads((ROOT/'aas/twin_manifest.json').read_text(encoding='utf8'))
    sid=base64.urlsafe_b64encode(manifest['submodels']['TwinRuntime'].encode()).decode().rstrip('=')
    current_url='http://127.0.0.1:8084/submodels/'+sid+'/submodel-elements/Current/%24value'
    a=get(current_url);time.sleep(3);b=get(current_url)
    assert b['Session'].startswith('simio-') and b['Session']==a['Session']
    assert int(b['Sequence'])>int(a['Sequence']) and b['Connection']=='ConnectedSimulated'
    assert -1<time.time()-float(b['Timestamp'])<5
    assert int(b['Produced'])==int(b['Good'])+int(b['Reject']) and int(b['Cavities'])==24
    assert abs(float(b['CycleTime'])-27.5)<.001
    base='http://127.0.0.1:3004'
    ds=get(base+'/api/datasources/uid/aas-infinity',headers=headers)
    assert ds['name']=='AAS-Server'
    dash=get(base+'/api/dashboards/uid/pet-injection-twin',headers=headers)['dashboard']
    queries=[t for panel in dash['panels'] for t in panel.get('targets',[]) if 'url' in t]
    source=copy.deepcopy(queries[0])
    source.update(refId='Source',root_selector='($r := $; [$r])',columns=[{'selector':'Session','text':'Session','type':'string'}])
    queries.append(source)
    now=int(time.time()*1000)
    result=get(base+'/api/ds/query',{'from':str(now-300000),'to':str(now),'queries':queries},headers)
    for ref,value in result['results'].items():
        assert not value.get('error'),(ref,value.get('error'))
        assert value.get('frames'),(ref,'no frames')
    live=result['results']['A']['frames'][0]
    live_names=[f['name'] for f in live['schema']['fields']]
    assert live['data']['values'][live_names.index('StateCode')][0]=='LIVE'
    fields=result['results']['Source']['frames'][0]
    names=[f['name'] for f in fields['schema']['fields']]
    session=fields['data']['values'][names.index('Session')][0]
    assert session==b['Session'],'Grafana is not receiving the current Simio session'
    history=get('http://127.0.0.1:8084/submodels/'+sid+'/submodel-elements/History/%24value')
    assert any(v.get('Session')==b['Session'] for v in history.values())
    report={'passed':True,'source':'Simio','session':b['Session'],'sequence_before':a['Sequence'],'sequence_after':b['Sequence'],'produced':b['Produced'],'cycle_seconds':b['CycleTime'],'grafana_datasource':ds['uid'],'grafana_queries':list(result['results']),'history_contains_simio':True,'checked_unix':time.time()}
    output=ROOT/'output/simio-team-check.json';output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps(report))


if __name__=='__main__':main()
