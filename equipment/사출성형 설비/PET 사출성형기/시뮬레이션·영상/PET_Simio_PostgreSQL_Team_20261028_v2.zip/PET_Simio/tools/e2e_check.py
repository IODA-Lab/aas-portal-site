"""End-to-end local test, or read-only remote inspection with explicit URL."""
import argparse
import json
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from aas_core import AasHttp
from aas_equipment import AasTwinWriter,parse_snapshot,iso
from model.pet_process import PetProcess
from tools.make_twin_aasx import initial_snapshot
from tests.fake_aas import FakeAAS
from pdm_app import step as analytics_step


def local():
    env=json.loads((ROOT/'aas/PET_Twin.environment.json').read_text(encoding='utf-8'));checks=[]
    with FakeAAS(env) as server:
        w=AasTwinWriter(server.url,token='pet-test-token',flush_s=.1);w.prepare();w.start();e=PetProcess();seq=0;origin=time.time()
        # Engine is fast, but await each test window's acknowledgement for exact no-loss assertions.
        while e.completed_cycles<3:
            e.step()
            if e.n%60==0:
                seq+=1;s={**initial_snapshot(),**e.state(),'Sequence':seq,'Timestamp':time.time(),'TimestampISO':iso(time.time()),'StartedISO':iso(origin),'Session':'e2e','Connection':'ConnectedSimulated'}
                w.add_sample(s);deadline=time.monotonic()+5
                while w.sent_sequence<seq and time.monotonic()<deadline:time.sleep(.005)
                if w.sent_sequence<seq:raise AssertionError('current window not delivered')
        seq+=1;s.update(e.state());s.update(Sequence=seq,Timestamp=time.time());w.add_sample(s)
        if not w.close():raise AssertionError('writer flush timed out')
        h=AasHttp(server.url,token='pet-test-token');current=parse_snapshot(h.get_value(w.profile.ids['TwinRuntime'],'Current'))
        assert current['Produced']==72 and current['CompletedCycles']==3
        assert current['Good']+current['Reject']==72 and current['Connection']=='Disconnected'
        checks.extend(['3 full PET cycles -> AAS','production counters','normal shutdown'])
        history=h.get_value(w.profile.ids['TwinRuntime'],'History');sequences=[int(r['Sequence']) for r in history.values() if int(r['Sequence'])>0]
        assert len(sequences)==len(set(sequences));assert max(sequences)==seq;assert w.stats()['records_dropped']==0
        checks.extend(['time-series/history saved','no duplicate record IDs','no data loss'])
        analytics=analytics_step(h,w.profile.manifest);assert analytics['MeanCycleTime']==sum(e.duration(i) for i in range(2,9));assert analytics['RULStatus']=='NotImplemented';checks.extend(['KPI from AAS','RUL explicitly unavailable'])
        w2=AasTwinWriter(server.url,token='pet-test-token');restored=w2.prepare();assert restored['Produced']==72;assert restored['Sequence']==seq;w2.http.close();checks.append('restart continuity')
        h.close();stats=w.stats()
    return {'status':'PASS','checks':checks,'writer':stats,'actual_basyx':'NOT_RUN','aws':'NOT_RUN','grafana_backend':'NOT_RUN'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--aas-url');p.add_argument('--out',type=Path,default=ROOT/'output/e2e_result.json');a=p.parse_args()
    if a.aas_url:
        from deploy.aws.remote_check import check
        results=check(a.aas_url,True);result={'status':'FAIL' if any(r['status']=='FAIL' for r in results) else 'PASS','checks':results}
    else:result=local()
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,indent=2));sys.exit(result['status']!='PASS')
