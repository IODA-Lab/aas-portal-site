"""Build a portable Simio team ZIP with explicit binaries and no local secrets."""
import hashlib
import argparse
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DLL='simio/NativeTelemetry/bin/Release/net10.0-windows/PetSimioTelemetry.dll'
GUIDE='docs/PET_Simio_PostgreSQL_실행가이드.pdf'
EXCLUDED={'__pycache__','.git','.venv','node_modules','obj','bin','output','dist','tmp'}
EXT={'.py','.js','.mjs','.cjs','.json','.yml','.html','.css','.svg','.md','.aasx','.xml','.cs','.csproj','.spfx','.txt','.ps1','.bat','.sql'}
LAUNCH={'Install_Simio_Extension.ps1','Install_Simio_Extension.bat','Simio_Team.ps1','Start_Simio_Team.bat','Stop_Simio_Team.bat','Status_Simio_Team.bat','Backup_PostgreSQL.ps1','Backup_PostgreSQL.bat'}
FIRST='''PET Simio + PostgreSQL 팀원 배포판 / 2026-10-28 / UI 3.0

1. ZIP 전체를 압축 해제합니다. 먼저 동봉한 PDF를 읽어 주세요.
2. 호환되는 Simio 20 학생 에디션 및 Docker Desktop이 필요합니다.
   Simio 설치 파일과 라이선스는 포함하지 않습니다.
3. Simio를 닫고 PET_Simio/launch/Install_Simio_Extension.bat 실행.
4. PET_Simio/simio/PET_24Cavity_27_5s.spfx를 열고 Shift+F6.
5. PET_Simio/launch/Start_Simio_Team.bat 실행.
6. http://localhost:3004/d/pet-injection-twin 접속.
   ID: admin / 비밀번호: 처음 생성된 PET_Simio/simio-team.local.env 참조.
7. 종료: Stop_Simio_Team.bat 먼저 실행, 이후 Simio 종료.

대시보드 상단 '중요 데이터 보기'를 누르면 생산·품질·온도·압력 핵심 값만 봅니다.
'전체 대시보드로 돌아가기'로 3D 화면에 복귀하며, 조회 시간 범위는 유지됩니다.
3D 바로 아래 '어떤 지표가 중요한가요?'를 누르면 같은 화면에서 중요 이유를 봅니다.
우선 확인할 지표는 은은한 청록색으로 구분하며, 경보나 정상 범위 판정 색상은 아닙니다.
3D 패널에서는 모델이 고정되고 오른쪽 공정·재생 메뉴만 스크롤됩니다.

공정 계산은 Simio, Python은 AAS 전달과 DB 저장을 담당합니다.
기존 버전도 AAS 현재값을 약 1초마다 갱신했습니다.
이번 버전은 AAS 갱신을 유지하면서 운전값과 완료 사이클을 PostgreSQL에 누적합니다.
DB: localhost:15432 / pet_history / pet
DB 비밀번호: simio-team.local.env의 PET_POSTGRES_PASSWORD
백업: Backup_PostgreSQL.bat
모든 값은 합성 데이터이며 실제 장비를 제어하지 않습니다.
개인 env 파일과 Docker 볼륨은 ZIP에 포함하지 않습니다.
실행 가이드: PET_Simio_PostgreSQL_실행가이드.pdf
편집용 가이드: PET_Simio/docs/Simio_PostgreSQL_팀원_실행가이드.md
기존 제작자용 3000/8081, Python 팀원용 3003/8083과 다른 배포판입니다.
'''


def collect():
    files=set()
    for dirname in ('aas','aas_seed','contract','grafana','model','viewer','tools','tests','simio','db'):
        for path in (ROOT/dirname).rglob('*'):
            if not path.is_file():continue
            rel=path.relative_to(ROOT)
            if set(rel.parts)&EXCLUDED:continue
            if path.suffix in EXT or path.name in ('LICENSE','Dockerfile'):files.add(rel.as_posix())
    files.update('launch/'+name for name in LAUNCH)
    files.update({'aas_core.py','aas_equipment.py','pet_config.py','simio_bridge.py','sim_publisher.py','kpi.py','pdm_app.py','rul_model.py','requirements.txt','package.json','docker-compose.simio-team.yml','docs/Simio_팀원_실행가이드.md',GUIDE,DLL})
    files.update({'cycle_archive.py','docs/Simio_PostgreSQL_팀원_실행가이드.md'})
    # Superseded experimental output is not an installation option in this ZIP.
    files.difference_update({'simio/Step_ExportTelemetry.py','simio/tools/install_transport.py','simio/tools/discover_transport.py','simio/tools/inspect_simio.py','tools/make_packages.py','tools/build_team_guide.py'})
    # Include PDF builder but preserve its default legacy behavior outside ZIP.
    files.add('tools/build_team_guide.py')
    for rel in files:
        assert (ROOT/rel).is_file(),rel
        assert not rel.endswith(('.local.env','.pem','.key','.pdb','.backup')),rel
    return sorted(files)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,default=ROOT/'dist/PET_Simio_PostgreSQL_Team_20261028.zip')
    out=parser.parse_args().out.resolve()
    out.parent.mkdir(exist_ok=True)
    files=collect()
    manifest={'edition':'PET Simio PostgreSQL team','date':'2026-10-28','viewer_version':'3.0','model':'simio/PET_24Cavity_27_5s.spfx','simio_tested':'20.294.55654 Student','ports':{'grafana':3004,'aas':8084,'postgresql':15432},'files':{rel:hashlib.sha256((ROOT/rel).read_bytes()).hexdigest() for rel in files}}
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('00_먼저읽기.txt',FIRST)
        z.write(ROOT/GUIDE,'PET_Simio_PostgreSQL_실행가이드.pdf')
        z.writestr('PET_Simio/README.md','# PET Simio PostgreSQL 팀원 배포판\n\n'+FIRST+'\n자세한 실행법은 docs/Simio_PostgreSQL_팀원_실행가이드.md를 참고하세요.\n')
        z.writestr('PET_Simio/package_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
        for rel in files:z.write(ROOT/rel,'PET_Simio/'+rel)
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        names=z.namelist()
        assert 'PET_Simio/'+DLL in names
        assert not any('.local.env' in n or '/output/' in n or '/.venv/' in n for n in names)
        # Ensure this PC's actual password values never entered the archive.
        secrets=[]
        for env in ROOT.glob('*.local.env'):
            for line in env.read_text(encoding='utf-8-sig').splitlines():
                if '=' in line and 'PASSWORD' in line.split('=',1)[0]:secrets.append(line.split('=',1)[1].strip().encode())
        for name in names:
            data=z.read(name)
            assert not any(secret and secret in data for secret in secrets),'credential found in '+name
    digest=hashlib.sha256(out.read_bytes()).hexdigest()
    out.with_suffix('.sha256.txt').write_text(digest+'  '+out.name+'\n',encoding='utf8')
    print(json.dumps({'zip':str(out),'files':len(files),'bytes':out.stat().st_size,'sha256':digest},ensure_ascii=False))


if __name__=='__main__':main()
