"""Extend the tested Simio guide with PostgreSQL operation and storage semantics."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'docs/Simio_팀원_실행가이드.md').read_text(encoding='utf8')
text=text.replace('# Simio 팀원 실행 가이드','# Simio + PostgreSQL 가이드')
text=text.replace('Windows 배포판 | 2026년 10월 28일 | 24캐비티 / 27.5초','Windows PostgreSQL 포함판 | 2026년 10월 28일 | 24캐비티 / 27.5초')
text=text.replace('PET_Simio_팀원_실행가이드.pdf','PET_Simio_PostgreSQL_실행가이드.pdf')
text=text.replace('팀원용 AAS:     http://localhost:8084','팀원용 AAS:     http://localhost:8084\n+PostgreSQL:     localhost:15432 / pet_history'.replace('\n+','\n'))
text=text.replace('Simio 공정 → C# PETTelemetry 출력 → Docker의 Python 전달기 → BaSyx AAS / MongoDB → Grafana 수치·그래프·3D 순서입니다. Python 전달기는 공정이나 생산수량을 계산하지 않습니다.',
'''Simio 공정 → C# 출력 → 전달기 → AAS → Grafana로 실시간 연결됩니다. 전달기는 같은 관측값을 디스크 대기열에도 넣고, 별도 저장기가 PostgreSQL에 누적합니다. Python은 공정을 계산하지 않습니다.

이전 버전도 AAS Current를 약 1초마다 갱신했습니다. 이번 추가 기능은 PostgreSQL의 장기 이력 저장입니다. MongoDB는 AAS 모델·최근 이력을, PostgreSQL은 운전 시계열·완료 사이클 기록을 보관합니다.''')
text=text.replace('최초 이미지·Grafana 플러그인 다운로드에는 인터넷이 필요합니다.','최초 이미지·플러그인·DB 드라이버 설치에는 인터넷이 필요합니다.')
text=text.replace('팀원용 Grafana·AAS·MongoDB를 정지합니다.','저장기를 거쳐 팀원용 Grafana·AAS·MongoDB·PostgreSQL을 정지합니다.')
text=text.replace('이 PDF와 편집 가능한 Markdown 가이드입니다.','PostgreSQL 저장 코드·SQL, 이 PDF와 Markdown 가이드입니다.')
text=text.replace('기본 이력은 최근 60개 기록의 순환 버퍼이며 장기간 전체 이력을 보관하는 시스템은 아닙니다.',
                  'AAS 기본 이력은 최근 60개 기록의 순환 버퍼입니다. PostgreSQL은 별도로 운전값과 완료 사이클을 누적합니다. 8장의 DB 조회로 저장 상태도 확인합니다.')
text=text.replace('| 드래그 / 스크롤 | 모델 회전 / 확대·축소 |',
                  '| 모델 위에서 드래그 / 휠 | 모델 회전 / 확대·축소 |\n| 오른쪽 공정·재생 메뉴에서 휠 | 모델 화면은 고정하고 오른쪽 메뉴만 위아래 이동 |')
text=text.replace('# 4 종료·재실행·절전 복구','''# 3-1 중요 지표와 화면 사용법

이 배포판은 UI 3.0입니다. 3D와 모든 지표를 보는 기본 대시보드, 핵심 값만 모은 별도 화면을 모두 포함합니다. 두 화면은 같은 AAS 현재값·최근 이력을 읽습니다.

## 3D를 보면서 중요한 지표 확인

3D 바로 아래 ‘어떤 지표가 중요한가요?’ 줄을 누르면 안내가 펼쳐집니다. 연결·경보, 품질, 공정 안정성, 생산성별로 어떤 값을 먼저 봐야 하는지 설명합니다. 다시 누르면 안내만 접힙니다. 아래 운전 지표는 계속 표시됩니다.

별표 대신 은은한 청록색으로 구분했습니다. 중요 숫자 패널에는 짙은 청록색 배경을, 중요 추세에는 차분한 청록색 선을 사용합니다. 이 색은 우선 확인할 항목이라는 뜻이며, 정상 범위·안전 상태·경보 판정 색상이 아닙니다.

| 우선 확인할 지표 | 확인하는 이유 |
|---|---|
| 설비 운전·연결 상태 / 경보 | 데이터가 최신인지, 이상 운전이 있는지 먼저 확인 |
| 불량 / 실린더 대표온도 / 금형 온도 | 누적 불량의 증가와 온도 변화를 함께 비교 |
| 사출 압력 | 사출·보압 동작 중 반복되는 압력 패턴 확인 |
| 최근 사이클 | 완료된 한 사이클의 소요 시간과 생산성 변화 확인 |

## 핵심 값만 따로 보기

상단 ‘중요 데이터 보기’를 누르면 별도 요약 화면으로 이동합니다. 연결·단계·경보, 생산·양품·불량·사이클 시간, 온도·압력과 추세를 모아 봅니다. ‘전체 대시보드로 돌아가기’로 3D 화면에 복귀하며 조회 시간 범위를 유지합니다.

## 스크롤과 데이터가 비어 있을 때

3D 셀 안에서는 모델 화면이 고정됩니다. 오른쪽 공정·재생 메뉴에 마우스를 올려 휠을 움직이면 그 메뉴만 스크롤됩니다. 모델 위의 휠은 확대·축소입니다. 아래 지표로 이동할 때는 3D 바깥에서 대시보드 페이지를 스크롤합니다.

‘API 정상 / 발행 종료’ 또는 ‘데이터 지연’이면 현재값은 숨깁니다. Simio 실행 상태를 확인한 후 Start_Simio_Team.bat을 다시 실행합니다. 경고 아이콘은 별도의 조회 실패이므로 오류 내용을 확인합니다. 이 화면의 추세는 AAS 최근 60개 기록이며, PostgreSQL 전체 이력은 8장의 명령으로 조회합니다.

이전 화면이나 별표가 남아 있으면 Ctrl+Shift+R을 누릅니다. 이전 ZIP을 사용하던 PC는 9장의 업데이트 절차로 기존 env 파일과 DB 볼륨을 유지합니다.

<!-- PAGE -->

# 4 종료·재실행·절전 복구''')
text+='''

<!-- PAGE -->

# 7 무엇이 PostgreSQL에 저장되나요?

## 기존 실시간 AAS와 새 영구 이력

기존 버전에서도 Simio 값은 AAS Current에 약 1초마다 반영됐고, History에는 최근 60개 기록이 순환 저장됐습니다. 이 버전은 그 흐름을 유지하면서 사이클 완료를 감지할 때도 즉시 Current 갱신을 요청합니다. 네트워크·서버 처리 시간에 따라 화면 반영에는 지연이 있을 수 있습니다.

PostgreSQL은 최근 기록을 덮어쓰지 않고 계속 쌓습니다. AAS와 PostgreSQL은 동일한 관측 데이터를 각각 전달받으며, 하나의 분산 트랜잭션은 아닙니다. DB 저장 성공만으로 같은 순간의 AAS 쓰기 성공까지 증명되지는 않습니다. 각각의 상태를 확인합니다.

| 테이블 | 저장 내용 |
|---|---|
| pet_twin.telemetry | 약 1초 간격 및 사이클 완료 시의 운전값. 시각·원본 세션·AAS Sequence·단계·누적 수량·온도·압력·스크루 위치 |
| pet_twin.cycles | 완료 사이클마다 1건. 원본 사이클 번호·완료 관측 시각·사이클 시간·배치 생산/양품/불량·대응 AAS 누적값 |
| 두 테이블의 payload | 추가 AAS 값과 원본 식별 정보를 JSONB 형태로 보존. 사이클에는 원본 상태도 포함 |

0.05초 간격의 모든 3D 자세를 장기 저장하는 구성은 아닙니다. DB 운전 이력은 약 1초 간격이며, 완료 사이클은 빠짐없이 감지하도록 전달기가 매 원본 샘플을 검사합니다. 설비 ID·원본 Simio 세션·샘플/사이클 번호 조합으로 중복 저장을 방지합니다.

## 사이클 번호와 첫 기록 해석

cycle_number는 해당 Simio 실행의 원본 사이클 번호입니다. AAS 누적 사이클은 이전 실행에서 이어질 수 있으므로 서로 다를 수 있습니다. cycles.aas_completed_cycles가 대응 AAS 누적값입니다. 배치 수량과 AAS 총생산도 구분해 읽습니다.

실행 도중 전달기를 연결했다면 첫 사이클 전체를 관찰하지 못했을 수 있습니다. observed_full_cycle=false로 표시합니다. 특히 취출 후 연결한 경우 첫 배치의 양품·불량을 역산하지 않고 NULL로 저장합니다. 다음 온전한 사이클부터 정상 집계합니다. 중도 경보로 완료되지 않은 사이클은 완료 테이블에 넣지 않으며 운전값의 Alarm으로 확인합니다.

<!-- PAGE -->

# 8 DB 접속과 조회

DB 클라이언트에서 아래 값으로 접속합니다. PostgreSQL은 이 PC의 루프백 주소에만 공개됩니다. 다른 PC에서 직접 접속하려고 방화벽이나 포트 공개 범위를 임의로 바꾸지 않습니다.

| 항목 | 값 |
|---|---|
| 호스트 / 포트 | localhost / 15432 |
| 데이터베이스 | pet_history |
| 사용자 | pet |
| 비밀번호 | simio-team.local.env의 PET_POSTGRES_PASSWORD 값 |
| 스키마 | pet_twin |

## PowerShell에서 빠르게 확인

PET_Simio 폴더에서 실행합니다. 별도 Python이나 DB 클라이언트를 PC에 설치하지 않아도 됩니다. 아래 명령은 테이블 건수·최근 기록·저장 대기 건수를 보여 줍니다.

```powershell
docker compose --env-file simio-team.local.env `
  -f docker-compose.simio-team.yml exec -T archive `
  python tools/db_report.py
```

telemetry_rows가 계속 증가하고, cycle_rows가 약 27.5초마다 증가해야 합니다. archive.connected=true는 DB 연결 상태이며 pending은 아직 DB에 확정되지 않은 건수입니다. 정상 운전 중에도 잠깐 1~2건 보일 수 있습니다. 장시간 증가만 하면 archive와 postgres 로그를 확인합니다.

## SQL 예시

```sql
SELECT observed_at, phase, produced, injection_pressure_bar
FROM pet_twin.telemetry
ORDER BY observed_at DESC LIMIT 20;

SELECT cycle_number, completed_at, cycle_time_seconds,
       batch_produced, batch_good, batch_reject,
       observed_full_cycle
FROM pet_twin.cycles
ORDER BY completed_at DESC LIMIT 20;
```

시각은 PostgreSQL timestamptz로 저장합니다. 클라이언트 시간대 설정에 따라 UTC 또는 한국 시각으로 표시됩니다. source_session이 달라지면 별도의 Simio 실행입니다. 단순히 cycle_number만으로 여러 실행의 기록을 합치지 않습니다.

<!-- PAGE -->

# 9 장애 복구·백업·업데이트

## PostgreSQL이 잠시 중단된 경우

Simio와 전달기가 계속 실행 중이면 AAS는 계속 갱신되고, 관측된 기록은 simio-outbox Docker 볼륨의 디스크 대기열에 남습니다. DB가 복구되면 저장기가 자동 재시도합니다. DB에 확정한 뒤 대기열에서 지우므로 중간 재시작에도 같은 기록을 중복 삽입하지 않습니다.

이 보장은 전달기가 정상적으로 관측하여 대기열에 기록한 데이터에 해당합니다. PC 절전·Simio 종료·전달기 자체 중단 기간의 데이터를 만들어 복원하지 않습니다. 디스크 용량 부족이나 볼륨 삭제 역시 복구 대상이 아닙니다. 중단 기간은 공백으로 남습니다.

저장 대기열은 archive 서비스가 처리하므로 Simio가 멈춘 뒤에도 DB가 살아 있으면 이미 대기 중인 기록은 반영됩니다. 수동 종료 시에는 Stop_Simio_Team.bat을 먼저 실행하고 Simio를 닫습니다. DB가 내려가 있어 대기열을 비우지 못해도 볼륨에 남겨 다음 실행에서 처리합니다.

## 백업

PostgreSQL 실행 중 launch/Backup_PostgreSQL.bat을 실행합니다. backups 폴더에 시각이 붙은 .dump 파일을 만듭니다. pg_dump의 custom 형식이며 pg_restore로 별도 DB에 복원할 수 있습니다. 기존 DB를 덮어쓰는 자동 복원은 제공하지 않습니다. 로그나 ZIP을 다시 만드는 작업과 DB 백업은 다릅니다.

이력 자동 삭제는 하지 않으므로 DB 크기가 계속 증가합니다. 디스크 사용량을 확인하고 정기적으로 백업합니다. 장기 보존 기간이나 삭제 정책은 팀에서 별도로 정해야 합니다. 20Hz 전체 자세가 아닌 1초 운전값을 저장해도 장기간 운전하면 용량이 커집니다.

## 이전 Simio ZIP에서 업데이트

기존 팀원용 Stop_Simio_Team.bat으로 종료한 후, 새 ZIP을 별도 폴더에 풉니다. 같은 PC의 기존 이력을 이어 쓸 경우 기존 simio-team.local.env를 새 PET_Simio 폴더에 복사합니다. 기존 볼륨은 삭제하지 않습니다. 새 Start는 기존 Grafana 비밀번호를 유지하고 PostgreSQL 비밀번호만 추가 생성합니다.

PostgreSQL 볼륨이 이미 있는데 비밀번호 항목이 사라졌다면 자동으로 새 비밀번호를 만들지 않습니다. 원래 env 파일을 복구해야 합니다. 새 PC에서는 제작자의 env 파일을 받지 말고 처음 실행 시 자체 생성합니다.

이 기능은 팀원용 3004/8084 환경에 포함됩니다. 제작자용 3000/8081 실행 파일에는 PostgreSQL 저장이 자동으로 붙지 않습니다. 두 환경을 혼용하지 말고 이번 ZIP의 Start_Simio_Team.bat을 사용합니다.
'''
(ROOT/'docs/Simio_PostgreSQL_팀원_실행가이드.md').write_text(text,encoding='utf8')
