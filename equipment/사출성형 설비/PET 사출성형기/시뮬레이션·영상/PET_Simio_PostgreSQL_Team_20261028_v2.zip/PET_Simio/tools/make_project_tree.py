"""Write the complete deliverable tree, excluding reproducible runtime directories."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXCLUDE={'.venv','__pycache__','node_modules','.git','output','dist'}


def make():
    out=ROOT/'docs/프로젝트_전체트리.txt'
    out.touch(exist_ok=True)
    lines=['디지털트윈_PET사출성형기/','└── 실시간_대시보드/'];count=0
    def visit(folder,prefix):
        nonlocal count
        entries=sorted((p for p in folder.iterdir() if p.name not in EXCLUDE and p.name not in ('.env','equipment.env','secrets.local.env')),key=lambda p:(not p.is_dir(),p.name.lower()))
        for i,p in enumerate(entries):
            last=i==len(entries)-1;lines.append(prefix+('└── ' if last else '├── ')+p.name+('/' if p.is_dir() else ''))
            if p.is_dir():visit(p,prefix+('    ' if last else '│   '))
            else:count+=1
    visit(ROOT,'    ')
    lines+=['',f'전체 제공 파일: {count}개 (아래 재생성 가능한 런타임 디렉터리는 상세 나열에서 제외)','로컬 .venv/: 검증용 Python 패키지. 공유 ZIP 미포함.','로컬 __pycache__/: Python 캐시. 공유 ZIP 미포함.','로컬 output/: 실행 원시 로그·JSONL·검증 중간 산출물. 확정 기록은 docs/validation/에 포함.','로컬 dist/: PET_Twin_team.zip. ZIP 자신을 다시 포함하지 않음.','선택 node_modules/: Playwright 설치 시 생성. 공유 ZIP 미포함.']
    out.write_text('\n'.join(lines)+'\n',encoding='utf-8');print(f'Tree written: {count} deliverable files')


if __name__=='__main__':make()
