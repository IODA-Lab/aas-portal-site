"""Dedicated team stack: create absent PET model once, then publish live data."""
import signal
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pet_config as cfg
from aas_core import AasHttp
from aas_seed.seed import seed
from tools.aas_model import read_aasx
from sim_publisher import main


def interrupted(*_):
    raise KeyboardInterrupt


def run():
    signal.signal(signal.SIGTERM,interrupted)
    http=AasHttp(cfg.AAS_URL,timeout=3,retries=0)
    try:
        for attempt in range(90):
            try:
                status,_=http.request('GET','/shells')
                if status==200: break
            except (ConnectionError,OSError): pass
            time.sleep(2)
        else: raise RuntimeError('BaSyx unavailable; check docker compose logs aas-env')
        env,_=read_aasx(cfg.ROOT/'aas/PET_Twin.aasx')
        # Read-only preflight; existing IDs are never reset or overwritten by seeding.
        print(seed(http,env,concept_descriptions=True),flush=True)
    finally:
        http.close()
    sys.argv=['sim_publisher.py','--mode','live','--aas-url',cfg.AAS_URL]
    return main()


if __name__=='__main__':
    try: sys.exit(run())
    except KeyboardInterrupt: sys.exit(0)
