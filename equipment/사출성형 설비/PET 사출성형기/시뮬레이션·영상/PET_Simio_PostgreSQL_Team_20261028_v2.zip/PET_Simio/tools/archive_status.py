import json
import os
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cycle_archive import Outbox

if __name__=='__main__':
    queue=Outbox(os.environ['PET_ARCHIVE_OUTBOX'])
    value=queue.status();queue.close()
    print(json.dumps(value))
    sys.exit(0 if value.get('connected') and time.time()-value.get('checked_at',0)<10 else 1)
