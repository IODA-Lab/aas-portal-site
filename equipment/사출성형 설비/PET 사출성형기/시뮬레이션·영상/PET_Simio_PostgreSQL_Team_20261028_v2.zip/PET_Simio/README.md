# PET Simio PostgreSQL 팀원 배포판

PET Simio + PostgreSQL 팀원 배포판 / 2026-10-28 / UI 3.0

1. ZIP 전체를 압축 해제합니다. 먼저 동봉한 PDF를 읽어 주세요.
2. 호환되는 Simio 20 학생 에디션 및 Docker Desktop이 필요합니다.
   Simio 설치 파일과 라이선스는 포함하지 않습니다.
3. Simio를 닫고 PET_Simio/launch/Install_Simio_Extension.bat 실행.
4. PET_Simio/simio/PET_24Cavity_27_5s.spfx를 열고 Shift+F6.
5. PET_Simio/launch/Start_Simio_Team.bat 실행.
6. http://localhost:3004/d/pet-injection-twin 접속.
   ID: admin / 비밀번호: 처음 생성된 PET_Simio/simio-team.local.env 참조.
7. 종료: Stop_Simio_Team.bat 먼저 실행, 이후 Simio 종료.

대시보드 상단 '중요 데이터 보기'를 누르면 생산·품질·온도·압력 핵심 값만 봅니다.
'전체 대시보드로 돌아가기'로 3D 화면에 복귀하며, 조회 시간 범위는 유지됩니다.
3D 바로 아래 '어떤 지표가 중요한가요?'를 누르면 같은 화면에서 중요 이유를 봅니다.
우선 확인할 지표는 은은한 청록색으로 구분하며, 경보나 정상 범위 판정 색상은 아닙니다.
3D 패널에서는 모델이 고정되고 오른쪽 공정·재생 메뉴만 스크롤됩니다.

공정 계산은 Simio, Python은 AAS 전달과 DB 저장을 담당합니다.
기존 버전도 AAS 현재값을 약 1초마다 갱신했습니다.
이번 버전은 AAS 갱신을 유지하면서 운전값과 완료 사이클을 PostgreSQL에 누적합니다.
DB: localhost:15432 / pet_history / pet
DB 비밀번호: simio-team.local.env의 PET_POSTGRES_PASSWORD
백업: Backup_PostgreSQL.bat
모든 값은 합성 데이터이며 실제 장비를 제어하지 않습니다.
개인 env 파일과 Docker 볼륨은 ZIP에 포함하지 않습니다.
실행 가이드: PET_Simio_PostgreSQL_실행가이드.pdf
편집용 가이드: PET_Simio/docs/Simio_PostgreSQL_팀원_실행가이드.md
기존 제작자용 3000/8081, Python 팀원용 3003/8083과 다른 배포판입니다.

자세한 실행법은 docs/Simio_PostgreSQL_팀원_실행가이드.md를 참고하세요.
