"""Infinity backend JSONata + Grafana shared-query pattern from reference dashboards."""
import argparse
import copy
import json
import sys
from pathlib import Path
from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from aas_core import b64

AAS={'type':'yesoreyeram-infinity-datasource','uid':'aas-infinity'}
SHARED={'type':'datasource','uid':'-- Dashboard --'}


def dashboard_link(title,uid,tooltip):
    return {'title':title,'type':'link','icon':'dashboard','tooltip':tooltip,
            'url':'/d/'+uid,'tags':[],'asDropdown':False,'targetBlank':False,
            'includeVars':False,'keepTime':True}


def target(url,selector,columns,ref='A',datasource=None):
    return {'refId':ref,'datasource':datasource or AAS,'type':'json','source':'url','format':'table','parser':'backend','url':url,'url_options':{'method':'GET'},'root_selector':selector,'columns':[{'selector':key,'text':key,'type':typ} for key,typ in columns]}


def build(base,runtime_id,datasource_uid='aas-infinity',viewer_url='/public/pet/viewer/index.html?mode=live&embed=1&transport=grafana'):
    viewer=urlsplit(viewer_url)
    local_viewer=not viewer.scheme and not viewer.netloc and viewer.path=='/public/pet/viewer/index.html'
    if not local_viewer and (viewer.scheme not in ('http','https') or not viewer.hostname or viewer.username or viewer.password):
        raise ValueError('viewer URL must be HTTP(S), without credentials')
    if local_viewer:
        params=dict(parse_qsl(viewer.query))
        params.update(datasource=datasource_uid,base=base.rstrip('/'),runtime=runtime_id,v='3.0')
        viewer_url=urlunsplit(('', '', viewer.path, urlencode(params), ''))
    datasource={**AAS,'uid':datasource_uid}
    prefix=base.rstrip('/')+'/submodels/'+b64(runtime_id)+'/submodel-elements/'
    # Two metric queries per dashboard refresh; the 3D viewer polls Current separately at 1 Hz.
    fields=['BarrelTemperature','MoldTemperature','InjectionPressure','ScrewPosition','CycleTime','Produced','Good','Reject','CycleProgress','Timestamp']
    # HTTP/JSON/parser failures deliberately remain Grafana query errors, never a fake Disconnected row.
    selector='($schema := $exists(Sequence) and $exists(Timestamp) and $exists(Connection)?true:$number("PET Current schema mismatch"); $seq := $number(Sequence); $age := $millis()/1000-$number(Timestamp); $fresh := $seq>0 and Connection="ConnectedSimulated" and $age>=-2 and $age<5; $code := $seq=0?"NO_DATA":Connection!="ConnectedSimulated"?"STOPPED":$age < -2?"CLOCK_SKEW":$age>=5?"STALE":"LIVE"; [{"Status":$code="NO_DATA"?"API 정상 / 발행 대기":$code="STOPPED"?"API 정상 / 발행 종료":$code="CLOCK_SKEW"?"API 정상 / 시계 오차":$code="STALE"?"API 정상 / 데이터 지연":"API 정상 / 수신 중","StateCode":$code,"RunState":$fresh?RunState:"—","Sequence":$seq,"AgeSeconds":$seq>0?$age:null,"Connection":Connection,"Phase":$fresh?Phase:"—","Alarm":$fresh?Alarm:"—",'+','.join('"'+k+'":$fresh?$number('+k+'):null' for k in fields)+'}])'
    current=target(prefix+'Current/%24value',selector,[(k,'string') for k in ['Status','StateCode','RunState','Connection','Phase','Alarm']]+[(k,'number') for k in fields+['Sequence','AgeSeconds']],datasource=datasource)
    hist_fields=['BarrelTemperature','MoldTemperature','InjectionPressure','ScrewPosition']
    hsel='($schema := $type($)="object" and $exists(Record0000)?true:$number("PET History schema mismatch"); $rows := $each($,function($r){$number($r.Sequence)>0?{"time":$number($r.Timestamp)*1000,'+','.join('"'+k+'":$number($r.'+k+')' for k in hist_fields)+'}:undefined}); $count($rows)>0?$sort($rows,function($l,$r){$l.time>$r.time}):[{"time":$millis(),'+','.join('"'+k+'":null' for k in hist_fields)+'}])'
    history=target(prefix+'History/%24value',hsel,[('time','timestamp_epoch')]+[(k,'number') for k in hist_fields],'TS',datasource)
    panels=[]
    def panel(i,title,ptype,x,y,w,h,source,field,unit='none',query=None):
        defaults={'unit':unit,'noValue':'— · 수신 상태 확인','decimals':1}
        options={'reduceOptions':{'calcs':['last'],'fields':field,'values':False},'textMode':'value_and_name','colorMode':'value','graphMode':'none'}
        tf=[]
        if ptype=='timeseries':
            defaults['custom']={'lineWidth':2,'fillOpacity':10,'spanNulls':False,'insertNulls':3000}
            options={'legend':{'displayMode':'list','placement':'bottom','showLegend':True},'tooltip':{'mode':'multi'}}
            tf=[{'id':'filterFieldsByName','options':{'include':{'names':['time',field]}}}]
        targets=[query] if query else [{'refId':'A','datasource':SHARED,'panelId':source,'withTransforms':False}]
        panels.append({'id':i,'title':title,'type':ptype,'gridPos':{'x':x,'y':y,'w':w,'h':h},'datasource':datasource if query else SHARED,'targets':targets,'fieldConfig':{'defaults':defaults,'overrides':[]},'options':options,'transformations':tf,'description':'합성 데이터 / SimulationAssumption. 경고 아이콘은 조회 실패: UID·DNS·HTTP·파싱 오류를 Inspect → Error에서 확인. API 정상/발행 대기는 Sequence=0이며 시뮬레이터 시작 필요. 오래된 현재값은 숨김.'})
    panel(1,'설비 운전·연결 상태','stat',0,0,8,4,None,'Status',query=current)
    panel(3,'현재 공정 단계','stat',8,0,8,4,1,'Phase')
    panel(4,'경보','stat',16,0,8,4,1,'Alarm')
    for i,(title,key,unit) in enumerate([('사이클 진행','CycleProgress','percentunit'),('스크류 위치','ScrewPosition','lengthmm'),('최근 사이클','CycleTime','s'),('총생산','Produced','none'),('양품','Good','none'),('불량','Reject','none')],5): panel(i,title,'stat',((i-5)%6)*4,4,4,4,1,key,unit)
    panel(2,'실린더 대표온도 추세 · °C','timeseries',0,8,12,7,None,'BarrelTemperature','celsius',history)
    panel(11,'금형 온도 추세 · °C','timeseries',12,8,12,7,2,'MoldTemperature','celsius')
    panel(12,'사출 압력 추세 · bar','timeseries',0,15,12,7,2,'InjectionPressure','pressurebar')
    panel(13,'스크류 위치 추세 · mm','timeseries',12,15,12,7,2,'ScrewPosition','lengthmm')
    panel(15,'장비 운전 상태','stat',0,22,8,4,1,'RunState')
    panel(16,'수신 Sequence','stat',8,22,8,4,1,'Sequence')
    panel(17,'마지막 수신 경과','stat',16,22,8,4,1,'AgeSeconds','s')
    panels.append({'id':14,'title':'조회 오류와 운전 데이터 상태 구분','type':'text','gridPos':{'x':0,'y':26,'w':24,'h':5},'options':{'mode':'markdown','content':'**경고 아이콘 / Query error**: 데이터소스 UID, Docker DNS, HTTP 404/401/500 또는 JSONata 파싱 오류입니다. 패널 메뉴 → Inspect → Error에서 원문을 확인하세요. **API 정상 / 발행 대기**: PET 모델은 있으나 Sequence=0, Python 발행기를 시작하세요. **데이터 지연**: 마지막 갱신 5초 이상. **발행 종료**: 정상 종료 또는 Disconnected. 빈 현재 수치는 위 상태와 함께 해석하세요.\n\n**PET Python 시뮬레이션** · 합성 데이터 / SimulationAssumption. 실린더 대표온도는 실제 Zone 센서값이 아닙니다. RUL: **미구현**. 추세는 기록 당시의 과거 값입니다.'}})
    important={
        1:'먼저 확인: 현재 숫자가 최신 수신값인지 판단하는 기준입니다.',
        4:'먼저 확인: 시뮬레이션의 이상 운전 발생 여부를 확인합니다.',
        10:'품질: 누적 불량 수량의 증가를 생산·양품 수량과 함께 확인합니다.',
        2:'품질·공정: 수지 가열 상태의 변화를 보는 대표온도입니다. 실제 Zone 센서값은 아닙니다.',
        11:'품질·공정: 냉각 상태와 사이클 변화를 함께 살펴보는 지표입니다.',
        12:'공정 안정성: 사출·보압 단계의 압력 변화가 반복되는 패턴을 확인합니다.',
        7:'생산성: 마지막 완료 사이클의 소요 시간으로 처리 속도 변화를 확인합니다.'}
    for item in panels:
        item['gridPos']['y']+=16
        if item['id'] in important:
            item['description']=important[item['id']]+' 청록색 강조는 중요도 표시이며 경보 판정이 아닙니다. '+item['description']
            defaults=item['fieldConfig']['defaults']
            defaults['color']={'mode':'fixed','fixedColor':'#20383E' if item['type']=='stat' else '#88B8C2'}
            if item['type']=='stat':item['options']['colorMode']='background_solid'
    guidance=[
        ('먼저 확인 · 연결 상태와 경보','**설비 운전·연결 상태 / 경보**\n\n숫자를 읽기 전에 최신 데이터인지, 이상 운전이 있는지 확인합니다. 발행 종료·데이터 지연이면 현재값으로 판단하지 않습니다.'),
        ('품질 · 불량과 온도','**불량 / 실린더 대표온도 / 금형 온도**\n\n불량 수량의 증가와 온도 추세를 함께 봅니다. 불량은 누적 수량이므로 총생산·양품과 비교합니다. 온도만으로 불량 원인을 확정하지 않습니다.'),
        ('공정 안정성 · 사출 압력','**사출 압력 추세**\n\n3D의 사출·보압 동작과 압력 변화를 함께 봅니다. 반복되는 압력 패턴이 달라지는지 확인하고, 스크류 위치를 보조 지표로 참고합니다.'),
        ('생산성 · 최근 사이클','**최근 사이클**\n\n한 사이클을 마치는 데 걸린 시간입니다. 총생산·양품 수량과 함께 처리 속도를 봅니다. 청록색 강조는 우선 확인 표시이며 정상 범위나 경보 기준은 아닙니다.')]
    panels.append({'id':19,'title':'어떤 지표가 중요한가요? · 눌러서 안내 펼치기 / 접기','type':'row','collapsed':True,
                   'gridPos':{'x':0,'y':14,'w':24,'h':1},
                   'panels':[{'id':24+i,'title':title,'type':'text','gridPos':{'x':i*6,'y':15,'w':6,'h':6},
                              'options':{'mode':'markdown','content':content}} for i,(title,content) in enumerate(guidance)]})
    # An explicit following row prevents collapsing the guide from absorbing the live panels.
    panels.append({'id':28,'title':'전체 운전 지표 · 청록색 강조 항목을 먼저 확인하세요','type':'row','collapsed':False,
                   'gridPos':{'x':0,'y':15,'w':24,'h':1},'panels':[]})
    panels.append({'id':18,'title':'PET 실시간 3D · 공정 단계별 동작','type':'innius-video-panel','gridPos':{'x':0,'y':0,'w':24,'h':14},'targets':[],
        'options':{'videoType':'iframe','iframeURL':viewer_url,'autoPlay':False,'loop':False,'customBackground':True,'backgroundColor':'#0c141c'},
        'description':'AAS Current를 1초마다 조회하고 20 Hz 기록을 보간하여 표시합니다. 약 1–2초 지연. 합성 데이터 / 일반 구조 모식도. 조회 실패·5초 이상 지연·발행 종료 시 정지합니다.',
        'links':[{'title':'3D 뷰어 별도 창','url':viewer_url,'targetBlank':True}]})
    return {'uid':'pet-injection-twin','title':'PET 프리폼 사출성형기 · 합성 데이터','schemaVersion':39,'version':1,'tags':['PET','Simulation'],'timezone':'browser','refresh':'5s','time':{'from':'now-5m','to':'now'},'panels':sorted(panels,key=lambda p:(p['gridPos']['y'],p['gridPos']['x'])),'annotations':{'list':[]},'templating':{'list':[]},
            'links':[dashboard_link('중요 데이터 보기','pet-key-metrics','생산·품질·공정 핵심 값 모아보기')]}


def build_key_metrics(dashboard):
    """A compact view of the same live queries, including their stale/error rules."""
    result=copy.deepcopy(dashboard)
    result.update(uid='pet-key-metrics',title='PET 중요 데이터 · 생산·품질·공정',
                  description='AAS 현재값과 최근 이력의 핵심 지표. 합성 데이터.',
                  links=[dashboard_link('전체 대시보드로 돌아가기','pet-injection-twin','3D 모델과 전체 패널 보기')])
    original={p['id']:p for p in result['panels']}
    for p in original.values():
        if p.get('type')=='timeseries':p['fieldConfig']['defaults'].pop('color',None)
    panels=[]
    # Keep query-owner IDs 1 (Current) and 2 (History) for dashboard sharing.
    for pid,x,y,w,h in [(1,0,0,8,3),(3,8,0,8,3),(4,16,0,8,3),
                        (8,0,3,6,4),(9,6,3,6,4),(10,12,3,6,4),(7,18,3,6,4),
                        (2,0,11,8,7),(11,8,11,8,7),(12,16,11,8,7)]:
        p=original[pid]
        p['gridPos']={'x':x,'y':y,'w':w,'h':h}
        if p['type']=='stat':
            p['options']['textMode']='value'
            p['options']['colorMode']='value'
            p['fieldConfig']['defaults']['noValue']='—'
            # Quantity/temperature alone is not a validated alarm threshold.
            p['fieldConfig']['defaults']['color']={'mode':'fixed','fixedColor':'light-blue'}
            if pid in (8,9,10):p['fieldConfig']['defaults']['decimals']=0
        panels.append(p)
    for pid,x,title,key,unit in [(20,0,'실린더 대표온도','BarrelTemperature','celsius'),
                               (21,8,'금형 온도','MoldTemperature','celsius'),
                               (22,16,'사출 압력','InjectionPressure','pressurebar')]:
        p=copy.deepcopy(original[7])
        p.update(id=pid,title=title,gridPos={'x':x,'y':7,'w':8,'h':4})
        p['options']['reduceOptions']['fields']=key
        p['fieldConfig']['defaults']['unit']=unit
        panels.append(p)
    panels.append({'id':23,'title':'중요 데이터 읽는 방법','type':'text',
                   'gridPos':{'x':0,'y':18,'w':24,'h':3},
                   'options':{'mode':'markdown','content':'**현재값은 5초마다 새로고침**합니다. 생산·양품·불량은 누적 수량, 최근 사이클은 마지막 완료 시간입니다. 온도·압력은 순간값입니다. **합성 데이터**이며 색상은 정상·불량 판정 기준이 아닙니다.\n\n상단 연결 상태를 함께 확인하세요. 발행 대기·종료·5초 이상 지연이면 현재값은 숨기고, 조회 실패는 경고 아이콘으로 표시합니다. 추세는 AAS의 최근 60개 이력이며, PostgreSQL 전체 저장 이력 조회 화면은 아닙니다.'}})
    result['panels']=sorted(panels,key=lambda p:(p['gridPos']['y'],p['gridPos']['x']))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--aas-internal',default='http://aas-env:8081'); p.add_argument('--datasource-uid',default='aas-infinity'); p.add_argument('--viewer-url',default='/public/pet/viewer/index.html?mode=live&embed=1&transport=grafana'); p.add_argument('--out',type=Path,default=ROOT/'grafana/dashboards/pet_dashboard.json'); a=p.parse_args()
    m=json.loads((ROOT/'aas/twin_manifest.json').read_text(encoding='utf-8'))
    dashboard=build(a.aas_internal,m['submodels']['TwinRuntime'],a.datasource_uid,a.viewer_url)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    for path,data in [(a.out,dashboard),(a.out.with_name('pet_key_metrics.json'),build_key_metrics(dashboard))]:
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        print(path)

