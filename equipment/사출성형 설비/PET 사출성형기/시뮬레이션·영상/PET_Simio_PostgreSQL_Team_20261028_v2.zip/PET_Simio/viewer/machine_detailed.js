import * as THREE from 'three';
import {takeoutPose,TAKEOUT} from './takeout_motion.js?v=2.9';

// Illustrative assembly, not manufacturer CAD. Existing AAS motion signals drive every actuator.
export function buildMachine(scene) {
  const root=new THREE.Group();root.name='PET 24 detailed assembly';scene.add(root);
  const mat=(color,metalness=0,roughness=.4,extra={})=>new THREE.MeshStandardMaterial({color,metalness,roughness,...extra});
  const m={ivory:mat(0xe4e7e5,.25,.32),navy:mat(0x263b4a,.45,.34),dark:mat(0x17232b,.25,.45),steel:mat(0x99a7b1,.85,.25),chrome:mat(0xdce8ee,.96,.14),brass:mat(0xc59a50,.85,.25),blue:mat(0x205991,.5,.28),black:mat(0x11191f,.15,.6),red:mat(0xd64b39,.25,.35),teal:mat(0x1ba69c,.4,.3),glass:mat(0x8cb7cb,.1,.17,{transparent:true,opacity:.14,depthWrite:false}),pet:mat(0xa3e1d5,.2,.16,{transparent:true,opacity:.72,depthWrite:false}),heater:mat(0xb7a084,.78,.3,{emissive:0x6e2809,emissiveIntensity:.1})};
  const cache=new Map();
  function geo(key,make){if(!cache.has(key))cache.set(key,make());return cache.get(key);}
  function mesh(g,material,x=0,y=0,z=0,parent=root){const o=new THREE.Mesh(g,material);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
  function box(w,h,d,x,y,z,material=m.steel,parent=root,bevel=.025){
    const b=Math.min(bevel,w/5,h/5,d/5);
    const g=geo('box'+[w,h,d,b].join(':'),()=>{
      if(!b)return new THREE.BoxGeometry(w,h,d);
      const s=new THREE.Shape(),a=w/2-b,c=h/2-b;s.moveTo(-a,-c);s.lineTo(a,-c);s.lineTo(a,c);s.lineTo(-a,c);s.closePath();
      const g=new THREE.ExtrudeGeometry(s,{depth:d-2*b,bevelEnabled:true,bevelThickness:b,bevelSize:b,bevelSegments:2,steps:1,curveSegments:1});g.translate(0,0,-d/2+b);return g;
    });return mesh(g,material,x,y,z,parent);
  }
  function cyl(r,len,x,y,z,material=m.steel,parent=root,axis='x',r2=r){
    const g=geo('cyl'+[r,r2,len].join(':'),()=>new THREE.CylinderGeometry(r,r2,len,32));const o=mesh(g,material,x,y,z,parent);
    if(axis==='x')o.rotation.z=Math.PI/2;if(axis==='z')o.rotation.x=Math.PI/2;return o;
  }
  function tube(points,r,material=m.black,parent=root){return mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),32,r,8,false),material,0,0,0,parent);}
  function instances(g,material,positions,parent=root){const batch=new THREE.InstancedMesh(g,material,positions.length),matrix=new THREE.Matrix4();positions.forEach((p,i)=>{matrix.makeTranslation(...p);batch.setMatrixAt(i,matrix);});batch.castShadow=true;batch.receiveShadow=true;parent.add(batch);return batch;}
  const boltGeo=new THREE.CylinderGeometry(.035,.035,.025,6);boltGeo.rotateZ(Math.PI/2);
  function bolts(x,ys,zs,parent=root){const a=[];for(const y of ys)for(const z of zs)a.push([x,y,z]);return instances(boltGeo,m.chrome,a,parent);}
  function label(text,w,h,x,y,z,parent=root,bg='#182c38',color='#e5eeed'){
    const c=document.createElement('canvas');c.width=768;c.height=128;const g=c.getContext('2d');g.fillStyle=bg;g.fillRect(0,0,768,128);g.fillStyle=color;g.font='600 48px Segoe UI';g.textAlign='center';g.textBaseline='middle';g.fillText(text,384,64);
    const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;return mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex}),x,y,z,parent);
  }
  // Bed, adjustable feet, service doors, panel gaps and recessed ventilation slots.
  box(8.4,.75,2.15,0,.53,0,m.navy);box(8.5,.12,2.23,0,.94,0,m.steel);
  for(const x of [-3.65,-1.2,1.2,3.65])for(const z of [-.78,.78]){cyl(.14,.09,x,.065,z,m.black,root,'y');cyl(.075,.23,x,.19,z,m.chrome,root,'y');box(.32,.09,.27,x,.3,z,m.steel);}
  for(let i=0;i<6;i++){const x=-3.48+i*1.39;box(1.32,.57,.055,x,.53,1.1,m.ivory);box(.11,.065,.035,x+.43,.62,1.14,m.dark);}
  instances(new THREE.BoxGeometry(.015,.16,.012),m.dark,Array.from({length:19},(_,i)=>[2.85+i*.047,.4,1.137]));
  label('PET  /  24 CAVITY SYSTEM',2.25,.15,-2.46,.54,1.139);box(7.7,.06,.08,0,.86,1.12,m.teal);
  for(const z of [-.8,.8])box(7.4,.06,.1,0,1.035,z,m.chrome);
  // Four polished tie bars, bronze guide bushes and layered fixed/moving platens.
  box(.76,2.25,1.95,-3.7,2.1,0,m.ivory);box(.52,2.14,1.86,-3.2,2.12,0,m.navy);box(.5,2.23,1.98,.35,2.13,0,m.navy);
  const moving=new THREE.Group();moving.name='Moving platen';root.add(moving);box(.34,2.12,1.8,-.76,2.12,0,m.navy,moving);
  for(const y of [1.35,2.92])for(const z of [-.73,.73]){
    cyl(.075,3.95,-1.43,y,z,m.chrome);
    for(const x of [-3.48,.64]){cyl(.12,.14,x,y,z,m.steel);cyl(.15,.075,x+.06,y,z,m.brass);}
    cyl(.125,.38,-.76,y,z,m.brass,moving);cyl(.154,.07,-.54,y,z,m.steel,moving);
  }
  bolts(.61,[1.12,1.65,2.6,3.13],[-.9,.9]);bolts(-.57,[1.13,1.65,2.6,3.1],[-.84,.84],moving);
  cyl(.27,.95,-2.95,2.1,0,m.blue);cyl(.31,.1,-2.42,2.1,0,m.steel);
  const clampRod=cyl(.12,1.5,-1.67,2.1,0,m.chrome);
  tube([[-3.25,2.34,0],[-3.45,2.5,-.38],[-3.55,1.15,-.8],[-2.9,1.05,-.85]],.04);
  tube([[-2.62,2.34,0],[-2.7,2.6,-.5],[-2.9,1.1,-.9]],.03);
  // A 6 x 4 cavity array with core pins, neck rings and guide pins.
  for(const [x,w,material] of [[-.02,.13,m.steel],[-.145,.095,m.dark],[-.26,.13,m.steel]])box(w,1.3,1.25,x,2.1,0,material);
  for(const [x,w,material] of [[-.54,.12,m.steel],[-.445,.06,m.dark],[-.365,.1,m.steel]])box(w,1.3,1.25,x,2.1,0,material,moving);
  const cavity=[],cores=[],rings=[],formed=[];
  for(let row=0;row<6;row++)for(let col=0;col<4;col++){const y=1.64+row*.185,z=-.405+col*.27;cavity.push([-.331,y,z]);cores.push([-.263,y,z]);rings.push([-.337,y,z]);formed.push([-.29,y,z]);}
  const cavityG=new THREE.CylinderGeometry(.062,.062,.012,24);cavityG.rotateZ(Math.PI/2);instances(cavityG,m.dark,cavity);
  const rimG=new THREE.TorusGeometry(.065,.009,6,20);rimG.rotateY(Math.PI/2);instances(rimG,m.chrome,rings);
  const coreG=new THREE.CylinderGeometry(.029,.023,.2,16);coreG.rotateZ(Math.PI/2);instances(coreG,m.chrome,cores,moving);
  bolts(-.34,[1.52,2.68],[-.52,.52]);bolts(-.3,[1.52,2.68],[-.52,.52],moving);
  for(const y of [1.56,2.64])for(const z of [-.54,.54]){cyl(.055,.38,-.37,y,z,m.brass,moving);cyl(.07,.04,-.35,y,z,m.steel);}
  for(let i=0;i<4;i++){
    cyl(.045,.1,-.14,1.65+i*.29,-.68,m.brass,root,'z');
    tube([[-.14,1.65+i*.29,-.74],[.15,1.6+i*.25,-1.03],[.75,1.12,-1.01],[1.4,1.07,-.95]],.018,i%2?m.red:m.blue);
  }
  // Injection carriage, ribbed servo motor, heater clamps, thermocouple leads and nozzle.
  box(3.3,.2,1.3,2.35,1.16,0,m.navy);for(const x of [1.1,3.45])for(const z of [-.52,.52])box(.38,.15,.23,x,1.31,z,m.steel);
  box(.57,1.2,1.15,3.5,1.94,0,m.ivory);cyl(.3,.6,3.99,2.15,0,m.navy);
  for(let i=0;i<10;i++)cyl(.33,.025,3.72+i*.052,2.15,0,m.dark);
  cyl(.34,.05,4.29,2.15,0,m.steel);bolts(4.32,[1.96,2.34],[-.19,.19]);
  const barrel=cyl(.22,2.45,2,2.15,0,m.steel),transparentBarrel=mat(0x80c3ce,.3,.16,{transparent:true,opacity:.12,depthWrite:false});
  for(let i=0;i<6;i++){
    const x=.95+i*.4;cyl(.255,.2,x,2.15,0,m.heater);cyl(.264,.022,x-.085,2.15,0,m.chrome);cyl(.264,.022,x+.085,2.15,0,m.chrome);
    box(.13,.09,.14,x,2.42,0,m.dark);cyl(.025,.11,x,2.46,.12,m.brass,root,'z');
    tube([[x,2.48,.13],[x+.08,2.58,.38],[x+.1,1.45,.48],[3.3,1.4,.5]],.012);
  }
  cyl(.2,.14,.71,2.15,0,m.steel);cyl(.06,.35,.48,2.15,0,m.chrome,root,'x',.16);
  const screw=new THREE.Group();screw.name='Screw';screw.position.set(2.02,2.15,0);root.add(screw);cyl(.065,2.33,0,0,0,m.chrome,screw);
  const profile=[];for(let i=0;i<=400;i++){const t=i/400;profile.push(new THREE.Vector3(t*2.2-1.1,.148*Math.cos(t*24*Math.PI),.148*Math.sin(t*24*Math.PI)));}
  mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(profile),400,.034,7,false),m.steel,0,0,0,screw);
  // Stainless hopper, throat, rolled rim, lid and loader pipe.
  cyl(.1,.4,3,2.53,0,m.chrome,root,'y');cyl(.39,.52,3,2.95,0,m.steel,root,'y',.11);cyl(.39,.42,3,3.42,0,m.chrome,root,'y');
  cyl(.415,.04,3,3.65,0,m.steel,root,'y');cyl(.36,.08,3,3.71,0,m.ivory,root,'y',.415);cyl(.07,.15,3,3.81,0,m.dark,root,'y');
  tube([[3,3.86,0],[3.32,4.03,0],[3.75,4.01,-.4],[3.87,2.8,-.5]],.055);box(.16,.25,.025,3,3.43,.394,m.glass);
  const pellets=[];for(let i=0;i<8;i++)pellets.push(mesh(geo('pellet',()=>new THREE.SphereGeometry(.035,8,6)),m.pet));
  // Overhead carriage, telescoping vertical mast and independently rotating receiver.
  for(const x of [-2.65,.1])box(.18,4.2,.18,x,3.1,-1.32,m.navy);
  box(3.1,.2,.34,-1.27,TAKEOUT.railY,-1.32,m.blue);
  const bridge=new THREE.Group();root.add(bridge);box(.26,.2,4,0,TAKEOUT.railY,.5,m.blue,bridge);
  for(const z of [-1.4,2.4])box(.33,.27,.17,0,TAKEOUT.railY,z,m.steel,bridge);
  box(.09,.04,3.8,0,TAKEOUT.railY+.13,.5,m.chrome,bridge);
  const carriage=box(.48,.22,.38,0,5.09,0,m.blue);
  const mast=box(.12,1,.14,0,4.6,0,m.chrome,root,0);
  const wrist=box(.24,.24,.28,0,4.2,0,m.blue);
  const robot=new THREE.Group();robot.name='Vertical takeout receiver';root.add(robot);
  box(.1,1.23,1.21,0,0,0,m.dark,robot);
  instances(cavityG,m.brass,formed.map(p=>[-.072,p[1]-2.12,p[2]]),robot);
  const preformG=new THREE.LatheGeometry([new THREE.Vector2(0,0),new THREE.Vector2(.022,.007),new THREE.Vector2(.037,.025),new THREE.Vector2(.04,.17),new THREE.Vector2(.05,.178),new THREE.Vector2(.05,.19),new THREE.Vector2(.037,.196),new THREE.Vector2(.037,.23),new THREE.Vector2(.03,.23),new THREE.Vector2(.03,.195)],20);preformG.rotateZ(-Math.PI/2);
  const preforms=new THREE.Group();preforms.name='Moulded preforms';root.add(preforms);instances(preformG,m.pet,formed,preforms);
  const carried=new THREE.Group();carried.name='Gripped preforms';root.add(carried);
  instances(preformG,m.pet,formed.map(p=>[-.30,p[1]-2.12,p[2]]),carried);
  // Conveyor with extrusion frame, guide rails, drive motor and individual belt ribs.
  box(2.85,.16,1.18,-1.06,1.12,2.32,m.navy);box(2.64,.035,.94,-1.06,1.22,2.32,m.black);
  for(const z of [1.74,2.9]){
    box(2.93,.13,.07,-1.06,1.16,z,m.steel);box(2.7,.045,.045,-1.06,1.42,z,m.chrome);
    for(const x of [-2.18,.07]){box(.09,1.03,.09,x,.61,z,m.steel);box(.2,.05,.2,x,.09,z,m.dark);box(.04,.27,.04,x,1.31,z,m.steel);}
  }
  for(const x of [-2.42,.3])cyl(.11,1.12,x,1.14,2.32,m.chrome,root,'z');cyl(.15,.26,.3,1.12,3.05,m.blue,root,'z');
  const ribs=[];for(let i=0;i<22;i++)ribs.push(box(.012,.012,.89,-2.35+i*.12,1.245,2.32,m.steel,root,0));
  const discharged=new THREE.Group();discharged.name='Conveyor preforms';root.add(discharged);const upright=preformG.clone();upright.rotateZ(Math.PI/2);
  instances(upright,m.pet,Array.from({length:24},(_,i)=>[.48-(i%6)*.185,1.25,1.915+Math.floor(i/6)*.27]),discharged);
  // Framed safety enclosure and motor cover; removable for internal inspection.
  const shell=new THREE.Group();shell.name='Safety enclosure';root.add(shell);
  // Open top access slot for the vertical robot, including when enclosure is shown.
  box(.9,.15,2.25,-2.95,3.35,0,m.ivory,shell);box(.85,.15,2.25,-.025,3.35,0,m.ivory,shell);
  for(const z of [-.94,.94])box(2.05,.15,.37,-1.475,3.35,z,m.ivory,shell);
  box(.15,2.35,2.25,-3.38,2.12,0,m.ivory,shell);box(3.7,2.25,.075,-1.5,2.15,-1.1,m.ivory,shell);
  for(const x of [-3.25,.23])box(.13,2.25,.09,x,2.15,1.105,m.navy,shell);for(const y of [1.08,3.2])box(3.6,.13,.09,-1.51,y,1.105,m.navy,shell);
  box(3.42,1.98,.025,-1.51,2.14,1.105,m.glass,shell,0);box(.06,.43,.08,-3.06,2.12,1.17,m.chrome,shell);label('CLAMPING UNIT',1.3,.12,-1.49,3.25,1.16,shell);
  box(1.19,1.48,1.72,3.72,2.05,0,m.ivory,shell);label('PET 24',.8,.18,3.75,2.56,.868,shell,'#e4e7e5','#263b4a');
  for(let i=0;i<12;i++)box(.015,.4,.018,3.35+i*.06,1.74,.87,m.dark,shell,0);
  // Physical HMI cabinet. Its display is drawn from the same live values as the HUD.
  const hmi=new THREE.Group();hmi.position.set(.94,2.2,1.34);hmi.rotation.y=.18;root.add(hmi);
  box(.72,1.22,.2,0,0,0,m.ivory,hmi);box(.58,.75,.035,0,.13,.118,m.dark,hmi);
  const screen=document.createElement('canvas');screen.width=384;screen.height=480;const sg=screen.getContext('2d');const screenTexture=new THREE.CanvasTexture(screen);screenTexture.colorSpace=THREE.SRGBColorSpace;
  mesh(new THREE.PlaneGeometry(.5,.65),new THREE.MeshBasicMaterial({map:screenTexture}),0,.13,.14,hmi);
  for(let i=0;i<4;i++)cyl(.031,.025,-.22+i*.11,-.35,.13,i===0?m.teal:m.black,hmi,'z');
  cyl(.063,.025,.21,-.48,.13,m.brass,hmi,'z');cyl(.044,.07,.21,-.48,.17,m.red,hmi,'z');box(.065,.3,.055,.26,.01,.155,m.chrome,hmi);
  cyl(.025,.28,.44,3.56,-.75,m.chrome,root,'y');const lamp=mat(0x64ddb6,.1,.25,{emissive:0x247a53,emissiveIntensity:.8});
  for(let i=0;i<3;i++)cyl(.065,.1,.44,3.74+i*.12,-.75,i===0?lamp:i===1?m.brass:m.red,root,'y');

  let internal=true,lastHmi='';
  function setInternal(value){internal=value;barrel.material=internal?transparentBarrel:m.steel;screw.visible=internal;shell.visible=!internal;return internal;}
  setInternal(true);
  function apply(s){
    const opening=Math.max(0,Math.min(1,Number(s.MoldOpen)/500));moving.position.x=-opening*1.55;
    clampRod.scale.y=Math.max(.06,1-opening*.94);clampRod.position.x=-1.67-opening*.71;
    screw.position.x=2.02+(Number(s.ScrewPosition)-120)/120*.55;screw.rotation.x=Number(s.ScrewAngle)*Math.PI/180;
    const takeout=takeoutPose(s);
    bridge.position.x=takeout.x+.16;carriage.position.set(takeout.x+.16,5.09,takeout.z);
    robot.position.set(takeout.x,takeout.y,takeout.z);robot.rotation.z=takeout.angle;
    const wristY=takeout.y+.15;wrist.position.set(takeout.x+.16,wristY,takeout.z);
    mast.scale.y=Math.max(.1,4.98-wristY);mast.position.set(takeout.x+.16,(4.98+wristY)/2,takeout.z);
    preforms.visible=takeout.inMold;preforms.position.set(moving.position.x,0,0);
    carried.visible=takeout.carrying;carried.position.copy(robot.position);carried.rotation.copy(robot.rotation);
    discharged.visible=Number(s.ConveyorProgress)>=0||takeout.released;
    discharged.position.x=takeout.released?-1:-1+Math.max(0,Number(s.ConveyorProgress))*1.3;
    for(let i=0;i<ribs.length;i++)ribs[i].position.x=-2.35+((i*.12+Math.max(0,Number(s.ConveyorProgress))*.72)%2.64);
    m.heater.emissiveIntensity=Math.max(0,Math.min(.6,(Number(s.BarrelTemperature)-25)/440));
    for(let i=0;i<pellets.length;i++){pellets[i].visible=internal&&s.Phase==='Feed';pellets[i].position.set(3+(i%3-1)*.08,3.65-((Number(s.PhaseProgress)*2+i/8)%1)*.7,(i%2-.5)*.12);}
    lamp.color.set(s.Alarm!=='None'?0xed5646:s.RunState==='Running'?0x64ddb6:0xf2c160);
    const stamp=s.Phase+Math.floor(s.SimTime*2);if(stamp!==lastHmi){
      lastHmi=stamp;sg.fillStyle='#0c202c';sg.fillRect(0,0,384,480);sg.fillStyle='#6fddd0';sg.font='bold 31px Segoe UI';sg.fillText('PET / PROCESS',23,47);sg.fillStyle='#e5eeee';sg.font='25px Segoe UI';sg.fillText(s.Phase.toUpperCase(),23,103);
      [['BARREL',s.BarrelTemperature,' C'],['PRESSURE',s.InjectionPressure,' bar'],['SCREW',s.ScrewPosition,' mm'],['TOTAL',s.Produced,' pcs']].forEach(([title,value,unit],i)=>{const y=155+i*72;sg.fillStyle='#7896a8';sg.font='17px Segoe UI';sg.fillText(title,23,y);sg.fillStyle='#e5eeee';sg.font='26px Segoe UI';sg.fillText(Number(value).toFixed(i===3?0:1)+unit,23,y+32);});
      sg.fillStyle='#244752';sg.fillRect(23,451,337,7);sg.fillStyle='#6fddd0';sg.fillRect(23,451,337*Number(s.CycleProgress),7);screenTexture.needsUpdate=true;
    }
    return {mold:moving.position.x,screw:screw.position.x,robot:robot.position.z,conveyor:discharged.position.x,takeout};
  }
  return {root,apply,setInternal};
}
