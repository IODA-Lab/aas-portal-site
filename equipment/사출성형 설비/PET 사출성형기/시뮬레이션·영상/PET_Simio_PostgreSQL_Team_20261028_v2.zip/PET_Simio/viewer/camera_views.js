export const viewpoints={
  overall:{eye:[-8.5,6.4,13],target:[0,2.6,.65]},
  feed:{eye:[5.4,4.8,4.5],target:[3,3.2,0]},
  mold:{eye:[-.1,3.7,4.5],target:[-1.25,2.18,0]},
  injection:{eye:[4.8,3.8,4.7],target:[2.2,2.45,0]},
  robot:{eye:[-5.5,5.1,8],target:[-1.1,3.35,.8]},
  conveyor:{eye:[-5.5,5.1,8.5],target:[-1,3.15,1.6]},
};
const phaseViews={Feed:'feed',Warmup:'injection',Clamp:'mold',Inject:'injection',Hold:'mold',CoolMeter:'injection',Open:'mold',Eject:'robot',Transfer:'conveyor',TakeoutSequence:'conveyor'};
export const viewForPhase=phase=>phaseViews[phase]||'overall';
