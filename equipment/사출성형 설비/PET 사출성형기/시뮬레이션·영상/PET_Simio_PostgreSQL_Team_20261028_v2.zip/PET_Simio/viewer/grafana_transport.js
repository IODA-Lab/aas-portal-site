// Same-origin transport: use the logged-in Grafana session and its existing read-only datasource.
import {numericFields} from './playback.js';
const fields=[...numericFields,'Sequence','Timestamp','Session','Connection','Samples','Phase','RunState','Alarm','Cooling','Metering','Injection','Holding'];
export function currentQuery(runtimeId,uid='aas-infinity',base='http://aas-env:8081'){
  const id=btoa(runtimeId).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  return {refId:'A',datasource:{type:'yesoreyeram-infinity-datasource',uid},type:'json',source:'url',format:'table',parser:'backend',
    url:base.replace(/\/$/,'')+'/submodels/'+id+'/submodel-elements/Current/%24value',url_options:{method:'GET'},
    // Parentheses force JSONata evaluation; a bare [$] can be consumed as a GJSON path.
    root_selector:'($r := $; [$r])',columns:fields.map(k=>({selector:k,text:k,type:'string'})),intervalMs:1000,maxDataPoints:1};
}
export function decodeCurrent(response){
  const result=response.results?.A;
  if(!result||result.error)throw new Error('Grafana AAS 조회 오류'+(result?.error?': '+result.error:''));
  let missing=fields;
  for(const frame of result.frames||[]){
    const data=Object.fromEntries((frame.schema?.fields||[]).map((f,i)=>[f.name,frame.data?.values?.[i]?.[0]]));
    const absent=fields.filter(k=>data[k]===undefined||data[k]===null);
    if(!absent.length)return data;
    if(absent.length<missing.length)missing=absent;
  }
  throw new Error('Grafana Current 필드 누락: '+missing.slice(0,4).join(', ')+(missing.length>4?' 외 '+(missing.length-4)+'개':''));
}
export async function readGrafanaCurrent(runtimeId,uid,base){
  const now=Date.now(),r=await fetch('/api/ds/query',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({from:String(now-60000),to:String(now),queries:[currentQuery(runtimeId,uid,base)]}),signal:AbortSignal.timeout(3500),cache:'no-store'});
  if(!r.ok)throw new Error('Grafana 조회 HTTP '+r.status);
  return decodeCurrent(await r.json());
}
