export const numericFields=['SimTime','PhaseProgress','CycleProgress','BarrelTemperature','MoldTemperature','InjectionPressure','ScrewPosition','MoldOpen','ScrewRPM','ScrewAngle','Takeout','ConveyorProgress','Produced','Good','Reject','CycleTime'];
export function parseState(raw){
  const s={...raw};for(const k of numericFields){s[k]=Number(raw[k]);if(!Number.isFinite(s[k]))throw new Error(`Invalid ${k}`);}
  for(const k of ['Cooling','Metering','Injection','Holding'])s[k]=raw[k]===true||raw[k]==='true';
  if(s.Produced!==s.Good+s.Reject)throw new Error('Counter mismatch');
  return s;
}
export function freshness(s,now=Date.now(),stale=5){
  if(!s)return 'NoData';if(s.Connection!=='ConnectedSimulated')return 'Disconnected';
  const age=now/1000-Number(s.Timestamp);
  return !Number.isFinite(age)||age< -2||age>stale?'Stale':'ConnectedSimulated';
}
export function sampleAt(frames,t){
  if(!frames.length)return null;let lo=0,hi=frames.length-1;
  while(lo<hi){let m=Math.ceil((lo+hi)/2);if(frames[m].SimTime<=t)lo=m;else hi=m-1;}
  const a=frames[lo],b=frames[Math.min(lo+1,frames.length-1)];
  // Never interpolate across phase changes, alarm transitions or sample gaps.
  if(a.Phase!==b.Phase||a.RunState!==b.RunState||b.SimTime-a.SimTime>.16)return {...a};
  let q=Math.min(1,Math.max(0,(t-a.SimTime)/Math.max(.0001,b.SimTime-a.SimTime)));let s={...a};
  for(const k of numericFields.filter(k=>!['Produced','Good','Reject'].includes(k)))s[k]=a[k]+(b[k]-a[k])*q;
  return s;
}
export class Playback{
  constructor(){this.frames=[];this.anchor=0;this.wall=0;this.session='';}
  push(s,now=performance.now()){
    if(this.session!==s.Session){this.frames=[];this.session=s.Session;}
    const rows=JSON.parse(s.Samples||'[]').map(parseState);
    const seen=new Map(this.frames.map(f=>[f.SimTime,f]));for(const r of rows)seen.set(r.SimTime,r);
    this.frames=[...seen.values()].sort((a,b)=>a.SimTime-b.SimTime).slice(-100);
    this.anchor=Number(s.SimTime)-1;this.wall=now;
  }
  state(now=performance.now()){return sampleAt(this.frames,Math.min(this.frames.at(-1)?.SimTime??0,this.anchor+(now-this.wall)/1000));}
}
