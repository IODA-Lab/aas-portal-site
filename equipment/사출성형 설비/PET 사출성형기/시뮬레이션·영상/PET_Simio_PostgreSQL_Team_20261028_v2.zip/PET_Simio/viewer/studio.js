import * as THREE from 'three';

export function setupStudio(scene,renderer){
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  const room=new THREE.Scene();room.background=new THREE.Color(0x5e707e);
  const wall=new THREE.Mesh(new THREE.BoxGeometry(24,14,24),new THREE.MeshBasicMaterial({color:0x798a97,side:THREE.BackSide}));wall.position.y=4;room.add(wall);
  for(const [w,h,x,y,z,intensity] of [[8,5,-5,8,3,5],[3,8,7,5,-3,3],[7,2,0,4,-8,4]]){
    const card=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({color:new THREE.Color().setRGB(intensity,intensity,intensity)}));card.position.set(x,y,z);card.lookAt(0,2,0);room.add(card);
  }
  const pmrem=new THREE.PMREMGenerator(renderer);const env=pmrem.fromScene(room,.04);scene.environment=env.texture;scene.environmentIntensity=.65;
  room.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});pmrem.dispose();
  scene.add(new THREE.HemisphereLight(0xdbeafb,0x273c48,1.4));
  const key=new THREE.DirectionalLight(0xfff1dd,3.4);key.position.set(-3,8,5);key.castShadow=true;key.shadow.mapSize.set(2048,2048);
  Object.assign(key.shadow.camera,{left:-7,right:7,top:7,bottom:-7,near:.5,far:25});key.shadow.bias=-.0002;key.shadow.normalBias=.025;scene.add(key);
  const fill=new THREE.DirectionalLight(0xa8cee8,1.5);fill.position.set(5,4,-4);scene.add(fill);
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(160,160),new THREE.MeshStandardMaterial({color:0x152731,metalness:.2,roughness:.65}));floor.rotation.x=-Math.PI/2;floor.position.y=-.005;floor.receiveShadow=true;scene.add(floor);
  const grid=new THREE.GridHelper(20,40,0x3c5665,0x273e4a);grid.position.y=.001;grid.material.transparent=true;grid.material.opacity=.2;scene.add(grid);
  scene.fog=new THREE.Fog(0x101e28,23,65);
}
