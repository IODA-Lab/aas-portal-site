// Display-only Cartesian path, not a measured robot axis or an AAS control command.
export const TAKEOUT={high:4.2,pick:2.12,drop:1.6,clearX:-1,pickX:-1.54,outZ:2.32,railY:5.25};
const clamp=v=>Math.max(0,Math.min(1,Number(v)||0));
const ramp=(u,a,b)=>{const t=clamp((u-a)/(b-a));return t*t*(3-2*t);};
const mix=(a,b,t)=>a+(b-a)*t;
export function takeoutPose(s){
  const c=TAKEOUT,u=clamp(s.PhaseProgress);
  const p={x:c.clearX,y:c.high,z:c.outZ,angle:0,carrying:false,inMold:['Hold','CoolMeter','Open'].includes(s.Phase),released:false,stage:'상부 대기'};
  if(s.Phase==='Open'){p.z=mix(c.outZ,0,ramp(u,.65,1));p.stage='금형 위로 이동';}
  if(s.Phase==='Eject'){
    if(Number(s.MoldOpen)<490){p.stage='금형 완전 열림 대기';return p;}
    p.z=0;p.y=mix(c.high,c.pick,ramp(u,0,.25));
    p.x=mix(c.clearX,c.pickX,ramp(u,.25,.4));
    p.carrying=u>=.4;p.inMold=!p.carrying;
    if(u>=.55)p.x=mix(c.pickX,c.clearX,ramp(u,.55,.7));
    if(u>=.7)p.y=mix(c.pick,c.high,ramp(u,.7,1));
    p.stage=u<.25?'수직 하강':u<.4?'금형으로 접근':u<.55?'프리폼 잡기':u<.7?'코어에서 인출':'수직 상승';
  }
  if(s.Phase==='Transfer'){
    p.z=mix(0,c.outZ,ramp(u,0,.3));p.carrying=u<.65;
    p.angle=Math.PI/2*ramp(u,.3,.4);p.y=mix(c.high,c.drop,ramp(u,.4,.65));
    if(u>=.65){p.released=true;p.y=mix(c.drop,c.high,ramp(u,.65,.85));}
    if(u>=.85)p.angle=Math.PI/2*(1-ramp(u,.85,1));
    p.stage=u<.3?'상부 횡이동':u<.4?'컨베이어 방향 전환':u<.65?'컨베이어에 내려놓기':u<.85?'놓고 상승':'상부 대기 복귀';
  }
  return p;
}
