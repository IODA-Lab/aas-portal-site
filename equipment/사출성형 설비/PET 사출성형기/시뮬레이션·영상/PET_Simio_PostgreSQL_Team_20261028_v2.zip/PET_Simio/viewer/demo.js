import {sampleAt} from './playback.js';
export class Demo{
  constructor(data){this.data=data;this.time=0;this.speed=1;this.paused=false;}
  step(dt){if(!this.paused)this.time=(this.time+dt*this.speed)%this.data.duration_s;return sampleAt(this.data.frames,this.time);}
  reset(){this.time=0;}
}
