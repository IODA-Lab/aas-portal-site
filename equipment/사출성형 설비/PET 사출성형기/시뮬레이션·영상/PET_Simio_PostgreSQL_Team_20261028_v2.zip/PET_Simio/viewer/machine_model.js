import * as THREE from 'three';
export function buildMachine(scene) {
  const root=new THREE.Group();scene.add(root);
  const mat=(color,extra={})=>new THREE.MeshStandardMaterial({color,roughness:.45,metalness:.35,...extra});
  const steel=mat(0x899eac),dark=mat(0x243b4b),body=mat(0x3e6578),blue=mat(0x5c91ba),copper=mat(0xc88647),cyan=mat(0x6bd8cd),mint=mat(0x99ead3,{transparent:true,opacity:.85});
  function box(w,h,d,x,y,z,m,parent=root){let o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
  function cylinder(r,len,x,y,z,m,parent=root){let o=new THREE.Mesh(new THREE.CylinderGeometry(r,r,len,24),m);o.rotation.z=Math.PI/2;o.position.set(x,y,z);o.castShadow=true;parent.add(o);return o;}
  box(7,.65,2.1,0,.48,0,body);box(7,.12,2.2,0,.85,0,steel);
  for(const x of [-2.8,2.8])for(const z of [-.75,.75])box(.6,.18,.4,x,.1,z,dark);
  box(.5,2.15,1.65,.35,1.9,0,blue);box(.45,2.15,1.65,-2.9,1.9,0,body);
  for(const y of [1.2,2.55])for(const z of [-.63,.63])cylinder(.055,3.3,-1.25,y,z,steel);
  const moving=new THREE.Group();root.add(moving);box(.42,1.95,1.48,-.65,1.9,0,blue,moving);box(.2,1.22,1.15,-.37,1.9,0,steel,moving);
  box(.2,1.22,1.15,.02,1.9,0,steel);
  const toggleA=cylinder(.09,1.65,-1.85,1.9,0,copper);box(.5,.5,.6,-2.7,1.9,0,steel);
  // Transparent barrel permits inspection of the screw; no actual machine geometry claim.
  cylinder(.23,2.55,1.94,1.9,0,mat(0x6bd8cd,{transparent:true,opacity:.18,depthWrite:false}));
  const heater=mat(0xc88647,{emissive:0x6c2004,emissiveIntensity:0});
  for(let i=0;i<5;i++)cylinder(.25,.17,1+i*.45,1.9,0,heater);
  const nozzle=new THREE.Mesh(new THREE.ConeGeometry(.19,.35,24),copper);nozzle.rotation.z=Math.PI/2;nozzle.position.set(.72,1.9,0);root.add(nozzle);
  box(.7,.85,.8,3.05,1.45,0,body);cylinder(.3,.6,3.25,1.9,0,steel);
  const screw=new THREE.Group();screw.position.set(1.95,1.9,0);root.add(screw);cylinder(.07,2.3,0,0,0,steel,screw);
  const points=[];for(let i=0;i<=350;i++){let t=i/350;points.push(new THREE.Vector3(t*2.2-1.1,.16*Math.cos(t*20*Math.PI),.16*Math.sin(t*20*Math.PI)));}
  const helix=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),350,.023,6,false),cyan);screw.add(helix);
  const hopper=new THREE.Mesh(new THREE.CylinderGeometry(.38,.13,.68,24),steel);hopper.position.set(2.75,2.8,0);root.add(hopper);cylinder(.09,.2,2.75,2.3,0,steel);
  box(.76,.08,.76,2.75,3.15,0,dark);box(.12,2.3,.12,-.35,2.1,-1,steel);box(2,.12,.2,-.3,3.25,-.4,copper);
  const pellets=[];
  for(let i=0;i<8;i++){const pellet=new THREE.Mesh(new THREE.SphereGeometry(.045,8,6),mint);root.add(pellet);pellets.push(pellet);}
  const robot=new THREE.Group();root.add(robot);box(.12,.8,.12,-.15,2.7,0,copper,robot);box(.38,.08,.65,-.15,2.28,0,copper,robot);
  const preforms=new THREE.Group();root.add(preforms);
  for(let i=0;i<8;i++){let b=new THREE.Mesh(new THREE.CylinderGeometry(.065,.047,.31,12),mint);b.position.set(0,1.6+(i%4)*.19,-.3+Math.floor(i/4)*.4);b.rotation.z=Math.PI/2;preforms.add(b);}
  const belt=new THREE.Group();root.add(belt);box(2.4,.12,.85,-.2,.93,2.05,dark,belt);for(const x of [-1.2,.8])for(const z of [1.78,2.32])box(.07,.85,.07,x,.47,z,steel,belt);
  const rollers=[];for(let i=0;i<10;i++){let o=box(.035,.015,.78,-1.35+i*.25,1.005,2.05,steel,belt);rollers.push(o);}
  const discharged=new THREE.Group();root.add(discharged);for(let i=0;i<8;i++){let b=new THREE.Mesh(new THREE.CylinderGeometry(.06,.04,.28,10),mint);b.position.set((i%4)*.13,1.17,1.9+Math.floor(i/4)*.23);discharged.add(b);}
  const lamp=mat(0x67e2bb,{emissive:0x28664f});cylinder(.07,.15,-2.9,3.13,-.55,lamp);
  box(.65,.4,.07,2.3,1.1,1.09,mat(0x15232b));
  const gate=mat(0x809fb4,{transparent:true,opacity:.08,depthWrite:false});box(2.8,1.75,.025,-1.3,1.8,.92,gate);
  function apply(s){
    heater.emissiveIntensity=Math.max(0,Math.min(1,(Number(s.BarrelTemperature)-25)/260));
    for(let i=0;i<pellets.length;i++){
      pellets[i].visible=s.Phase==='Feed';
      pellets[i].position.set(2.75+(i%3-1)*.12,3.65-((Number(s.PhaseProgress)*2+i/8)%1)*.55,(i%2-.5)*.15);
    }
    moving.position.x=-Number(s.MoldOpen)/500*1.5;
    toggleA.scale.y=Math.max(.1,1-Number(s.MoldOpen)/500*.65);
    screw.position.x=1.95+(Number(s.ScrewPosition)-120)/120*.55;screw.rotation.x=Number(s.ScrewAngle)*Math.PI/180;
    robot.position.z=Number(s.Takeout)*1.65;robot.position.y=Number(s.Takeout)*.1;
    preforms.visible=['Hold','CoolMeter','Open','Eject','Transfer'].includes(s.Phase);
    preforms.position.set(-.1+moving.position.x,0,s.Phase==='Eject'||s.Phase==='Transfer'?Number(s.Takeout)*1.65:0);
    if(s.Phase==='Transfer')preforms.visible=false;
    discharged.visible=Number(s.ConveyorProgress)>=0;discharged.position.x=-1+Math.max(0,Number(s.ConveyorProgress))*1.8;
    for(let i=0;i<rollers.length;i++)rollers[i].position.x=-1.35+((i*.25+Math.max(0,Number(s.ConveyorProgress))*.7)%2.5);
    lamp.color.set(s.Alarm!=='None'?0xe97c5b:s.RunState==='Running'?0x67e2bb:0xe2c06b);
    helix.material.emissive.set(s.Injection?0x186b65:s.Metering?0x16454a:0x000000);
    return {mold: moving.position.x,screw:screw.position.x,robot:robot.position.z,conveyor:discharged.position.x};
  }
  return {root,apply};
}
