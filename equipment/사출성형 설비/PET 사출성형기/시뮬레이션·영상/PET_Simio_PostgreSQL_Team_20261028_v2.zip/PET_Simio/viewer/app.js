import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {buildMachine} from './machine_detailed.js?v=3.0';
import {viewpoints,viewForPhase} from './camera_views.js?v=3.0';
import {takeoutPose} from './takeout_motion.js?v=3.0';
import {setupStudio} from './studio.js';
import {parseState,Playback} from './playback.js';
import {Demo} from './demo.js';
import {motions,liveStatus} from './phase_ui.js';
import {readGrafanaCurrent} from './grafana_transport.js?v=3.0';
import {PhaseLoop} from './phase_loop.js?v=3.0';
const $=id=>document.getElementById(id),q=new URLSearchParams(location.search),live=q.get('mode')==='live';
const embedded=q.get('embed')==='1';document.body.classList.toggle('embedded',embedded);document.documentElement.classList.toggle('embedded',embedded);
const motion=document.createElement('p');motion.id='motion';$('phase').parentElement.after(motion);
const pose=document.createElement('div');pose.id='pose';$('scene').after(pose);
const overlay=document.createElement('div');overlay.id='live-overlay';overlay.hidden=true;overlay.setAttribute('role','status');$('scene').after(overlay);
let latest=null,demo=null,loop=null,play=new Playback(),healthy=!live,trace=[],lastTrace=-1;
const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(35,1,.05,160);camera.position.set(...viewpoints.overall.eye);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;renderer.setClearColor(0x000000,0);$('scene').append(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(...viewpoints.overall.target);controls.enableDamping=true;controls.maxDistance=24;controls.minDistance=1.6;controls.maxPolarAngle=Math.PI*.49;
setupStudio(scene,renderer);const machine=buildMachine(scene);
new ResizeObserver(()=>{const el=$('scene');camera.aspect=el.clientWidth/el.clientHeight;camera.updateProjectionMatrix();renderer.setSize(el.clientWidth,el.clientHeight);}).observe($('scene'));
let cameraMove=null,internal=true,previousInternal=null;
function setView(name){const v=viewpoints[name]||viewpoints.overall;cameraMove={eye:new THREE.Vector3(...v.eye),target:new THREE.Vector3(...v.target)};$('viewpoint').value=name;}
controls.addEventListener('start',()=>{cameraMove=null;});
$('camera').onclick=()=>setView('overall');$('viewpoint').onchange=e=>setView(e.target.value);
function setInternal(value){internal=value;machine.setInternal(internal);$('cutaway').setAttribute('aria-pressed',String(internal));$('cutaway').textContent=internal?'내부 보기 ON':'외장 보기 ON';}
$('cutaway').onclick=()=>setInternal(!internal);
const publicData=await fetch('../model/public/process_public.json?v=3.0').then(r=>r.json());
const connection=await fetch('../model/public/connection.json').then(r=>r.json()).catch(()=>({}));
const labels={...Object.fromEntries(publicData.steps.map(s=>[s.name,s.label])),TakeoutSequence:'취출 → 컨베이어 인계 연속'};
const replayControls=document.createElement('div');replayControls.className='replay-controls';
replayControls.innerHTML='<button id="return-live" type="button" disabled></button><div class="phase-playback"><label for="phase-speed">반복 속도</label><select id="phase-speed" disabled><option value="0.1">0.1×</option><option value="0.25">0.25×</option><option value="0.5" selected>0.5× · 기본</option><option value="0.75">0.75×</option><option value="1">1×</option><option value="2">2×</option></select><button id="phase-pause" type="button" disabled aria-pressed="false">일시정지</button><button id="phase-restart" type="button" disabled>처음부터</button></div><p id="replay-note" role="status"></p>';
$('steps').before(replayControls);
const sequenceButton=document.createElement('button');sequenceButton.id='takeout-sequence';sequenceButton.type='button';sequenceButton.disabled=true;sequenceButton.setAttribute('aria-pressed','false');sequenceButton.textContent='취출 → 컨베이어 인계 연속 반복';sequenceButton.title='취출부터 컨베이어 인계까지 이어서 반복 · 다시 클릭하면 자동 순서 복귀';replayControls.prepend(sequenceButton);
const normalNote=live?'기본: 실시간 순서 자동 재생 · 단계를 누르면 해당 동작 반복':'기본: 전체 순서 자동 재생 · 단계를 누르면 해당 동작 반복';
$('return-live').textContent=live?'실시간 복귀':'전체 순서 복귀';$('replay-note').textContent='단계별 재생 준비 중…';
function selectPhase(phase){
  if(!loop)return;
  if(loop.phase===phase||phase===null)loop.clear();else loop.select(phase);
  const selected=loop.phase;document.body.classList.toggle('repeat-mode',!!selected);
  setView(viewForPhase(selected));
  if(selected){if(previousInternal===null)previousInternal=internal;setInternal(true);}
  else if(previousInternal!==null){setInternal(previousInternal);previousInternal=null;}
  $('return-live').disabled=!selected;
  sequenceButton.setAttribute('aria-pressed',String(selected==='TakeoutSequence'));
  for(const id of ['phase-speed','phase-pause','phase-restart'])$(id).disabled=!selected;
  $('phase-pause').textContent='일시정지';$('phase-pause').setAttribute('aria-pressed','false');
  $('replay-note').textContent=selected?`${labels[selected]} 반복 · 기록 재생 (실시간 아님). 실시간 시뮬레이션은 계속 진행됩니다.`:normalNote;
  $('mode').textContent=selected?'동작 반복 / 기록 재생':live?'AAS / SIMULATED':'OFFLINE DEMO';
  document.querySelector('.progresslabel span').textContent=selected==='TakeoutSequence'?'취출 → 인계 전체 진행':selected?'선택 동작 진행':'사이클 진행';
  document.querySelectorAll('.step').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.phase===selected)));
  overlay.hidden=!!selected||healthy;trace=[];lastTrace=-1;
}
$('return-live').onclick=()=>selectPhase(null);
sequenceButton.onclick=()=>selectPhase('TakeoutSequence');
$('phase-speed').onchange=e=>loop?.setSpeed(Number(e.target.value));
$('phase-pause').onclick=()=>{if(!loop?.phase)return;loop.togglePause();$('phase-pause').textContent=loop.paused?'재개':'일시정지';$('phase-pause').setAttribute('aria-pressed',String(loop.paused));};
$('phase-restart').onclick=()=>{if(!loop?.phase)return;loop.restart();$('phase-pause').textContent='일시정지';$('phase-pause').setAttribute('aria-pressed','false');};
$('steps').replaceChildren(...publicData.steps.map((s,i)=>{let d=document.createElement('button');d.type='button';d.className='step';d.dataset.phase=s.name;d.disabled=true;d.setAttribute('aria-pressed','false');d.setAttribute('aria-label',s.label+' 반복 재생');d.title='클릭: 이 동작 반복 · 다시 클릭: 자동 순서 복귀';d.innerHTML=`<b>${String(i+1).padStart(2,'0')}</b><span>${s.label}</span><span class="duration">${s.duration_s.toFixed(1)} s ↻</span>`;d.onclick=()=>selectPhase(s.name);return d;}));
const recorded=fetch('../model/public/demo_cycle.json?v=3.0').then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.json();});
recorded.then(data=>{loop=new PhaseLoop(data);sequenceButton.disabled=!loop.has('TakeoutSequence');document.querySelectorAll('.step').forEach(el=>{el.disabled=!loop.clips.has(el.dataset.phase);});$('replay-note').textContent=normalNote;}).catch(()=>{$('replay-note').textContent='단계 기록을 불러오지 못했습니다. 자동 재생은 계속됩니다.';});
function status(text,bad=false){$('connection').textContent=text;$('connection').classList.toggle('bad',bad);}
if(live){
  $('mode').textContent='AAS / SIMULATED';for(const id of ['pause','reset','speed'])$(id).disabled=true;
  const aas=q.get('aas')||connection.aas_url;
  function applyStatus(value){healthy=value.live;document.body.dataset.connection=value.code;status(value.text,!healthy);overlay.hidden=!!loop?.phase||healthy;overlay.textContent=value.text+' · 동작 정지';}
  async function poll(){
    try{
      let endpoint='/api/current';
      if(aas){
        const u=new URL(aas);if(!['https:','http:'].includes(u.protocol)||u.username||u.password||!connection.runtime_id)throw new Error('AAS 주소·트윈 ID 오류');
        const id=btoa(connection.runtime_id).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
        endpoint=aas.replace(/\/$/,'')+`/submodels/${id}/submodel-elements/Current/$value`;
      }
      let raw;
      if(q.get('transport')==='grafana')raw=await readGrafanaCurrent(q.get('runtime')||connection.runtime_id,q.get('datasource')||undefined,q.get('base')||undefined);
      else{const r=await fetch(endpoint,{signal:AbortSignal.timeout(3500),cache:'no-store'});if(!r.ok)throw new Error('AAS HTTP '+r.status);raw=await r.json();}
      latest=parseState(raw);
      if(!Number.isFinite(Number(latest.Sequence))||!Number.isFinite(Number(latest.Timestamp))||typeof latest.Connection!=='string'||!motions[latest.Phase])throw new Error('Current 스키마 오류');
      play.push(latest);applyStatus(liveStatus(latest,Date.now(),publicData.stale_s));
    }catch(e){applyStatus({live:false,code:'query-error',text:'조회 실패 · '+e.message});}
    setTimeout(poll,1000);
  }poll();
}else{
  try{demo=new Demo(await recorded);status('오프라인 · 엔진 기록 재생');}
  catch(e){status('데모 데이터 로드 실패',true);healthy=false;}
  $('pause').onclick=()=>{if(demo){demo.paused=!demo.paused;$('pause').textContent=demo.paused?'재생':'일시정지';}};
  $('reset').onclick=()=>{demo?.reset();trace=[];lastTrace=-1;};$('speed').onchange=e=>{if(demo)demo.speed=Number(e.target.value);};
}
function hud(s){
  motion.textContent=['Eject','Transfer'].includes(s.Phase)?takeoutPose(s).stage:motions[s.Phase]||'공정 단계 확인 필요';
  pose.textContent=`금형 열림 ${s.MoldOpen.toFixed(0)} mm · 스크류 ${s.ScrewPosition.toFixed(1)} mm / ${s.ScrewRPM.toFixed(0)} rpm · 취출 ${(s.Takeout*100).toFixed(0)}%`;
  $('phase').textContent=labels[s.Phase]||s.Phase;$('runstate').textContent={Running:'정상 운전',Alarm:'경보 · 동작 정지',Stopped:'정지',Standby:'대기'}[s.RunState];
  const progress=loop?.phase==='TakeoutSequence'?loop.progress:loop?.phase?s.PhaseProgress:s.CycleProgress;
  $('progress').style.width=progress*100+'%';$('percent').textContent=(progress*100).toFixed(0)+'%';
  if(loop?.phase){
    const state=loop.paused?'일시정지':{playing:'동작 재생',hold:'끝 자세 확인',reset:'다음 반복 준비',start:'시작 자세 확인'}[loop.stage];
    $('runstate').textContent=`${state} · ${loop.speed}× · 기록 재생`;
  }
  document.querySelectorAll('.step').forEach(el=>el.classList.toggle('active',el.dataset.phase===s.Phase));
  for(const [id,k] of [['barrel','BarrelTemperature'],['mold','MoldTemperature'],['pressure','InjectionPressure'],['screw','ScrewPosition'],['cycle','CycleTime']])$(id).textContent=Number(s[k]).toFixed(1);
  $('production').textContent=`${s.Produced} / ${s.Good} / ${s.Reject}`;
  $('alarm').textContent=s.Alarm==='None'?'● 경보 없음 · RUL 추정 미구현':'● '+s.Alarm;$('alarm').classList.toggle('bad',s.Alarm!=='None');
  $('time').textContent=loop?.phase?'단계 동작 예시 · 표시값은 기록된 합성 데이터':`시뮬레이션 ${s.SimTime.toFixed(1)} s`+(live?' · 갱신 '+new Date(Number(latest.Timestamp)*1000).toLocaleTimeString('ko-KR'):' · 실제 서버 미연결');
}
function drawTrace(s){
  if(s.SimTime<lastTrace){trace=[];lastTrace=-1;}
  if(s.SimTime-lastTrace>=.1){trace.push(s);lastTrace=s.SimTime;}trace=trace.filter(p=>p.SimTime>=s.SimTime-30);
  const c=$('trend'),w=c.clientWidth,h=c.clientHeight;c.width=w*devicePixelRatio;c.height=h*devicePixelRatio;const g=c.getContext('2d');g.scale(devicePixelRatio,devicePixelRatio);g.clearRect(0,0,w,h);
  g.strokeStyle='#293c49';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(0,i*h/3);g.lineTo(w,i*h/3);g.stroke();}
  for(const [k,max,color] of [['InjectionPressure',1500,'#6ae0d0'],['ScrewPosition',120,'#eda65e']]){g.beginPath();g.strokeStyle=color;g.lineWidth=1.6;trace.forEach((p,i)=>{let x=w-(s.SimTime-p.SimTime)/30*w,y=h-Number(p[k])/max*(h-8)-4;i?g.lineTo(x,y):g.moveTo(x,y);});g.stroke();}
}
let last=performance.now();function frame(now){let dt=Math.min(.1,(now-last)/1000);last=now;
  if(live&&healthy&&!liveStatus(latest,Date.now(),publicData.stale_s).live){healthy=false;const st=liveStatus(latest,Date.now(),publicData.stale_s);status(st.text,true);document.body.dataset.connection=st.code;overlay.hidden=!!loop?.phase;overlay.textContent=st.text+' · 동작 정지';}
  const automatic=live?(healthy?(play.state(now)||latest):null):demo?.step(dt);
  let s=loop?.phase?loop.step(dt):automatic;
  renderer.domElement.style.opacity=String(loop?.phase&&!loop.paused?loop.opacity:1);
  if(s){machine.apply(s);hud(s);if(!embedded)drawTrace(s);document.body.dataset.phase=s.Phase;document.body.dataset.status=loop?.phase?'phase-repeat':live?'live':'demo';}
  else if(live){for(const id of ['barrel','mold','pressure','screw','cycle','production','percent'])$(id).textContent='—';$('runstate').textContent='실시간 상태 확인 불가';$('phase').textContent='수신 대기 / 동작 정지';$('alarm').textContent='경보 상태 확인 불가';motion.textContent='모델은 마지막 수신 자세에서 정지합니다.';pose.textContent='현재 위치값 확인 불가';$('progress').style.width='0%';document.querySelectorAll('.step.active').forEach(el=>el.classList.remove('active'));document.body.dataset.status='disconnected';}
  if(cameraMove){camera.position.lerp(cameraMove.eye,.12);controls.target.lerp(cameraMove.target,.12);if(camera.position.distanceTo(cameraMove.eye)<.005){camera.position.copy(cameraMove.eye);controls.target.copy(cameraMove.target);cameraMove=null;}}
  controls.update();renderer.render(scene,camera);requestAnimationFrame(frame);
}requestAnimationFrame(frame);
