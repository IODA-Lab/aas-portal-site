import {parseState,sampleAt} from './playback.js';

// Replay a contiguous engine-recorded operation without writing to the live simulator.
export class PhaseLoop {
  constructor(data){
    this.clips=new Map();this.phase=null;this.time=0;this.speed=.5;this.paused=false;
    this.endHold=.4;this.resetDuration=.5;this.startHold=.15;this.stage='playing';this.opacity=1;
    for(let i=0;i<data.frames.length;){
      let end=i+1;while(end<data.frames.length&&data.frames[end].Phase===data.frames[i].Phase)end++;
      const phase=data.frames[i].Phase;
      if(!this.clips.has(phase)){
        const frames=data.frames.slice(i,end).map(parseState),start=frames[0].SimTime;
        const stop=data.frames[end]?.SimTime??data.duration_s;
        this.clips.set(phase,{frames,start,duration:Math.max(.05,stop-start)});
      }
      i=end;
    }
    this.sequences=new Map();
    const eject=this.clips.get('Eject'),transfer=this.clips.get('Transfer');
    if(eject&&transfer&&Math.abs(eject.start+eject.duration-transfer.start)<1e-6){
      this.sequences.set('TakeoutSequence',{start:eject.start,duration:eject.duration+transfer.duration,frames:[...eject.frames,...transfer.frames]});
    }
    this.progress=0;
  }
  has(phase){return this.clips.has(phase)||this.sequences.has(phase);}
  select(phase){if(!this.has(phase))throw new Error('단계 기록 없음: '+phase);this.phase=phase;this.restart();}
  restart(){this.time=0;this.progress=0;this.paused=false;this.stage='playing';this.opacity=1;}
  clear(){this.phase=null;this.restart();}
  setSpeed(speed){if(!Number.isFinite(speed)||speed<.1||speed>2)throw new Error('재생 속도 범위: 0.1–2');this.speed=speed;}
  togglePause(){this.paused=!this.paused;}
  step(dt){
    if(!this.phase)return null;
    const clip=this.clips.get(this.phase)||this.sequences.get(this.phase);
    const duration=clip.duration+this.endHold+this.resetDuration+this.startHold;
    if(!this.paused)this.time=(this.time+Math.max(0,dt)*this.speed)%duration;
    let sampleTime=clip.start+Math.min(this.time,clip.duration),opacity=1;
    this.stage='playing';
    if(this.time>=clip.duration){
      this.stage='hold';
      if(this.time>=clip.duration+this.endHold){
        const resetTime=this.time-clip.duration-this.endHold;
        if(resetTime<this.resetDuration){
          this.stage='reset';const progress=resetTime/this.resetDuration;
          // Hide the positional reset; never depict a reversed operation as measured motion.
          opacity=Math.abs(progress*2-1);opacity=opacity*opacity*(3-2*opacity);
          if(progress>=.5)sampleTime=clip.start;
        }else{this.stage='start';sampleTime=clip.start;}
      }
    }
    this.opacity=opacity;
    this.progress=Math.max(0,Math.min(1,(sampleTime-clip.start)/clip.duration));
    return sampleAt(clip.frames,sampleTime);
  }
}
