export const motions={
  Feed:'호퍼에서 PET 원료 공급 · 초기 준비',
  Warmup:'실린더 가열 · 설정 온도 도달 대기',
  Clamp:'이동 형판 전진 · 금형 닫힘',
  Inject:'스크류 전진 · 용융 PET 사출',
  Hold:'보압 유지 · 수축 보상',
  CoolMeter:'금형 냉각 · 스크류 회전 및 후퇴',
  Open:'이동 형판 후퇴 · 금형 열림',
  Eject:'취출기 이동 · 프리폼 인출',
  Transfer:'컨베이어 이송 · 다음 사이클 준비',
};
export function liveStatus(s,now=Date.now(),stale=5){
  if(!s||Number(s.Sequence)===0)return {code:'waiting',text:'API 정상 · 발행 대기',live:false};
  if(s.Connection!=='ConnectedSimulated')return {code:'stopped',text:'API 정상 · 발행 종료',live:false};
  const age=now/1000-Number(s.Timestamp);
  if(!Number.isFinite(age)||age< -2)return {code:'clock',text:'API 정상 · 시각 오류',live:false};
  if(age>=stale)return {code:'stale',text:'API 정상 · 데이터 지연',live:false};
  return {code:'live',text:'AAS 수신 중 · 합성 데이터',live:true};
}
