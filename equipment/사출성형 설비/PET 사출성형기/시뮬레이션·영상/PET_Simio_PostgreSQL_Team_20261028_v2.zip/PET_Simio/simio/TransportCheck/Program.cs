using PetSimioTelemetry;
using System.Text.Json;

string folder = Path.GetFullPath(args[0]);
Directory.CreateDirectory(folder);
string file = Path.Combine(folder, "atomic-check-" + Guid.NewGuid().ToString("N") + ".json");
if (!AtomicPacket.TryWrite(file, "{\"sequence\":1}")) throw new Exception("initial write failed");
using (var reader = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read))
{
    if (AtomicPacket.TryWrite(file, "{\"sequence\":2}")) throw new Exception("expected Windows sharing conflict");
    using var original = JsonDocument.Parse(File.ReadAllText(file));
    if (original.RootElement.GetProperty("sequence").GetInt32() != 1) throw new Exception("previous packet corrupted");
}
if (!AtomicPacket.TryWrite(file, "{\"sequence\":3}")) throw new Exception("recovery after reader closed failed");
using var latest = JsonDocument.Parse(File.ReadAllText(file));
if (latest.RootElement.GetProperty("sequence").GetInt32() != 3) throw new Exception("recovered packet invalid");
Console.WriteLine("PASS: reader lock does not throw; old JSON stays valid; next tick recovers.");
