import json
from pathlib import Path
from simio_mcp_client import SimioMCP

MODEL = '/Project/Model'
ROOT = Path(__file__).resolve().parents[2]

class API:
    def __init__(self):
        self.client = SimioMCP(timeout=8)

    def call(self, tool, **args):
        result = self.client.call(tool, args)
        text = '\n'.join(x.get('text', '') for x in result.get('content', []))
        if result.get('isError'):
            raise RuntimeError(tool + ': ' + text)
        try:
            value = json.loads(text)
        except ValueError:
            return text
        if isinstance(value, dict) and value.get('error'):
            raise RuntimeError(tool + ': ' + str(value))
        return value

    def prop(self, path, name, value, units=None):
        args = dict(path=path, propertyName=name, value=str(value))
        if units:
            args['units'] = units
        return self.call('set_property', **args)

if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    args = json.loads(Path(sys.argv[2]).read_text(encoding='utf-8')) if len(sys.argv)>2 else {}
    print(json.dumps(API().call(sys.argv[1], **args), ensure_ascii=False, indent=2))
