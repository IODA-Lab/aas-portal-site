"""Build native Simio Assign/Delay/Decide processes. No Python simulation loop."""
from api import *
import xml.etree.ElementTree as E

class Process:
    def __init__(self, name):
        self.name=name
        self.root=E.Element('Process',Name=name,BeginStepID='2',Scope='Public')
        self.steps=[]
        self.container=E.SubElement(self.root,'Steps')
    def step(self,typ,name,**props):
        idx=len(self.steps)+2
        e=E.SubElement(self.container,'Step',Type=typ,Name=name,ID=str(idx))
        ps=E.SubElement(e,'Properties')
        for k,v in props.items():
            p=E.SubElement(ps,'Property',Name=k)
            if k in ('StateVariableName','ProcessName'): E.SubElement(p,'Value').text=str(v)
            else:p.text=str(v)
        self.steps.append([e,None]);return idx
    def assign(self,k,v):return self.step('Assign','Set_'+k+'_'+str(len(self.steps)),StateVariableName=k,NewValue=v)
    def link(self,idx,*targets):self.steps[idx-2][1]=targets
    def xml(self):
        for i,(e,targets) in enumerate(self.steps):
            if targets is None:targets=[i+3] if i<len(self.steps)-1 else []
            for j,t in enumerate(targets):
                E.SubElement(e,'Exit',Name=('True' if j==0 else 'False') if e.attrib['Type']=='Decide' else 'Exit',Type='Primary' if j==0 else 'Alternate',NextID=str(t))
        return E.tostring(self.root,encoding='unicode')

def build():
    a=API()
    status=a.call('get_run_status',modelPath=MODEL)
    print('status',status)
    if status['isInRunMode']:a.call('stop_model',modelPath=MODEL)
    c=json.loads((ROOT/'model/process_scenario.json').read_text(encoding='utf8'))
    r=c['recipe']; d=c['dynamics']; limit=c['limits']
    states={
        'Phase':('String','Feed'), 'RunState':('String','Running'), 'Alarm':('String','None'),
        'TelemetryText':('String',''),
        'PhaseStart':('Real',0), 'PhaseDuration':('Real',1), 'CycleStart':('Real',7),
        'Elapsed':('Real',0), 'PhaseProgress':('Real',0), 'CycleProgress':('Real',0),
        'SmoothProgress':('Real',0), 'MeterProgress':('Real',0), 'PressureTarget':('Real',0),
        'SimTime':('Real',0),'BarrelTemperature':('Real',270),'MoldTemperature':('Real',12),
        'InjectionPressure':('Real',0),'HoldingPressure':('Real',0), 'ClampingForce':('Real',0),
        'MoldOpen':('Real',500),'ScrewPosition':('Real',6),'ScrewRPM':('Real',0),'ScrewAngle':('Real',0),
        'Cooling':('Boolean','False'),'Metering':('Boolean','False'),'Injection':('Boolean','False'),'Holding':('Boolean','False'),
        'Takeout':('Real',0),'ConveyorProgress':('Real',-1),'ConveyorStart':('Real',-100),
        'Cavities':('Integer',24),'CompletedCycles':('Integer',0),'Produced':('Integer',0),'Good':('Integer',0),'Reject':('Integer',0),
        'BatchReject':('Integer',0),'QualityIndex':('Integer',0),'PeakPressure':('Real',0),'BatchBad':('Boolean','False'),
        'CycleTime':('Real',0),'CycleSumSeconds':('Real',0),'RunSeconds':('Real',0),
        'SampleIndex':('Integer',0),'FaultMode':('Integer',0),'FaultActive':('Boolean','False'),
        'InjectionSetpoint':('Real',1200),'HoldingSetpoint':('Real',700),
    }
    existing={x['name'] for x in a.call('list_children',path=MODEL+'/States')['items']}
    for name,(typ,val) in states.items():
        if name not in existing:a.call('create_model_item',path=MODEL+'/States',name=name,type=typ)
        a.prop(MODEL+'/States/'+name,'초기 상태 값',val)
    processes=ROOT/'simio/processes'; processes.mkdir(exist_ok=True)
    def install(p):
        xml=p.xml();(processes/(p.name+'.xml')).write_text(xml,encoding='utf8')
        a.call('set_process_xml',modelPath=MODEL,xml=xml)

    p=Process('PET_Cycle')
    clamp=None
    for phase in c['steps']:
        name=phase['name'];duration=phase['duration_s']
        start=p.assign('Phase','"'+name+'"')
        if name=='Clamp':
            clamp=start;p.assign('CycleStart','TimeNow*3600');p.assign('PeakPressure',0);p.assign('BatchBad','False')
        p.assign('PhaseStart','TimeNow*3600');p.assign('PhaseDuration',duration);p.assign('PhaseProgress',0)
        delay=p.step('Delay','Duration_'+name,DelayTime=str(duration/3600))
        gate=p.step('Decide','Safety_'+name,DecideType='ConditionBased',ConditionOrProbability='Alarm=="None"')
        p.link(gate,gate+1,1)
        # Latch physical endpoints so event ordering at timer boundaries cannot leave a mold gap.
        if name=='Clamp':p.assign('MoldOpen',0)
        if name in ('Warmup','CoolMeter'):p.assign('ScrewPosition',120)
        if name=='Inject':p.assign('ScrewPosition',6)
        if name=='Open':p.assign('MoldOpen',500)
        if name=='Eject':
            p.assign('Takeout',1);p.assign('BatchReject',0);p.assign('QualityIndex',0)
            first=p.assign('BatchReject','BatchReject+Math.If(BatchBad || PeakPressure<900 || Random.Uniform(0,1)<0.01,1,0)')
            p.assign('QualityIndex','QualityIndex+1')
            check=p.step('Decide','CheckAllCavities',DecideType='ConditionBased',ConditionOrProbability='QualityIndex<Cavities')
            count=p.assign('Produced','Produced+Cavities');p.link(check,first,count)
            p.assign('Reject','Reject+BatchReject');p.assign('Good','Good+Cavities-BatchReject')
        if name=='Transfer':
            p.assign('Takeout',0);p.assign('CompletedCycles','CompletedCycles+1')
            p.assign('CycleTime','TimeNow*3600-CycleStart');p.assign('CycleSumSeconds','CycleSumSeconds+CycleTime')
            last=p.assign('ConveyorStart','TimeNow*3600');p.link(last,clamp)
    install(p)

    p=Process('PET_Sample')
    expressions=[
        ('SimTime','TimeNow*3600'),('SampleIndex','SampleIndex+1'),
        ('FaultActive','(FaultMode==1 && SimTime>=17 && SimTime<29) || (FaultMode==2 && SimTime>=9 && SimTime<13) || (FaultMode==3 && SimTime>=10 && SimTime<15) || (FaultMode==4 && SimTime>=10 && SimTime<15)'),
        ('Alarm','Math.If(Alarm!="None",Alarm,Math.If(FaultMode==4 && FaultActive,"SAFETY_INTERLOCK",Math.If(FaultMode==1 && FaultActive && Phase=="CoolMeter","COOLING_FAILURE","None")))'),
        ('RunState','Math.If(Alarm=="None","Running","Alarm")'),
        ('Elapsed','Math.If(RunState=="Running",Math.Max(0,SimTime-PhaseStart),Elapsed)'),
        ('PhaseProgress','Math.Min(1,Elapsed/PhaseDuration)'),
        ('SmoothProgress','PhaseProgress*PhaseProgress*(3-2*PhaseProgress)'),
        ('MeterProgress','Math.Min(1,Elapsed/5)'),
        ('CycleProgress','Math.If(RunState!="Running",CycleProgress,Math.If(SimTime<7,0,Math.Min(1,(SimTime-CycleStart)/27.5)))'),
        ('RunSeconds','RunSeconds+Math.If(RunState=="Running",0.05,0)'),
        ('BarrelTemperature','BarrelTemperature+(Math.If(FaultMode==3 && FaultActive,350,285+Math.If(Phase=="Warmup" || Phase=="CoolMeter",0.7,0))-BarrelTemperature)*(1-Math.Exp(-0.05/2.5))'),
        ('MoldTemperature','MoldTemperature+(12-MoldTemperature)*(1-Math.Exp(-0.05/8))+Math.If(Phase=="Inject" || Phase=="Hold",0.45*0.05,0)'),
        ('MoldOpen','Math.If(Phase=="Clamp",500*(1-SmoothProgress),Math.If(Phase=="Open",500*SmoothProgress,MoldOpen))'),
        ('ScrewPosition','Math.If(Phase=="Warmup",6+114*SmoothProgress,Math.If(Phase=="Inject",120-114*SmoothProgress,Math.If(Phase=="CoolMeter",6+114*MeterProgress*MeterProgress*(3-2*MeterProgress),ScrewPosition)))'),
        ('ScrewRPM','Math.If(Phase=="Warmup" || (Phase=="CoolMeter" && Elapsed<5),120,0)'),
        ('ScrewAngle','ScrewAngle+ScrewRPM*6*0.05'),
        ('PressureTarget','Math.If(RunState!="Running",0,Math.If(Phase=="Inject",Math.If(FaultMode==2 && FaultActive,1875,1200),Math.If(Phase=="Hold",700,0)))'),
        ('InjectionPressure','InjectionPressure+(PressureTarget-InjectionPressure)*(1-Math.Exp(-0.05/Math.If(PressureTarget>0,0.12,0.08)))'),
        ('PeakPressure','Math.If(Phase=="Inject",Math.Max(PeakPressure,InjectionPressure),PeakPressure)'),
        ('HoldingPressure','Math.If(Phase=="Hold",InjectionPressure,0)'),
        ('ClampingForce','Math.If(MoldOpen<0.000001,2500,0)'),
        ('Cooling','Phase=="CoolMeter"'),('Metering','Phase=="CoolMeter" && Elapsed<5'),
        ('Injection','Phase=="Inject"'),('Holding','Phase=="Hold"'),
        ('Takeout','Math.If(Phase=="Eject",SmoothProgress,Math.If(Phase=="Transfer",1-SmoothProgress,Takeout))'),
        ('ConveyorProgress','Math.If(SimTime-ConveyorStart<5,(SimTime-ConveyorStart)/5,-1)'),
        ('BatchBad','BatchBad || MoldTemperature>20'),
        ('Alarm','Math.If(Alarm!="None",Alarm,Math.If(BarrelTemperature>310,"BARREL_OVERHEAT",Math.If(MoldTemperature>35,"MOLD_OVERHEAT",Math.If(InjectionPressure>1500,"OVERPRESSURE",Math.If(PressureTarget>0 && MoldOpen>0.000001,"MOLD_NOT_CLAMPED","None")))))'),
        ('RunState','Math.If(Alarm=="None","Running","Alarm")'),
        ('ScrewRPM','Math.If(RunState=="Running",ScrewRPM,0)'),
        ('InjectionPressure','Math.If(RunState=="Running",InjectionPressure,0)'),
        ('HoldingPressure','Math.If(RunState=="Running",HoldingPressure,0)'),
        ('Cooling','Cooling && RunState=="Running"'),('Metering','Metering && RunState=="Running"'),
        ('Injection','Injection && RunState=="Running"'),('Holding','Holding && RunState=="Running"'),
    ]
    for k,v in expressions:
        if k in ('MoldOpen','ScrewPosition','ScrewRPM','ScrewAngle','Takeout'):
            v='Math.If(RunState=="Running",'+v+','+k+')'
        p.assign(k,v)
    # Native state snapshot consumed by the C# IO-only extension every 50 ms.
    numeric=('SimTime PhaseProgress CycleProgress BarrelTemperature MoldTemperature InjectionPressure InjectionSetpoint HoldingSetpoint HoldingPressure ClampingForce MoldOpen ScrewPosition ScrewRPM ScrewAngle Takeout ConveyorProgress Cavities CompletedCycles Produced Good Reject CycleTime CycleSumSeconds RunSeconds SampleIndex Cooling Metering Injection Holding').split()
    fields=['String.FromReal('+k+',"G17")' for k in numeric]+['Phase','RunState','Alarm']
    p.assign('TelemetryText','+"|"+'.join(fields))
    p.step('0f82677e-fca9-4892-a106-6e43c9f19377','PublishNativeTelemetry')
    p.steps[-1][0].set('ReadableType','PETTelemetry')
    install(p)
    existing={x['name'] for x in a.call('list_children',path=MODEL+'/Elements')['items']}
    for name,offset,interval,maxevents,process in [('CycleClock',0,1,1,'PET_Cycle'),('SampleClock',0.05,0.05,'Infinity','PET_Sample')]:
        if name not in existing:a.call('create_model_item',path=MODEL+'/Elements',type='Timer',name=name)
        path=MODEL+'/Elements/'+name
        a.prop(path,'TimeOffset',offset,'Seconds');a.prop(path,'TimeInterval',interval,'Seconds')
        a.prop(path,'MaximumEvents',maxevents);a.prop(path,'TriggeredProcessName',process)
    a.call('set_run_setup',modelPath=MODEL,settingsJson=json.dumps({'RealTimeClock':False,'RunEndType':'Infinite','FrameInterval':0.1/3600,'CalendarEventsBetweenCallbacksForInteractiveRun':32,'MinCallbacksPerSecond':5}))
    result=a.call('get_diagnostics',modelPath=MODEL)
    (ROOT/'output/simio/build_diagnostics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(result)

if __name__=='__main__':build()
