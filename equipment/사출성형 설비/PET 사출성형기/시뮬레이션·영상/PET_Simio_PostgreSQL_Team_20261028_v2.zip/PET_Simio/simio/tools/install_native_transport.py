"""Install the compiled IO extension step into the stopped native model."""
from api import *
import xml.etree.ElementTree as E

a=API()
if a.call('get_run_status',modelPath=MODEL)['isInRunMode']:
    raise RuntimeError('Stop the model in Simio first')
r=E.fromstring((ROOT/'simio/processes/PET_Sample.xml').read_text(encoding='utf8'))
steps=r.find('Steps')
for old in list(steps):
    if old.attrib.get('Name') in ('PublishNativeStates','FlushTenSamples','ClearTelemetryBatch','PublishNativeTelemetry') or 'TelemetryBatch' in old.attrib.get('Name',''):
        steps.remove(old)
last=steps[-1]
for old in list(last.findall('Exit')):last.remove(old)
idx=int(last.attrib['ID'])+1
E.SubElement(last,'Exit',Name='Exit',Type='Primary',NextID=str(idx))
publish=E.SubElement(steps,'Step',Type='0f82677e-fca9-4892-a106-6e43c9f19377',ReadableType='PETTelemetry',Name='PublishNativeTelemetry',ID=str(idx))
xml=E.tostring(r,encoding='unicode')
print(a.call('set_process_xml',modelPath=MODEL,xml=xml))
(ROOT/'simio/processes/PET_Sample.xml').write_text(xml,encoding='utf8')
print(a.call('get_diagnostics',modelPath=MODEL))
a.call('set_run_setup',modelPath=MODEL,settingsJson=json.dumps({'RealTimeClock':False,'RunEndType':'Infinite','FrameInterval':0.1/3600,'CalendarEventsBetweenCallbacksForInteractiveRun':32,'MinCallbacksPerSecond':5}))
