"""Client for Simio's documented local Desktop Interactive MCP endpoint.

Reference: installed Simio Reference Guide, AI Help in Simio, pp. 2208-2215.
Requires Simio's Project Home > MCP Server toggle enabled by the user/UI.
Only the CLI inventory mode is read-only; `call` performs the named tool.
"""
import argparse
import json
import sys
import urllib.request
from pathlib import Path


class SimioMCP:
    def __init__(self, url="http://localhost:51310", timeout=120):
        self.url = url
        self.timeout = timeout
        self.session = None
        self.counter = 0
        self.rpc("initialize", {
            "protocolVersion": "2025-03-26",
            "capabilities": {},
            "clientInfo": {"name": "codex-simio-workspace", "version": "1.0"},
        })
        self.rpc("notifications/initialized", notification=True)

    def rpc(self, method, params=None, notification=False):
        body = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            body["params"] = params
        if not notification:
            self.counter += 1
            body["id"] = self.counter
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": "2025-03-26",
        }
        if self.session:
            headers["Mcp-Session-Id"] = self.session
        request = urllib.request.Request(self.url, json.dumps(body).encode("utf-8"), headers, method="POST")
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            if response.headers.get("Mcp-Session-Id"):
                self.session = response.headers["Mcp-Session-Id"]
            payload = response.read().decode("utf-8")
        if not payload.strip():
            return None
        if payload.lstrip().startswith("{"):
            result = json.loads(payload)
        else:
            messages = []
            for line in payload.splitlines():
                if line.startswith("data:"):
                    messages.append(json.loads(line[5:].strip()))
            result = next((v for v in messages if v.get("id") == body.get("id")), messages[-1] if messages else {})
        if "error" in result:
            raise RuntimeError(result["error"])
        return result.get("result", result)

    def tools(self):
        result = self.rpc("tools/list")
        return result["tools"]

    def call(self, name, arguments=None):
        return self.rpc("tools/call", {"name": name, "arguments": arguments or {}})


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["inventory", "schema", "call"])
    parser.add_argument("name", nargs="?")
    parser.add_argument("--arguments", help="Path to JSON object containing tool arguments")
    parser.add_argument("--output", help="Write JSON output here instead of stdout")
    args = parser.parse_args()
    client = SimioMCP()
    if args.mode == "inventory":
        result = {"tools": client.tools(), "active_model": client.call("get_active_model")}
    elif args.mode == "schema":
        result = [t for t in client.tools() if args.name is None or args.name in t["name"]]
    else:
        if not args.name:
            parser.error("call requires a tool name")
        arguments = json.loads(Path(args.arguments).read_text(encoding="utf-8")) if args.arguments else {}
        result = client.call(args.name, arguments)
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
        print(args.output)
    else:
        print(rendered)


if __name__ == "__main__":
    main()
