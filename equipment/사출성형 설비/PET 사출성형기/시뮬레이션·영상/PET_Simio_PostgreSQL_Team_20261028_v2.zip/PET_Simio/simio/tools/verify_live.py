"""Read-only end-to-end check of the live native Simio -> BaSyx path."""
import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from aas_core import AasHttp
from aas_equipment import parse_snapshot
from simio_bridge import discover_packet, read_packet
import pet_config as cfg


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seconds', type=float, default=60)
    args = p.parse_args()
    http = AasHttp('http://localhost:8081', timeout=3, retries=1)
    sid = cfg.manifest()['submodels']['TwinRuntime']
    path = discover_packet()
    rows = []
    start = time.monotonic()
    try:
        while True:
            native = read_packet(path)
            current = parse_snapshot(http.get_value(sid, 'Current'))
            age = time.time() - current['Timestamp']
            assert current['Session'] == native['session'], 'AAS is not receiving this Simio session'
            assert current['Connection'] == 'ConnectedSimulated', current['Connection']
            assert -1 <= age < 5, f'AAS stale: {age:.2f}s'
            assert current['Produced'] == current['Good'] + current['Reject']
            assert current['Cavities'] == 24
            poses = json.loads(current['Samples'])
            assert poses and len(poses) <= 40
            row = {k: current[k] for k in ('Session','Sequence','Phase','Produced','Good','Reject','CycleTime','SimTime','Timestamp')}
            row.update(aas_age=round(age,3), native_sim_s=native['samples'][-1]['SimTime'], native_index=native['samples'][-1]['SampleIndex'])
            if rows:
                assert row['Sequence'] > rows[-1]['Sequence'], 'AAS sequence stopped'
                assert row['Produced'] >= rows[-1]['Produced'], 'production counter decreased'
            rows.append(row)
            print(json.dumps(row), flush=True)
            if time.monotonic() - start >= args.seconds:
                break
            time.sleep(3)
        assert len({r['Phase'] for r in rows}) >= 3, 'not enough process phases observed'
        assert rows[-1]['Produced'] > rows[0]['Produced'], 'no completed production observed'
        assert abs(rows[-1]['CycleTime'] - 27.5) < .001
        history = http.get_value(sid, 'History')
        assert any(r.get('Session') == rows[-1]['Session'] for r in history.values()), 'Simio history missing'
        report = {'passed':True,'engine':'Simio','transport':'SimioNativeDotNet','duration_s':time.monotonic()-start,'rows':rows}
        output=ROOT/'output/simio/live_verification.json'
        output.parent.mkdir(parents=True,exist_ok=True)
        output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        print('PASS: native Simio, live AAS values, counts, 27.5s cycle and history')
    finally:
        http.close()


if __name__ == '__main__':
    main()
