"""Exercise actual Simio runs; must be used only on the PET migration model."""
from api import *
import time

a=API()
def wait_end(timeout=90):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        status=a.call('get_run_status',modelPath=MODEL)
        if status.get('lastError'):raise RuntimeError(status['lastError'])
        if status['isInRunMode'] and not status['canGo'] and not status['running']:return
        time.sleep(0.5)
    raise TimeoutError('Simio validation run did not finish')

def value(expr):return a.call('evaluate_runtime_expression',modelPath=MODEL,expression=expr)['result']['value']

wait_end()
results=[]
for fault,expected in [(0,'None'),(1,'COOLING_FAILURE'),(2,'OVERPRESSURE'),(3,'BARREL_OVERHEAT'),(4,'SAFETY_INTERLOCK')]:
    if fault:
        a.call('stop_model',modelPath=MODEL)
        a.prop(MODEL+'/States/FaultMode','초기 상태 값',fault)
        a.call('set_run_setup',modelPath=MODEL,settingsJson=json.dumps({'RealTimeClock':False,'RunEndType':'RunLength','EndTimeValue':35/3600,'EndTimeUnitSubType':0}))
        a.call('fast_forward_model',modelPath=MODEL);time.sleep(0.2);wait_end()
    row={k:value(k) for k in ['TimeNow','Phase','Produced','Good','Reject','CompletedCycles','CycleTime','Alarm','RunState','SampleIndex']}
    assert row['Alarm']==expected,row
    assert row['Produced']==row['Good']+row['Reject'],row
    if fault:assert row['Produced']==0 and row['RunState']=='Alarm',row
    else:assert row['Produced']==72 and row['CompletedCycles']==3 and abs(row['CycleTime']-27.5)<1e-7,row
    results.append({'fault_mode':fault,**row});print(results[-1],flush=True)
a.call('stop_model',modelPath=MODEL)
a.prop(MODEL+'/States/FaultMode','초기 상태 값',0)
a.call('set_run_setup',modelPath=MODEL,settingsJson=json.dumps({'RealTimeClock':False,'RunEndType':'Infinite'}))
(ROOT/'output/simio/native_validation.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
print('Native normal/fault runs validated; model restored to realtime normal mode.')
