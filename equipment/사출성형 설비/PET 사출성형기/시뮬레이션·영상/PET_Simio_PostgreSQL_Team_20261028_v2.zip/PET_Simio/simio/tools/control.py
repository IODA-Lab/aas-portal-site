"""Check native output; optionally control the PET model through local MCP."""
from api import *
import argparse
import sys
sys.path.insert(0,str(ROOT))
from simio_bridge import discover_packet, read_packet

p=argparse.ArgumentParser()
p.add_argument('action',choices=['start','pause','stop','status'])
args=p.parse_args()
if args.action in ('status','start'):
    try:
        path=discover_packet()
        packet=read_packet(path)
    except (ValueError,OSError,KeyError):
        if args.action=='status':
            print('No fresh native Simio output. Open the PET model and press Shift+F6.');sys.exit(1)
    else:
        print(json.dumps({'engine':'Simio','session':packet['session'],'phase':packet['samples'][-1]['Phase'],'packet':str(path)}));sys.exit(0)
a=API()
a.client.timeout=8
processes={x['name'] for x in a.call('list_children',path=MODEL+'/Processes')['items']}
if not {'PET_Cycle','PET_Sample'}<=processes:
    raise RuntimeError('Open simio/PET_24Cavity_27_5s.spfx in Simio first. The active model was not modified.')
status=a.call('get_run_status',modelPath=MODEL)
if args.action=='status':print(json.dumps(status,ensure_ascii=False,indent=2))
elif args.action=='stop':
    if status['isInRunMode']:print(a.call('stop_model',modelPath=MODEL))
elif args.action=='pause':
    if status['running']:print(a.call('pause_model',modelPath=MODEL))
else:
    if a.call('get_diagnostics',modelPath=MODEL)['errorCount']:
        raise RuntimeError('Simio model has errors; correct them before starting')
    if not status['isInRunMode']:
        a.prop(MODEL+'/States/FaultMode','초기 상태 값',0)
        a.call('set_run_setup',modelPath=MODEL,settingsJson=json.dumps({'RealTimeClock':False,'RunEndType':'Infinite'}))
    if not status['running']:print(a.call('fast_forward_model',modelPath=MODEL))
    else:print('Simio already running')
