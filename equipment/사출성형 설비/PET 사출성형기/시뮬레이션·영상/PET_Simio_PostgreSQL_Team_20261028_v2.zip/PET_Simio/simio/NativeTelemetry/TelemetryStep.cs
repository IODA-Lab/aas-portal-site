using System.Diagnostics;
using System.Globalization;
using System.Text.Json;
using SimioAPI;
using SimioAPI.Extensions;

namespace PetSimioTelemetry;

// IO only. All process states are calculated by the model's native processes.
public sealed class TelemetryDefinition : IStepDefinition
{
    public string Name => "PETTelemetry";
    public string Description => "Publish native PET states at wall-clock 1x without a Python script host.";
    public System.Drawing.Image Icon => null!;
    public Guid UniqueID => new("0f82677e-fca9-4892-a106-6e43c9f19377");
    public int NumberOfExits => 1;
    public void DefineSchema(IPropertyDefinitions schema) { }
    public IStep CreateStep(IPropertyReaders properties) => new TelemetryStep();
}

public sealed class TelemetryStep : IStep
{
    private static readonly string[] Numeric = ("SimTime PhaseProgress CycleProgress BarrelTemperature MoldTemperature " +
        "InjectionPressure InjectionSetpoint HoldingSetpoint HoldingPressure ClampingForce MoldOpen ScrewPosition ScrewRPM " +
        "ScrewAngle Takeout ConveyorProgress Cavities CompletedCycles Produced Good Reject CycleTime CycleSumSeconds RunSeconds SampleIndex").Split(' ');
    private static readonly string[] Booleans = "Cooling Metering Injection Holding".Split(' ');
    private static readonly string[] Strings = "Phase RunState Alarm".Split(' ');
    private readonly Queue<Dictionary<string, object>> samples = new();
    private string session = "";
    private string file = "";
    private double lastTime = -1, sim0;
    private Stopwatch clock = new();

    public ExitType Execute(IStepExecutionContext context)
    {
        string text = ((IStringState)context.AssociatedObject.States["TelemetryText"]).Value;
        string[] values = text.Split('|');
        if (values.Length != Numeric.Length + Booleans.Length + Strings.Length)
            throw new InvalidDataException("Native PET telemetry field count mismatch");
        var sample = new Dictionary<string, object>();
        int index = 0;
        foreach (string name in Numeric) sample[name] = double.Parse(values[index++], CultureInfo.InvariantCulture);
        foreach (string name in Booleans) sample[name] = double.Parse(values[index++], CultureInfo.InvariantCulture) != 0;
        foreach (string name in Strings) sample[name] = values[index++];
        double sim = (double)sample["SimTime"];
        if (session == "" || sim <= lastTime)
        {
            session = "simio-" + Guid.NewGuid().ToString("N");
            string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PETSimio", "Live");
            Directory.CreateDirectory(folder);
            file = Path.Combine(folder, "pet_live_" + session + ".json");
            samples.Clear(); sim0 = sim; clock.Restart();
        }
        // Only throttle delivery; never calculate or advance simulation state.
        double wait = sim - sim0 - clock.Elapsed.TotalSeconds;
        if (wait > 0) Thread.Sleep(TimeSpan.FromSeconds(wait));
        else if (wait < -1) { sim0 = sim; clock.Restart(); }
        lastTime = sim;
        sample["SchemaVersion"] = "1.0.0";
        sample["DataSource"] = "Simulated";
        sample["Assumption"] = "SimulationAssumption";
        samples.Enqueue(sample);
        while (samples.Count > 40) samples.Dequeue();
        var packet = new { engine = "Simio", model = "PET_24Cavity_27_5s", session,
            transport_version = 5, transport = "SimioNativeDotNet", written_at = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0,
            samples = samples.ToArray() };
        // Windows can report a reader/antivirus replacement collision as either
        // IOException or UnauthorizedAccessException. IO must not abort the
        // Simio process: the next tick retries the whole rolling window. A
        // persistent failure leaves written_at stale, which the bridge rejects.
        AtomicPacket.TryWrite(file, JsonSerializer.Serialize(packet));
        return ExitType.FirstExit;
    }
}
