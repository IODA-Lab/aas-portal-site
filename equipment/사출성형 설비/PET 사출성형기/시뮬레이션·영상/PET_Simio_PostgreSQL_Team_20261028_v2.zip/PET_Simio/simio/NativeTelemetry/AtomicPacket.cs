namespace PetSimioTelemetry;

public static class AtomicPacket
{
    public static bool TryWrite(string file, string json)
    {
        try
        {
            File.WriteAllText(file + ".tmp", json);
            File.Move(file + ".tmp", file, true);
            return true;
        }
        catch (IOException) { return false; }
        catch (UnauthorizedAccessException) { return false; }
    }
}
