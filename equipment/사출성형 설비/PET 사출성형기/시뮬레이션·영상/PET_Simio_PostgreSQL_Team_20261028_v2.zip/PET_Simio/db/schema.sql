CREATE SCHEMA IF NOT EXISTS pet_twin;
CREATE TABLE IF NOT EXISTS pet_twin.telemetry (
  equipment_id text NOT NULL,
  source_session text NOT NULL,
  sample_index bigint NOT NULL,
  observed_at timestamptz NOT NULL,
  stored_at timestamptz NOT NULL DEFAULT now(),
  aas_sequence bigint NOT NULL,
  cycle_number bigint NOT NULL,
  phase text NOT NULL,
  produced bigint NOT NULL,
  good bigint NOT NULL,
  reject bigint NOT NULL,
  barrel_temperature_c double precision NOT NULL,
  mold_temperature_c double precision NOT NULL,
  injection_pressure_bar double precision NOT NULL,
  screw_position_mm double precision NOT NULL,
  payload jsonb NOT NULL,
  PRIMARY KEY (equipment_id,source_session,sample_index),
  CHECK (produced=good+reject)
);
CREATE INDEX IF NOT EXISTS telemetry_observed_idx ON pet_twin.telemetry(equipment_id,observed_at DESC);
CREATE TABLE IF NOT EXISTS pet_twin.cycles (
  equipment_id text NOT NULL,
  source_session text NOT NULL,
  cycle_number bigint NOT NULL,
  sample_index bigint NOT NULL,
  completed_at timestamptz NOT NULL,
  stored_at timestamptz NOT NULL DEFAULT now(),
  source_sim_seconds double precision NOT NULL,
  cycle_time_seconds double precision NOT NULL CHECK (cycle_time_seconds>0),
  batch_produced integer,
  batch_good integer,
  batch_reject integer,
  observed_full_cycle boolean NOT NULL,
  aas_completed_cycles bigint NOT NULL,
  aas_produced bigint NOT NULL,
  payload jsonb NOT NULL,
  PRIMARY KEY (equipment_id,source_session,cycle_number),
  CHECK (batch_produced=batch_good+batch_reject)
);
CREATE INDEX IF NOT EXISTS cycles_completed_idx ON pet_twin.cycles(equipment_id,completed_at DESC);
