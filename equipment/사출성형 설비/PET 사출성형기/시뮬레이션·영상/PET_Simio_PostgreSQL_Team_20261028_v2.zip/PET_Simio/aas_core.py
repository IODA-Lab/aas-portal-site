"""Shared REST/serialization primitives reused from the supplied common core.
See docs/reuse_manifest.json for exact origin. PET-specific async policy lives in aas_equipment.py.
"""
import base64, datetime as dt, http.client, json, math, os, re, threading, time, urllib.parse
KST = dt.timezone(dt.timedelta(hours=9))
INT_TYPES = frozenset(('xs:integer','xs:int','xs:long','xs:short','xs:byte','xs:nonNegativeInteger','xs:positiveInteger','xs:unsignedLong','xs:unsignedInt','xs:unsignedShort','xs:unsignedByte'))
_DUR_RE = re.compile(r'^(-)?P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$')
def b64(identifier):
    """AAS V3 API 경로 인코딩: base64url(패딩 제거)."""
    return base64.urlsafe_b64encode(identifier.encode("utf-8")).decode("ascii").rstrip("=")

def iso_ms(epoch_ms):
    """epoch ms → ISO8601(+09:00, ms 3자리). 예 2026-10-08T14:00:01.000+09:00"""
    return dt.datetime.fromtimestamp(epoch_ms / 1000.0, KST).isoformat(timespec="milliseconds")

def now_iso():
    return iso_ms(time.time() * 1000.0)

def parse_iso_ms(s):
    """ISO8601 → epoch ms (실패 시 None, 시간대 없으면 +09:00)."""
    try:
        d = dt.datetime.fromisoformat(str(s).strip().replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=KST)
    return int(round(d.timestamp() * 1000))

def iso_duration(seconds):
    """초 → xs:duration 문자열. 정수 초면 'PT43S', 아니면 'PT1.5S'."""
    s = max(0.0, float(seconds))
    if abs(s - round(s)) < 1e-6:
        return "PT%dS" % int(round(s))
    return ("PT%.3f" % s).rstrip("0").rstrip(".") + "S"

def parse_duration_s(s):
    """xs:duration('PT25.8S', 'PT1H2M3S', 'P1DT2H') → 초. 연·월은 쓰지 않는다. 형식이 다르면 None."""
    m = _DUR_RE.match(str(s or "").strip())
    if not m or not any(m.group(i) for i in range(2, 6)):
        return None
    d, h, mi, se = (float(m.group(i) or 0) for i in range(2, 6))
    v = d * 86400 + h * 3600 + mi * 60 + se
    return -v if m.group(1) else v

def ref(sem):
    """semanticId 참조(ExternalReference/GlobalReference)."""
    return {"type": "ExternalReference", "keys": [{"type": "GlobalReference", "value": sem}]}

def _s(v):
    """BaSyx $value 문자열화: 숫자도 "-60.0" 형태(숫자로 보내면 500, T1), bool 은 소문자, None 은 ""."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)

def fmt(v, vtype=None, nd=None):
    """값 하나 → $value 문자열(계약 §5).
    - valueType 이 정수형(xs:integer·int·long …)이면 str(int(round(v))) — 소수점 금지(T2)
    - nd(자릿수)가 있으면 str(round(float(v), nd)) (예 7020.0 → '7020.0', 2.0213 → '2.021')
    - bool → 'true'/'false', None → ''. 유한하지 않은 수(NaN·Inf)는 ValueError(호출 쪽이 직전 값을 쓴다)"""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        f = float(v)
        if not math.isfinite(f):
            raise ValueError("유한하지 않은 값은 쓰지 않는다(NaN·Inf)")
        if vtype in INT_TYPES:
            return str(int(round(f)))
        if nd is not None:
            return str(round(f, nd))
        return str(v)
    if isinstance(v, str) and vtype in INT_TYPES:
        try:
            return str(int(round(float(v))))
        except ValueError:
            return v
    return str(v)

def parse_value(s, vtype):
    """$value 문자열 → 파이썬 값(정수형 int, xs:double·float·decimal float, xs:boolean bool, 그 밖 str). 실패 시 None.
    AASX 의 '<value/>' 는 BaSyx 에서 null 로 읽힐 수 있으므로(WP2 실측 T10) None 도 받는다."""
    if s is None:
        return None
    try:
        if vtype in INT_TYPES:
            return int(round(float(s)))
        if vtype in ("xs:double", "xs:float", "xs:decimal"):
            f = float(s)
            return f if math.isfinite(f) else None
        if vtype == "xs:boolean":
            t = str(s).strip().lower()
            return True if t == "true" else False if t == "false" else None
    except (TypeError, ValueError):
        return None
    return str(s)

def value_body(v):
    """$value PATCH 본문. dict(SMC) 는 하위까지 문자열화, tuple(min, max) 은 Range(BaSyx 는 정수만 — T5),
    list 는 MLP([{lang: text}])·SML 값 배열(항목마다 같은 규칙)."""
    if isinstance(v, dict):
        return {k: value_body(x) for k, x in v.items()}
    if isinstance(v, tuple):
        return {"min": int(round(v[0])), "max": int(round(v[1]))}
    if isinstance(v, list):
        return [value_body(x) for x in v]
    return _s(v)

def range_body(lo, hi):
    """신뢰구간 같은 Range 본문: lo = ⌊lo⌋, hi = ⌈hi⌉ 정수(소수 JSON 숫자는 BaSyx 가 0 쪽으로 자르므로 직접 만든다 — T5′)."""
    return {"min": int(math.floor(float(lo))), "max": int(math.ceil(float(hi)))}

def mlp(texts):
    """{'ko': …, 'en': …} 또는 [(lang, text)…] → MLP ValueOnly 리스트 [{'ko': …}, {'en': …}] (dict·문자열은 500, T6)."""
    items = texts.items() if isinstance(texts, dict) else texts
    return [{k: str(t)} for k, t in items]

def encode_path(path):
    """URL 경로(쿼리 포함) 인코딩. '[', ']' 는 %5B %5D 로 바뀐다(실측 T7: 날 대괄호는 Tomcat 400).
    tests/fake_aas.encode_path(idShortPath 조각 기준 함수)와 같은 규칙에 '/'·쿼리 문자만 더 살린다."""
    return urllib.parse.quote(path, safe="/$.=?&-_~")

def prop(id_short, value, vtype="xs:string", sem=None):
    p = {"modelType": "Property", "idShort": id_short, "valueType": vtype, "value": _s(value)}
    if sem:
        p["semanticId"] = ref(sem) if isinstance(sem, str) else sem
    return p

def smc(id_short, items, sem=None, desc=None):
    c = {"modelType": "SubmodelElementCollection", "idShort": id_short, "value": list(items)}
    if sem:
        c["semanticId"] = ref(sem) if isinstance(sem, str) else sem
    if desc:
        c["description"] = [{"language": k, "text": v} for k, v in desc.items()]
    return c

def mlp_element(id_short, value, sem=None):
    """MLP 요소(value = ValueOnly 리스트 [{'ko': …}, …] 또는 dict)."""
    items = value if isinstance(value, list) else mlp(value or {})
    e = {"modelType": "MultiLanguageProperty", "idShort": id_short,
         "value": [{"language": k, "text": t} for x in items for k, t in x.items()]}
    if sem:
        e["semanticId"] = ref(sem) if isinstance(sem, str) else sem
    return e

def element_value(el):
    """요소 JSON(GET …/{path}, $value 아님) → ValueOnly 와 같은 모양. $value GET 과 달리 소수 Range(T5)·중복 idShort 에서도
    실패하지 않는다(Range 는 {'min': 문자열, 'max': 문자열}, 같은 idShort 는 뒤의 것)."""
    if not isinstance(el, dict):
        return None
    mt = el.get("modelType")
    if mt == "Property":
        return el.get("value")
    if mt == "MultiLanguageProperty":
        return [{x.get("language"): x.get("text")} for x in el.get("value") or []]
    if mt == "Range":
        return {"min": el.get("min"), "max": el.get("max")}
    if mt == "SubmodelElementCollection":
        return {c.get("idShort"): element_value(c) for c in el.get("value") or [] if isinstance(c, dict)}
    if mt == "SubmodelElementList":
        return [element_value(c) for c in el.get("value") or []]
    if mt == "Entity":
        return {"statements": [{c.get("idShort"): element_value(c)} for c in el.get("statements") or []],
                "entityType": el.get("entityType"), "specificAssetIds": el.get("specificAssetIds") or []}
    if mt in ("File", "Blob"):
        return {"contentType": el.get("contentType"), "value": el.get("value")}
    return el.get("value")

def shape(el):
    """요소 구조 비교용: SMC 는 {idShort: 하위 구조}, 그 외는 modelType(값·순서 무관)."""
    if el.get("modelType") == "SubmodelElementCollection":
        return {c.get("idShort"): shape(c) for c in el.get("value") or []}
    return el.get("modelType")

def path_tokens(path):
    """'A.B[0].C' → ['A', 'B', 0, 'C']"""
    out = []
    for part in (path or "").split("."):
        m = re.match(r"^([^\[\]]*)((?:\[\d+\])*)$", part)
        if not m:
            raise ValueError("idShortPath 형식 오류: " + path)
        if m.group(1):
            out.append(m.group(1))
        out += [int(i) for i in re.findall(r"\[(\d+)\]", m.group(2))]
    return out

class AasError(RuntimeError):
    """HTTP 응답 오류(서버가 응답은 함)."""
    def __init__(self, method, path, status, text, token_env="PET_AAS_TOKEN"):
        hint = f" (쓰기 인증 실패: {token_env} 확인)" if status in (401, 403) else ""
        super().__init__(f"{method} {path} -> {status} {text[:200]!r}{hint}")
        self.status = status

class AasUnavailable(ConnectionError):
    """연결 불가·타임아웃·연결 끊김(네트워크/서버 다운) — 결과 불명. 재시도 대상(POST·전체 PATCH 는 재시도하지 않음)."""

class _OneSeg:
    """http.client 는 헤더와 본문을 따로 send → Nagle×지연ACK 로 PATCH 1건 ~50 ms(Docker 포트 프록시·원격 모두).
    헤더+본문을 한 세그먼트로 보내면 왕복 1회(RTT)로 끝남(FPD 실측)."""
    def _send_output(self, message_body=None, encode_chunked=False):
        self._buffer.extend((b"", b""))
        msg = b"\r\n".join(self._buffer)
        del self._buffer[:]
        self.send(msg + (message_body or b""))

class _Conn(_OneSeg, http.client.HTTPConnection):
    pass

class _ConnS(_OneSeg, http.client.HTTPSConnection):
    pass

class AasHttp:
    """BaSyx AAS Environment REST 최소 클라이언트(연결 1개, 스레드 안전: 호출마다 잠금). path 는 idShortPath.

    request() 는 연결 오류(거부·타임아웃·끊김)를 retries 번까지 재시도: 재사용하던 keep-alive 연결이 끊긴 첫 실패는
    즉시 새 연결로, 그 뒤는 지수 백오프(backoff·2^k, 최대 backoff_max). 끝내 실패하면 AasUnavailable.
    https:// 주소는 HTTPSConnection(인증서·호스트명 검증 기본, ssl_context 로 바꿀 수 있음).
    token: 쓰기 인증 토큰(None → 환경변수 token_env, '' → 없음). 있으면 모든 요청에 Authorization: Bearer 헤더.
           토큰 값은 속성·로그·예외에 남기지 않는다(auth 는 있음/없음만)."""

    TOKEN_ENV = "PET_AAS_TOKEN"
    DEFAULT_TIMEOUT = 5.0

    def __init__(self, base_url, timeout=None, retries=2, backoff=0.25, backoff_max=4.0, stop_event=None,
                 token=None, ssl_context=None, token_env=None):
        u = urllib.parse.urlsplit(base_url.rstrip("/"))
        if u.scheme not in ("http", "https") or not u.hostname:
            raise ValueError(f"AAS 주소 형식 오류: {base_url!r} (예: http://192.168.0.10:8081)")
        self.base_url = base_url.rstrip("/")
        self.https = u.scheme == "https"
        self.token_env = token_env or self.TOKEN_ENV
        tok = (os.environ.get(self.token_env, "") if token is None else token).strip()
        self._auth = {"Authorization": "Bearer " + tok} if tok else {}
        self.auth = bool(tok)
        self._ssl = ssl_context
        self.host, self.port, self.prefix = u.hostname, u.port or (443 if self.https else 80), u.path
        self.timeout = self.DEFAULT_TIMEOUT if timeout is None else timeout
        self.retries, self.backoff, self.backoff_max = retries, backoff, backoff_max
        self._stop = stop_event
        self._conn, self._lk = None, threading.Lock()
        self.n_req = self.n_retry = self.n_conn_err = 0
        self.ms_last = self.ms_sum = self.ms_max = 0.0
        self.bytes_out = 0
        self.last_used = 0.0

    def close(self):
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    def _sleep(self, s):
        if self._stop is not None:
            self._stop.wait(s)
        else:
            time.sleep(s)

    def _conn_cls(self):
        return _ConnS if self.https else _Conn

    def _new_conn(self):
        cls = self._conn_cls()
        if self.https:
            return cls(self.host, self.port, timeout=self.timeout, context=self._ssl)
        return cls(self.host, self.port, timeout=self.timeout)

    def request(self, method, path, body=None, retries=None):
        """→ (status, bytes). 연결 오류는 재시도 후 AasUnavailable. path 는 '/submodels/…' (encode_path 로 인코딩)."""
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        hdr = {"Content-Type": "application/json"} if data is not None else {}
        hdr.update(self._auth)
        url = self.prefix + encode_path(path)
        n = self.retries if retries is None else retries
        with self._lk:
            for attempt in range(n + 1):
                reused = self._conn is not None
                try:
                    if self._conn is None:
                        self._conn = self._new_conn()
                    t0 = time.perf_counter()
                    self._conn.request(method, url, data, hdr)
                    r = self._conn.getresponse()
                    raw = r.read()
                    if r.will_close:
                        self.close()
                    self.ms_last = (time.perf_counter() - t0) * 1000.0
                    self.ms_sum += self.ms_last
                    self.ms_max = max(self.ms_max, self.ms_last)
                    self.n_req += 1
                    self.bytes_out += len(data or b"")
                    self.last_used = time.monotonic()
                    return r.status, raw
                except (OSError, http.client.HTTPException) as e:
                    self.close()
                    self.n_conn_err += 1
                    self.last_used = time.monotonic()
                    if attempt >= n or (self._stop is not None and self._stop.is_set()):
                        raise AasUnavailable(f"{method} {path}: {e!r}") from e
                    self.n_retry += 1
                    if not (reused and attempt == 0):          # 오래된 keep-alive 끊김은 즉시 재연결
                        self._sleep(min(self.backoff_max, self.backoff * (2 ** attempt)))

    @staticmethod
    def el(sm_id, path=None):
        base = f"/submodels/{b64(sm_id)}/submodel-elements"
        return f"{base}/{path}" if path else base

    def _json(self, method, path, body=None, ok_404=False, retries=None):
        st, raw = self.request(method, path, body, retries)
        if st == 404 and ok_404:
            return None
        if st >= 300:
            raise AasError(method, path, st, raw.decode("utf-8", "replace"), self.token_env)
        if not raw or not raw.strip():
            return None
        try:                                    # JSON 이면 늘 해석: null → None(계약 §5-10 '읽은 null 은 없음', T10), 숫자·불리언도 JSON 값
            return json.loads(raw)
        except ValueError:                      # JSON 이 아닌 본문(드묾)은 글자 그대로
            return raw.decode("utf-8", "replace")

    # ---- 조회 ----
    def get(self, sm_id, path=None, retries=None):
        """요소 JSON(path=None 이면 서브모델 전체). 없으면 None."""
        p = self.el(sm_id, path) if path else f"/submodels/{b64(sm_id)}"
        return self._json("GET", p, ok_404=True, retries=retries)

    def get_value(self, sm_id, path, retries=None):
        """$value (ValueOnly). 없으면 None. 소수 Range 가 든 요소는 BaSyx 가 400(T5) → get() + element_value() 로 읽을 것."""
        return self._json("GET", self.el(sm_id, path) + "/$value", ok_404=True, retries=retries)

    # ---- 갱신 ----
    def patch_value(self, sm_id, path, value, retries=None):
        """$value PATCH. SMC 는 하위 구조 전체를 보내야 함(일부만 보내면 500 = 결과 불명, 실측 T3)."""
        self._json("PATCH", self.el(sm_id, path) + "/$value", value_body(value), retries=retries)

    def post(self, sm_id, parent_path, element, retries=0):
        """parent_path(SMC) 아래에 요소 추가(None 이면 서브모델 최상위).
        주의: 운영 MongoDB 는 같은 idShort 를 POST 해도 201 로 중복 생성한다(T4) → POST 는 멱등이 아니므로
        자동 재시도하지 않는다(retries=0). 결과를 모르는 실패 뒤에는 호출자가 GET 으로 존재를 확인하고 다시 보낼 것."""
        self._json("POST", self.el(sm_id, parent_path), element, retries=retries)

    def put(self, sm_id, path, element, retries=None):
        self._json("PUT", self.el(sm_id, path), element, retries=retries)

    def delete(self, sm_id, path, retries=None):
        """삭제. 없으면 False."""
        st, raw = self.request("DELETE", self.el(sm_id, path), retries=retries)
        if st == 404:
            return False
        if st >= 300:
            raise AasError("DELETE", path, st, raw.decode("utf-8", "replace"), self.token_env)
        return True
